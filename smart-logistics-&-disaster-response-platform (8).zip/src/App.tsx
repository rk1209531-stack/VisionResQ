import React, { useState, useEffect, useRef } from "react";
import {
  ScreenId,
  UserRole,
  Incident,
  IncidentType,
  IncidentStatus,
  BroadcastAlert,
  EmergencyRequest,
  OfflineReportQueueItem,
  TransportBooking,
  BookingStatus,
  VehiclePricingConfig,
} from "./types";
import {
  INITIAL_INCIDENTS,
  INITIAL_ALERTS,
  INITIAL_EMERGENCY_REQUESTS,
} from "./mockData";
import {
  INITIAL_BOOKINGS,
  INITIAL_VEHICLE_PRICING,
} from "./transportData";
import {
  analyzeIncidentWithGemini,
  fetchSerpApiDisruptionAlerts,
  getOfflineQueue,
  saveToOfflineQueue,
  clearOfflineQueue,
} from "./services/api";
import { useDeviceGPS } from "./hooks/useDeviceGPS";
import {
  testConnection,
  subscribeIncidents,
  saveIncidentToFirestore,
  updateIncidentInFirestore,
  subscribeEmergencyRequests,
  saveEmergencyRequestToFirestore,
  updateEmergencyRequestInFirestore,
  subscribeTransportBookings,
  saveTransportBookingToFirestore,
  updateTransportBookingInFirestore,
  subscribeBroadcastAlerts,
  saveBroadcastAlertToFirestore,
  seedInitialFirestoreDataIfEmpty,
} from "./services/firebase";

// Components
import { Header } from "./components/common/Header";
import { MobileFrame } from "./components/mobile/MobileFrame";
import { AlertOctagon } from "lucide-react";

// Screens (All 17 Required SIH Screens + Smart Logistics Module)
import { SplashScreen } from "./components/screens/SplashScreen";
import { LoginScreen } from "./components/screens/LoginScreen";
import { RegistrationScreen } from "./components/screens/RegistrationScreen";
import { HomeDashboardScreen } from "./components/screens/HomeDashboardScreen";
import { BookTransportScreen } from "./components/screens/BookTransportScreen";
import { BookingConfirmationScreen } from "./components/screens/BookingConfirmationScreen";
import { BookingTrackingScreen } from "./components/screens/BookingTrackingScreen";
import { DriverDashboardScreen } from "./components/screens/DriverDashboardScreen";
import { IncidentReportingScreen } from "./components/screens/IncidentReportingScreen";
import { VoiceReportingScreen } from "./components/screens/VoiceReportingScreen";
import { AIAnalysisScreen } from "./components/screens/AIAnalysisScreen";
import { IncidentDetailsScreen } from "./components/screens/IncidentDetailsScreen";
import { CrowdVerificationScreen } from "./components/screens/CrowdVerificationScreen";
import { LiveIncidentMapScreen } from "./components/screens/LiveIncidentMapScreen";
import { SmartRouteScreen } from "./components/screens/SmartRouteScreen";
import { AlertsScreen } from "./components/screens/AlertsScreen";
import { EmergencyRequestsScreen } from "./components/screens/EmergencyRequestsScreen";
import { AuthorityDashboardScreen } from "./components/screens/AuthorityDashboardScreen";
import { IncidentManagementScreen } from "./components/screens/IncidentManagementScreen";
import { ResolutionTrackingScreen } from "./components/screens/ResolutionTrackingScreen";
import { UserProfileScreen } from "./components/screens/UserProfileScreen";
import { SIHDeliverablesScreen } from "./components/screens/SIHDeliverablesScreen";

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<ScreenId>("home");
  const [currentRole, setCurrentRole] = useState<UserRole>("citizen");
  const [viewMode, setViewMode] = useState<"mobile" | "fullscreen" | "deliverables">("mobile");
  const [incidents, setIncidents] = useState<Incident[]>(INITIAL_INCIDENTS);
  const [selectedIncident, setSelectedIncident] = useState<Incident | null>(INITIAL_INCIDENTS[0]);
  const [alerts, setAlerts] = useState<BroadcastAlert[]>(INITIAL_ALERTS);
  const [emergencyRequests, setEmergencyRequests] = useState<EmergencyRequest[]>(INITIAL_EMERGENCY_REQUESTS);
  const [isOnline, setIsOnline] = useState<boolean>(true);
  const [offlineQueue, setOfflineQueue] = useState<OfflineReportQueueItem[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);

  // Smart Logistics & Transport Booking Module State
  const [bookings, setBookings] = useState<TransportBooking[]>(INITIAL_BOOKINGS);
  const [activeBooking, setActiveBooking] = useState<TransportBooking | null>(INITIAL_BOOKINGS[0]);
  const [vehiclePricing, setVehiclePricing] = useState<VehiclePricingConfig[]>(INITIAL_VEHICLE_PRICING);
  const [firebaseConnected, setFirebaseConnected] = useState<boolean>(false);
  const { location: userGps } = useDeviceGPS();

  // Initialize Firebase Firestore connection, live listeners & seed initial dataset
  useEffect(() => {
    let unsubs: (() => void)[] = [];

    async function initFirebase() {
      const isConnected = await testConnection();
      setFirebaseConnected(isConnected);

      // Seed baseline data if firestore collections are empty
      await seedInitialFirestoreDataIfEmpty(
        INITIAL_INCIDENTS,
        INITIAL_ALERTS,
        INITIAL_EMERGENCY_REQUESTS,
        INITIAL_BOOKINGS
      );

      // 1. Incidents Real-time sync
      const unsubIncidents = subscribeIncidents(
        (liveIncidents) => {
          if (liveIncidents && liveIncidents.length > 0) {
            setIncidents(liveIncidents);
            setSelectedIncident((current) => {
              if (!current) return liveIncidents[0];
              const match = liveIncidents.find((i) => i.id === current.id);
              return match || liveIncidents[0];
            });
          }
        },
        (err) => console.warn("Firestore incidents listener warning:", err)
      );
      unsubs.push(unsubIncidents);

      // 2. Emergency Requests Real-time sync
      const unsubEmergency = subscribeEmergencyRequests(
        (liveRequests) => {
          if (liveRequests && liveRequests.length > 0) {
            setEmergencyRequests(liveRequests);
          }
        },
        (err) => console.warn("Firestore emergency requests listener warning:", err)
      );
      unsubs.push(unsubEmergency);

      // 3. Transport Bookings Real-time sync
      const unsubBookings = subscribeTransportBookings(
        (liveBookings) => {
          if (liveBookings && liveBookings.length > 0) {
            setBookings(liveBookings);
            setActiveBooking((current) => {
              if (!current) return liveBookings[0];
              const match = liveBookings.find((b) => b.bookingId === current.bookingId);
              return match || liveBookings[0];
            });
          }
        },
        (err) => console.warn("Firestore bookings listener warning:", err)
      );
      unsubs.push(unsubBookings);

      // 4. Broadcast Alerts Real-time sync
      const unsubAlerts = subscribeBroadcastAlerts(
        (liveAlerts) => {
          if (liveAlerts && liveAlerts.length > 0) {
            setAlerts(liveAlerts);
          }
        },
        (err) => console.warn("Firestore alerts listener warning:", err)
      );
      unsubs.push(unsubAlerts);
    }

    initFirebase();

    return () => {
      unsubs.forEach((unsub) => unsub());
    };
  }, []);

  // Connect SerpApi + Gemini AI road & disaster disruption pipeline to existing alert/risk workflow using GPS coordinates
  useEffect(() => {
    if (!isOnline) return;
    let cancelled = false;

    async function syncRegionalDisruptionReports() {
      const result = await fetchSerpApiDisruptionAlerts({
        lat: userGps.lat,
        lng: userGps.lng,
        locationName: userGps.locality || userGps.formattedAddress,
      });

      if (cancelled || result.status !== "success" || result.alerts.length === 0) {
        return;
      }

      setAlerts((prev) => {
        const existingIds = new Set(prev.map((a) => a.id));
        const existingTitles = new Set(prev.map((a) => a.title.toLowerCase()));
        const newUniqueAlerts = result.alerts.filter(
          (a) => !existingIds.has(a.id) && !existingTitles.has(a.title.toLowerCase())
        );
        if (newUniqueAlerts.length === 0) return prev;
        return [...newUniqueAlerts, ...prev];
      });
    }

    syncRegionalDisruptionReports();

    return () => {
      cancelled = true;
    };
  }, [isOnline, userGps.lat, userGps.lng, userGps.locality, userGps.formattedAddress]);

  // Logistics Handlers
  const handleInitiateBooking = (booking: TransportBooking) => {
    setActiveBooking(booking);
    setBookings((prev) => [booking, ...prev.filter((b) => b.bookingId !== booking.bookingId)]);
    saveTransportBookingToFirestore(booking).catch((err) =>
      console.warn("Could not sync booking to Firestore:", err)
    );
  };

  const handleConfirmBooking = (bookingId: string) => {
    const booking = bookings.find((b) => b.bookingId === bookingId) || activeBooking;
    setBookings((prev) =>
      prev.map((b) =>
        b.bookingId === bookingId ? { ...b, status: "Driver Assigned", driverProgressPercent: 5 } : b
      )
    );
    setActiveBooking((prev) =>
      prev && prev.bookingId === bookingId
        ? { ...prev, status: "Driver Assigned", driverProgressPercent: 5 }
        : prev
    );
    updateTransportBookingInFirestore(
      bookingId,
      {
        status: "Driver Assigned",
        driverProgressPercent: 5,
      },
      booking || undefined
    ).catch((err) => console.warn("Could not sync booking confirmation to Firestore:", err));
  };

  const handleUpdateBookingStatus = (
    bookingId: string,
    status: BookingStatus,
    progressPercent?: number
  ) => {
    const booking = bookings.find((b) => b.bookingId === bookingId) || activeBooking;
    setBookings((prev) =>
      prev.map((b) => {
        if (b.bookingId !== bookingId) return b;
        return {
          ...b,
          status,
          driverProgressPercent:
            progressPercent !== undefined ? progressPercent : b.driverProgressPercent,
          updatedAt: "Just now",
        };
      })
    );
    setActiveBooking((prev) => {
      if (!prev || prev.bookingId !== bookingId) return prev;
      return {
        ...prev,
        status,
        driverProgressPercent:
          progressPercent !== undefined ? progressPercent : prev.driverProgressPercent,
        updatedAt: "Just now",
      };
    });
    updateTransportBookingInFirestore(
      bookingId,
      {
        status,
        driverProgressPercent: progressPercent,
      },
      booking || undefined
    ).catch((err) => console.warn("Could not sync booking status to Firestore:", err));
  };

  const handleUpdateVehiclePricing = (pricing: VehiclePricingConfig[]) => {
    setVehiclePricing(pricing);
  };

  const handleApproveGreenCorridor = (bookingId: string) => {
    const booking = bookings.find((b) => b.bookingId === bookingId) || activeBooking;
    setBookings((prev) =>
      prev.map((b) => (b.bookingId === bookingId ? { ...b, greenCorridorApproved: true } : b))
    );
    setActiveBooking((prev) =>
      prev && prev.bookingId === bookingId ? { ...prev, greenCorridorApproved: true } : prev
    );
    updateTransportBookingInFirestore(
      bookingId,
      {
        greenCorridorApproved: true,
        status: booking?.status || "Driver Assigned",
      },
      booking || undefined
    ).catch((err) => console.warn("Could not sync green corridor approval to Firestore:", err));
  };

  // Initialize offline queue
  useEffect(() => {
    setOfflineQueue(getOfflineQueue());
  }, []);

  // Handler: Incident Report Submission with Gemini AI
  const handleReportSubmit = async (reportData: {
    type: IncidentType;
    description: string;
    locationName: string;
    lat: number;
    lng: number;
    imageBase64?: string;
    imageUrl?: string;
  }) => {
    // If user is currently in simulated offline mode:
    if (!isOnline) {
      const offlineItem: OfflineReportQueueItem = {
        id: `offline_${Date.now()}`,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        type: reportData.type,
        description: reportData.description,
        locationName: reportData.locationName,
        lat: reportData.lat,
        lng: reportData.lng,
        imageBase64: reportData.imageBase64,
        imageUrl: reportData.imageUrl,
        syncStatus: "Pending",
      };

      saveToOfflineQueue(offlineItem);
      setOfflineQueue(getOfflineQueue());

      // Create local fallback incident for immediate viewing
      const newIncident: Incident = {
        id: offlineItem.id,
        title: `${reportData.type} at ${reportData.locationName}`,
        description: reportData.description,
        type: reportData.type,
        status: "Reported",
        locationName: reportData.locationName,
        lat: reportData.lat,
        lng: reportData.lng,
        imageUrl: reportData.imageUrl || "https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?w=800&auto=format&fit=crop&q=80",
        reportedAt: "Just now (Offline)",
        reportedBy: {
          name: "You (Offline Mode)",
          role: currentRole,
          phone: "+91 98765 43210",
        },
        aiAnalysis: {
          incidentType: reportData.type,
          summary: reportData.description,
          severity: "High",
          riskScore: 85,
          recommendedAction: "Saved to offline cache. Will auto-sync with Gemini AI when reconnected.",
          estimatedClearanceHours: 12,
          greenCorridorViability: false,
          modelUsed: "Cached Offline Heuristic",
        },
        crowdVerification: {
          confirmations: 1,
          rejections: 0,
          confidenceScore: 100,
          userVoted: "confirm",
        },
        resolutionTimeline: [
          {
            step: "Reported (Offline)",
            timestamp: "Just now",
            updatedBy: "Local Device Storage",
            note: "Stored in encrypted local queue due to zero network coverage.",
          },
        ],
      };

      setIncidents([newIncident, ...incidents]);
      setSelectedIncident(newIncident);
      setCurrentScreen("ai_analysis");
      return;
    }

    // Online Mode: Trigger Gemini AI Vision
    setIsAnalyzing(true);
    try {
      const aiResult = await analyzeIncidentWithGemini({
        imageBase64: reportData.imageBase64,
        userDescription: reportData.description,
        locationName: reportData.locationName,
        lat: reportData.lat,
        lng: reportData.lng,
      });

      const newIncident: Incident = {
        id: `inc_${Date.now()}`,
        title: `${aiResult.incidentType || reportData.type} at ${reportData.locationName}`,
        description: reportData.description,
        type: aiResult.incidentType || reportData.type,
        status: "Reported",
        locationName: reportData.locationName,
        lat: reportData.lat,
        lng: reportData.lng,
        imageUrl: reportData.imageUrl || "https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?w=800&auto=format&fit=crop&q=80",
        reportedAt: "Just now",
        reportedBy: {
          name: "You (Verified Citizen)",
          role: currentRole,
          phone: "+91 98765 43210",
        },
        aiAnalysis: {
          incidentType: aiResult.incidentType || reportData.type,
          summary: aiResult.summary || reportData.description,
          severity: aiResult.severity || "High",
          riskScore: aiResult.riskScore || 85,
          recommendedAction: aiResult.recommendedAction || "Use alternate route.",
          estimatedClearanceHours: aiResult.estimatedClearanceHours || 12,
          affectedInfrastructure: aiResult.affectedInfrastructure || ["Carriageway"],
          greenCorridorViability: aiResult.greenCorridorViability ?? false,
          modelUsed: "Gemini 3.8 Flash Multimodal",
        },
        crowdVerification: {
          confirmations: 1,
          rejections: 0,
          confidenceScore: 100,
          userVoted: "confirm",
        },
        resolutionTimeline: [
          {
            step: "Reported",
            timestamp: "Just now",
            updatedBy: "Citizen + Gemini Vision",
            note: "Incident captured, GPS geotagged, and scanned with AI.",
          },
        ],
      };

      setIncidents([newIncident, ...incidents]);
      setSelectedIncident(newIncident);
      setCurrentScreen("ai_analysis");

      // Save live to Firebase Firestore
      saveIncidentToFirestore(newIncident).catch((err) =>
        console.warn("Could not sync incident to Firestore:", err)
      );
    } catch (err) {
      console.error("Report submit error:", err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Handler: Voice Report Submitted -> Jump to Report Screen with transcribed description
  const handleVoiceSubmitted = (transcript: string) => {
    setCurrentScreen("report");
  };

  // Handler: Crowd Verification Vote (Step 3)
  const handleVote = (incidentId: string, type: "confirm" | "reject") => {
    let updatedPayload: Partial<Incident> | null = null;
    setIncidents((prev) =>
      prev.map((inc) => {
        if (inc.id !== incidentId) return inc;

        const currentVoted = inc.crowdVerification.userVoted;
        let confirms = inc.crowdVerification.confirmations;
        let rejects = inc.crowdVerification.rejections;

        if (currentVoted === type) {
          // Toggle off
          if (type === "confirm") confirms = Math.max(0, confirms - 1);
          else rejects = Math.max(0, rejects - 1);
          const nextVerification = {
            ...inc.crowdVerification,
            confirmations: confirms,
            rejections: rejects,
            confidenceScore:
              confirms + rejects > 0
                ? Math.round((confirms / (confirms + rejects)) * 100)
                : 50,
            userVoted: null,
          };
          updatedPayload = { crowdVerification: nextVerification };
          return {
            ...inc,
            crowdVerification: nextVerification,
          };
        }

        if (type === "confirm") {
          confirms += 1;
          if (currentVoted === "reject") rejects = Math.max(0, rejects - 1);
        } else {
          rejects += 1;
          if (currentVoted === "confirm") confirms = Math.max(0, confirms - 1);
        }

        const total = confirms + rejects;
        const confidenceScore = total > 0 ? Math.round((confirms / total) * 100) : 50;
        const nextStatus = confidenceScore >= 80 && inc.status === "Reported" ? "Verified" : inc.status;

        const nextVerification = {
          confirmations: confirms,
          rejections: rejects,
          confidenceScore,
          userVoted: type,
        };

        updatedPayload = {
          status: nextStatus,
          crowdVerification: nextVerification,
        };

        return {
          ...inc,
          status: nextStatus,
          crowdVerification: nextVerification,
        };
      })
    );

    if (updatedPayload) {
      const incident = incidents.find((i) => i.id === incidentId);
      updateIncidentInFirestore(
        incidentId,
        {
          ...updatedPayload,
          title: incident?.title || "Incident Report",
        },
        incident || undefined
      ).catch((err) =>
        console.warn("Could not sync vote to Firestore:", err)
      );
    }
  };

  // Handler: Toggle Emergency Priority
  const handleTogglePriority = (incidentId: string) => {
    let nextPriority = false;
    const incident = incidents.find((i) => i.id === incidentId);
    setIncidents((prev) =>
      prev.map((inc) => {
        if (inc.id === incidentId) {
          nextPriority = !inc.isEmergencyPriority;
          return { ...inc, isEmergencyPriority: nextPriority };
        }
        return inc;
      })
    );
    updateIncidentInFirestore(
      incidentId,
      {
        isEmergencyPriority: nextPriority,
        title: incident?.title || "Incident Report",
        status: incident?.status || "Reported",
      },
      incident || undefined
    ).catch((err) =>
      console.warn("Could not sync emergency priority to Firestore:", err)
    );
  };

  // Handler: Update Resolution Status & Append Milestone Note
  const handleUpdateStatus = (incidentId: string, status: IncidentStatus, note?: string) => {
    let newTimeline: Incident["resolutionTimeline"] = [];
    const incident = incidents.find((i) => i.id === incidentId);
    setIncidents((prev) =>
      prev.map((inc) => {
        if (inc.id !== incidentId) return inc;
        newTimeline = [
          ...inc.resolutionTimeline,
          {
            step: status,
            timestamp: "Just now",
            updatedBy: currentRole === "authority" ? "Authority Official" : "Emergency Unit",
            note: note || `Status updated to ${status}.`,
          },
        ];
        return {
          ...inc,
          status,
          resolutionTimeline: newTimeline,
        };
      })
    );
    updateIncidentInFirestore(
      incidentId,
      {
        status,
        resolutionTimeline: newTimeline,
        title: incident?.title || "Incident Report",
      },
      incident || undefined
    ).catch((err) =>
      console.warn("Could not sync status update to Firestore:", err)
    );
  };

  // Handler: Create Broadcast Alert
  const handleCreateAlert = (alertData: Omit<BroadcastAlert, "id" | "timestamp" | "active">) => {
    const newAlert: BroadcastAlert = {
      ...alertData,
      id: `alert_${Date.now()}`,
      timestamp: "Just now",
      active: true,
    };
    setAlerts([newAlert, ...alerts]);
    saveBroadcastAlertToFirestore(newAlert).catch((err) =>
      console.warn("Could not sync broadcast alert to Firestore:", err)
    );
  };

  // Handler: Resolve Broadcast Alert
  const handleResolveAlert = (id: string) => {
    const target = alerts.find((a) => a.id === id);
    setAlerts((prev) =>
      prev.map((a) => (a.id === id ? { ...a, active: false } : a))
    );
    if (target) {
      saveBroadcastAlertToFirestore({ ...target, active: false }).catch((err) =>
        console.warn("Could not sync alert resolve to Firestore:", err)
      );
    }
  };

  // Handler: Create Emergency Request
  const handleCreateEmergencyRequest = (
    reqData: Omit<EmergencyRequest, "id" | "requestedAt" | "status">
  ) => {
    const newReq: EmergencyRequest = {
      ...reqData,
      id: `sos_${Date.now()}`,
      requestedAt: "Just now",
      status: "Green Corridor Active",
    };
    setEmergencyRequests([newReq, ...emergencyRequests]);
    saveEmergencyRequestToFirestore(newReq).catch((err) =>
      console.warn("Could not sync emergency request to Firestore:", err)
    );
  };

  // Handler: Update Emergency Request Status
  const handleUpdateEmergencyStatus = (
    id: string,
    status: EmergencyRequest["status"]
  ) => {
    const req = emergencyRequests.find((r) => r.id === id);
    setEmergencyRequests((prev) =>
      prev.map((r) => (r.id === id ? { ...r, status } : r))
    );
    updateEmergencyRequestInFirestore(id, { status }, req || undefined).catch((err) =>
      console.warn("Could not sync emergency status to Firestore:", err)
    );
  };

  // Handler: Sync Offline Queue (Step 8)
  const handleSyncOffline = async () => {
    const queue = getOfflineQueue();
    if (queue.length === 0) return;

    for (const item of queue) {
      try {
        const aiResult = await analyzeIncidentWithGemini({
          userDescription: item.description,
          locationName: item.locationName,
          lat: item.lat,
          lng: item.lng,
        });

        const syncedIncident: Incident = {
          id: `synced_${item.id}`,
          title: `${aiResult.incidentType || item.type} at ${item.locationName}`,
          description: item.description,
          type: aiResult.incidentType || item.type,
          status: "Verified",
          locationName: item.locationName,
          lat: item.lat,
          lng: item.lng,
          imageUrl: item.imageUrl || "https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?w=800&auto=format&fit=crop&q=80",
          reportedAt: "Synced from Offline Cache",
          reportedBy: {
            name: "Field Officer (Synced)",
            role: currentRole,
            phone: "+91 98765 43210",
          },
          aiAnalysis: {
            incidentType: aiResult.incidentType || item.type,
            summary: aiResult.summary || item.description,
            severity: aiResult.severity || "High",
            riskScore: aiResult.riskScore || 85,
            recommendedAction: aiResult.recommendedAction || "Use alternate route.",
            estimatedClearanceHours: aiResult.estimatedClearanceHours || 12,
            affectedInfrastructure: aiResult.affectedInfrastructure || ["Carriageway"],
            greenCorridorViability: aiResult.greenCorridorViability ?? false,
            modelUsed: "Gemini 3.8 Flash (Synced)",
          },
          crowdVerification: {
            confirmations: 2,
            rejections: 0,
            confidenceScore: 100,
            userVoted: "confirm",
          },
          resolutionTimeline: [
            {
              step: "Synced to Cloud",
              timestamp: "Just now",
              updatedBy: "Background Sync Worker",
              note: "Offline report processed and added to active highway records.",
            },
          ],
        };

        setIncidents((prev) => [syncedIncident, ...prev]);
        saveIncidentToFirestore(syncedIncident).catch((err) =>
          console.warn("Could not sync offline item to Firestore:", err)
        );
      } catch (err) {
        console.warn("Failed to sync item:", err);
      }
    }

    clearOfflineQueue();
    setOfflineQueue([]);
  };

  // Render Current Screen
  const renderScreen = () => {
    switch (currentScreen) {
      case "splash":
        return <SplashScreen onComplete={() => setCurrentScreen("home")} />;

      case "login":
        return (
          <LoginScreen
            currentRole={currentRole}
            onRoleChange={setCurrentRole}
            onNavigate={setCurrentScreen}
          />
        );

      case "register":
        return (
          <RegistrationScreen
            currentRole={currentRole}
            onRoleChange={setCurrentRole}
            onNavigate={setCurrentScreen}
          />
        );

      case "home":
        return (
          <HomeDashboardScreen
            incidents={incidents}
            alerts={alerts}
            currentRole={currentRole}
            onNavigate={setCurrentScreen}
            onSelectIncident={(inc) => {
              setSelectedIncident(inc);
              setCurrentScreen("incident_details");
            }}
            isOnline={isOnline}
          />
        );

      case "book_transport":
        return (
          <BookTransportScreen
            onNavigate={setCurrentScreen}
            onInitiateBooking={handleInitiateBooking}
            vehiclePricing={vehiclePricing}
            userRole={currentRole}
            incidents={incidents}
          />
        );

      case "booking_confirmation":
        return (
          <BookingConfirmationScreen
            booking={activeBooking}
            onNavigate={setCurrentScreen}
            onConfirmBooking={handleConfirmBooking}
          />
        );

      case "booking_tracking":
        return (
          <BookingTrackingScreen
            booking={activeBooking}
            onNavigate={setCurrentScreen}
            onUpdateBookingStatus={handleUpdateBookingStatus}
          />
        );

      case "driver_dashboard":
        return (
          <DriverDashboardScreen
            bookings={bookings}
            onNavigate={setCurrentScreen}
            onUpdateBookingStatus={handleUpdateBookingStatus}
            onSelectBookingForTracking={(booking) => {
              setActiveBooking(booking);
            }}
          />
        );

      case "report":
        return (
          <IncidentReportingScreen
            onNavigate={setCurrentScreen}
            onSubmitReport={handleReportSubmit}
            isOnline={isOnline}
            isAnalyzing={isAnalyzing}
          />
        );

      case "voice_report":
        return (
          <VoiceReportingScreen
            onNavigate={setCurrentScreen}
            onVoiceSubmitted={handleVoiceSubmitted}
          />
        );

      case "ai_analysis":
        return (
          <AIAnalysisScreen
            incident={selectedIncident}
            onNavigate={setCurrentScreen}
          />
        );

      case "incident_details":
        return (
          <IncidentDetailsScreen
            incident={selectedIncident}
            onNavigate={setCurrentScreen}
            onVote={handleVote}
            onTogglePriority={handleTogglePriority}
          />
        );

      case "crowd_verify":
        return (
          <CrowdVerificationScreen
            incidents={incidents}
            onVote={handleVote}
            onSelectIncident={(inc) => {
              setSelectedIncident(inc);
            }}
            onNavigate={setCurrentScreen}
          />
        );

      case "live_map":
        return (
          <LiveIncidentMapScreen
            incidents={incidents}
            onSelectIncident={(inc) => {
              setSelectedIncident(inc);
            }}
            onNavigate={setCurrentScreen}
          />
        );

      case "smart_route":
        return <SmartRouteScreen onNavigate={setCurrentScreen} incidents={incidents} />;

      case "alerts":
        return (
          <AlertsScreen
            alerts={alerts}
            currentRole={currentRole}
            onNavigate={setCurrentScreen}
            onCreateAlert={handleCreateAlert}
            onResolveAlert={handleResolveAlert}
          />
        );

      case "emergency":
        return (
          <EmergencyRequestsScreen
            emergencyRequests={emergencyRequests}
            currentRole={currentRole}
            onNavigate={setCurrentScreen}
            onCreateRequest={handleCreateEmergencyRequest}
            onUpdateStatus={handleUpdateEmergencyStatus}
            isOnline={isOnline}
          />
        );

      case "authority_dashboard":
        return (
          <AuthorityDashboardScreen
            incidents={incidents}
            onNavigate={setCurrentScreen}
            onSelectIncident={(inc) => {
              setSelectedIncident(inc);
            }}
            bookings={bookings}
            vehiclePricing={vehiclePricing}
            onUpdateVehiclePricing={handleUpdateVehiclePricing}
            onApproveGreenCorridor={handleApproveGreenCorridor}
          />
        );

      case "incident_mgmt":
        return (
          <IncidentManagementScreen
            incidents={incidents}
            onSelectIncident={(inc) => {
              setSelectedIncident(inc);
            }}
            onUpdateStatus={handleUpdateStatus}
            onNavigate={setCurrentScreen}
          />
        );

      case "resolution_tracking":
        return (
          <ResolutionTrackingScreen
            incident={selectedIncident}
            onNavigate={setCurrentScreen}
            onAdvanceStage={handleUpdateStatus}
          />
        );

      case "profile":
        return (
          <UserProfileScreen
            currentRole={currentRole}
            onRoleChange={setCurrentRole}
            isOnline={isOnline}
            onToggleOnline={() => setIsOnline(!isOnline)}
            offlineQueueCount={offlineQueue.length}
            onSyncOffline={handleSyncOffline}
            onNavigate={setCurrentScreen}
          />
        );

      default:
        return (
          <HomeDashboardScreen
            incidents={incidents}
            alerts={alerts}
            currentRole={currentRole}
            onNavigate={setCurrentScreen}
            onSelectIncident={(inc) => {
              setSelectedIncident(inc);
              setCurrentScreen("incident_details");
            }}
            isOnline={isOnline}
          />
        );
    }
  };

  const activeAlertsCount = alerts.filter((a) => a.active).length;
  const [isSosFlashing, setIsSosFlashing] = useState(false);
  const sosAudioCtxRef = useRef<AudioContext | null>(null);
  const sosFlashTimerRef = useRef<number | null>(null);

  const playEmergencySosAlertSound = () => {
    try {
      const AudioContextClass =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!AudioContextClass) return;

      if (!sosAudioCtxRef.current || sosAudioCtxRef.current.state === "closed") {
        sosAudioCtxRef.current = new AudioContextClass();
      }
      const ctx = sosAudioCtxRef.current;
      if (ctx.state === "suspended") {
        ctx.resume().catch(() => {});
      }

      const now = ctx.currentTime;
      const duration = 0.44; // Matches the 440ms flash animation window

      // Master gain envelope for the 440ms flash duration
      const masterGain = ctx.createGain();
      masterGain.gain.setValueAtTime(0.001, now);
      masterGain.gain.exponentialRampToValueAtTime(0.22, now + 0.02);
      masterGain.gain.setValueAtTime(0.22, now + 0.18);
      masterGain.gain.exponentialRampToValueAtTime(0.04, now + 0.21);
      masterGain.gain.exponentialRampToValueAtTime(0.25, now + 0.24);
      masterGain.gain.setValueAtTime(0.25, now + 0.38);
      masterGain.gain.exponentialRampToValueAtTime(0.0001, now + duration);
      masterGain.connect(ctx.destination);

      // High-frequency primary emergency beacon oscillator (1850Hz -> 2650Hz rapid dual sweep)
      const primaryOsc = ctx.createOscillator();
      primaryOsc.type = "triangle";
      primaryOsc.frequency.setValueAtTime(1850, now);
      primaryOsc.frequency.exponentialRampToValueAtTime(2650, now + 0.19);
      primaryOsc.frequency.setValueAtTime(2000, now + 0.22);
      primaryOsc.frequency.exponentialRampToValueAtTime(2880, now + 0.42);
      primaryOsc.connect(masterGain);

      // High-frequency harmonic overtone for crisp emergency urgency (3200Hz)
      const harmonicOsc = ctx.createOscillator();
      const harmonicGain = ctx.createGain();
      harmonicOsc.type = "sine";
      harmonicOsc.frequency.setValueAtTime(3100, now);
      harmonicOsc.frequency.exponentialRampToValueAtTime(3720, now + duration);
      harmonicGain.gain.setValueAtTime(0.35, now);
      harmonicOsc.connect(harmonicGain);
      harmonicGain.connect(masterGain);

      primaryOsc.start(now);
      harmonicOsc.start(now);
      primaryOsc.stop(now + duration);
      harmonicOsc.stop(now + duration);
    } catch (err) {
      console.warn("Emergency SOS audio alert could not play:", err);
    }
  };

  const handleFullscreenSosClick = () => {
    if (sosFlashTimerRef.current !== null) {
      window.clearTimeout(sosFlashTimerRef.current);
    }
    setIsSosFlashing(true);
    playEmergencySosAlertSound();
    setCurrentScreen("emergency");
    sosFlashTimerRef.current = window.setTimeout(() => {
      setIsSosFlashing(false);
      sosFlashTimerRef.current = null;
    }, 440);
  };

  return (
    <div className="min-h-screen bg-[#050816] text-slate-100 flex flex-col font-sans selection:bg-[#2563EB] selection:text-white relative overflow-x-hidden">
      {/* Subtle Ambient Blue/Cyan Command Center Glow */}
      <div className="pointer-events-none fixed top-0 left-1/4 w-[520px] h-[320px] bg-[#2563EB]/[0.07] rounded-full blur-[120px] z-0" />
      <div className="pointer-events-none fixed bottom-0 right-1/4 w-[480px] h-[320px] bg-[#06B6D4]/[0.05] rounded-full blur-[120px] z-0" />

      {/* Top Universal Navbar */}
      <Header
        currentRole={currentRole}
        onRoleChange={setCurrentRole}
        isOnline={isOnline}
        onToggleOnline={() => setIsOnline(!isOnline)}
        activeScreen={currentScreen}
        onNavigate={setCurrentScreen}
        offlineCount={offlineQueue.length}
        onSyncOffline={handleSyncOffline}
        viewMode={viewMode}
        onViewModeChange={setViewMode}
        emergencyCount={emergencyRequests.filter((e) => e.status.includes("Active") || e.status.includes("Pending")).length}
        firebaseConnected={firebaseConnected}
      />

      {/* Main Container */}
      <main className="relative z-10 flex-1 flex items-center justify-center p-2 sm:p-6 w-full">
        {viewMode === "deliverables" ? (
          <div key="deliverables" className="w-full vrq-page-enter">
            <SIHDeliverablesScreen
              onNavigate={setCurrentScreen}
              onViewModeChange={setViewMode}
            />
          </div>
        ) : viewMode === "fullscreen" ? (
          <div className="w-full max-w-7xl mx-auto flex flex-col xl:flex-row gap-6">
            <div className="flex-1 vrq-card overflow-hidden min-h-[720px] flex flex-col">
              <div className="px-4 py-3 bg-[#050816]/90 border-b border-white/[0.08] flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#10B981] animate-pulse shadow-[0_0_8px_#10B981]" />
                  <span className="text-xs font-bold text-slate-200 capitalize tracking-wide">
                    Full Screen Mode: {currentScreen.replace(/_/g, " ")}
                  </span>
                </div>
                <button
                  onClick={() => setViewMode("mobile")}
                  className="px-3 py-1.5 text-xs font-semibold bg-white/[0.06] hover:bg-white/[0.12] border border-white/[0.08] text-slate-200 rounded-xl transition-all duration-200 active:scale-95 cursor-pointer"
                >
                  Switch to Mobile Frame
                </button>
              </div>
              <div key={currentScreen} className="flex-1 p-4 sm:p-6 overflow-y-auto relative vrq-page-enter">
                {renderScreen()}
              </div>

              {/* Global Floating SOS Button in Full Screen Mode */}
              <button
                id="fullscreen-floating-sos-btn"
                onClick={handleFullscreenSosClick}
                aria-label="Trigger Emergency SOS"
                data-audio-alert={isSosFlashing ? "playing" : "idle"}
                className={`fixed bottom-6 right-6 z-50 overflow-hidden px-4 py-3 rounded-full bg-gradient-to-r from-[#EF4444] via-rose-600 to-red-700 hover:from-red-500 hover:to-rose-500 active:from-red-700 active:via-rose-800 active:to-red-900 text-white font-black text-xs sm:text-sm flex items-center gap-2 ring-2 ring-red-400/40 active:ring-red-500/60 transition-all duration-200 hover:scale-105 active:scale-95 cursor-pointer vrq-sos-pulse ${
                  isSosFlashing ? "vrq-sos-flashing" : ""
                }`}
                title="Emergency SOS Green Corridor"
              >
                <span
                  aria-hidden="true"
                  className={`vrq-sos-flash-overlay ${isSosFlashing ? "is-flashing" : ""}`}
                />
                <AlertOctagon className="relative z-10 w-5 h-5 text-white" />
                <span className="relative z-10 tracking-wider font-extrabold">EMERGENCY SOS</span>
              </button>
            </div>
          </div>
        ) : (
          <MobileFrame
            currentScreen={currentScreen}
            onNavigate={setCurrentScreen}
            currentRole={currentRole}
            activeAlertsCount={activeAlertsCount}
          >
            <div key={currentScreen} className="vrq-page-enter h-full">
              {renderScreen()}
            </div>
          </MobileFrame>
        )}
      </main>
    </div>
  );
}
