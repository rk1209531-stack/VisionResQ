import React, { useState, useCallback, useEffect } from "react";
import {
  APIProvider,
  Map,
  AdvancedMarker,
  Pin,
  InfoWindow,
  Polyline,
  Circle,
  useMap,
  useApiLoadingStatus,
  APILoadingStatus,
} from "@vis.gl/react-google-maps";
import { Incident } from "../../types";
import {
  AlertTriangle,
  MapPin,
  Compass,
  Layers,
  Navigation,
  ExternalLink,
  ShieldCheck,
  Flame,
  Droplets,
  Building,
  Car,
} from "lucide-react";

export type MapOverlayLayer = "Traffic Density" | "Hazard Zones" | "Relief Centers";

export interface ReliefCenterItem {
  id: string;
  name: string;
  agency: string;
  lat: number;
  lng: number;
  capacityBeds: number;
  availableBeds: number;
  stockpilePercent: number;
  facilities: string[];
  contactPhone: string;
  status: "Operational" | "High Occupancy" | "Emergency Triage";
}

export interface TrafficDensitySegment {
  id: string;
  corridorName: string;
  densityPercent: number;
  avgSpeedKmh: number;
  congestionLevel: "Heavy Congestion" | "Moderate Slowdown" | "Free Flow";
  color: string;
  queueLengthKm: number;
  coordinates: [number, number][];
  midpoint: [number, number];
}

export const DEFAULT_RELIEF_CENTERS: ReliefCenterItem[] = [
  {
    id: "rc-guwahati",
    name: "Guwahati NDRF Command & Trauma Camp",
    agency: "NDRF 1st Bn & ASDMA",
    lat: 26.1158,
    lng: 91.7589,
    capacityBeds: 1200,
    availableBeds: 410,
    stockpilePercent: 94,
    facilities: ["Level-1 Trauma ICU", "Helipad", "Water Purification", "Satellite Comms"],
    contactPhone: "+91 361-2237219",
    status: "Operational",
  },
  {
    id: "rc-jagiroad",
    name: "Jagiroad SDMA Flood Shelter & Depot",
    agency: "SDRF & District Medical Team",
    lat: 26.1195,
    lng: 92.185,
    capacityBeds: 650,
    availableBeds: 185,
    stockpilePercent: 88,
    facilities: ["Inflatable Rescue Boats", "Mobile Medical Unit", "Ration Warehouse"],
    contactPhone: "+91 3678-242108",
    status: "Operational",
  },
  {
    id: "rc-sonapur",
    name: "Sonapur Highland Evacuation & Triage Hub",
    agency: "BRO & Emergency Medical Corps",
    lat: 25.152,
    lng: 92.385,
    capacityBeds: 450,
    availableBeds: 92,
    stockpilePercent: 76,
    facilities: ["Earthmover Staging", "Emergency Oxygen", "Highway Rescue Crane"],
    contactPhone: "+91 361-2789401",
    status: "High Occupancy",
  },
  {
    id: "rc-haflong",
    name: "Haflong Green Corridor Logistics Base",
    agency: "NHAI & NDRF Relief Convoy Hub",
    lat: 25.1642,
    lng: 93.0167,
    capacityBeds: 800,
    availableBeds: 520,
    stockpilePercent: 96,
    facilities: ["Fuel Reserve", "Convoy Escort Base", "Field Hospital"],
    contactPhone: "+91 3673-236112",
    status: "Operational",
  },
  {
    id: "rc-silchar",
    name: "Silchar Regional Disaster Relief & Medical Camp",
    agency: "Cachar DDMA & Red Cross",
    lat: 24.8333,
    lng: 92.7789,
    capacityBeds: 1500,
    availableBeds: 640,
    stockpilePercent: 91,
    facilities: ["Regional Hospital Link", "Air-Drop Zone", "Cold Chain Medicine Storage"],
    contactPhone: "+91 3842-239044",
    status: "Operational",
  },
];

export const DEFAULT_TRAFFIC_SEGMENTS: TrafficDensitySegment[] = [
  {
    id: "tf-sonapur-red",
    corridorName: "NH-6 Sonapur Landslide Approach",
    densityPercent: 92,
    avgSpeedKmh: 8,
    congestionLevel: "Heavy Congestion",
    color: "#ef4444",
    queueLengthKm: 4.2,
    coordinates: [
      [26.1112, 92.1001],
      [25.62, 92.23],
      [25.132, 92.361],
    ],
    midpoint: [25.62, 92.23],
  },
  {
    id: "tf-jorabat-amber",
    corridorName: "NH-27 Guwahati–Jagiroad Bottleneck",
    densityPercent: 64,
    avgSpeedKmh: 24,
    congestionLevel: "Moderate Slowdown",
    color: "#f59e0b",
    queueLengthKm: 1.8,
    coordinates: [
      [26.1445, 91.7362],
      [26.125, 91.92],
      [26.1112, 92.1001],
    ],
    midpoint: [26.125, 91.92],
  },
  {
    id: "tf-silchar-amber",
    corridorName: "NH-6 Sonapur–Silchar Southern Link",
    densityPercent: 58,
    avgSpeedKmh: 28,
    congestionLevel: "Moderate Slowdown",
    color: "#f59e0b",
    queueLengthKm: 1.1,
    coordinates: [
      [25.132, 92.361],
      [24.98, 92.57],
      [24.8333, 92.7789],
    ],
    midpoint: [24.98, 92.57],
  },
  {
    id: "tf-haflong-green",
    corridorName: "NH-27 Nagaon–Haflong Safe Green Corridor",
    densityPercent: 18,
    avgSpeedKmh: 58,
    congestionLevel: "Free Flow",
    color: "#10b981",
    queueLengthKm: 0,
    coordinates: [
      [26.1445, 91.7362],
      [26.345, 92.684],
      [25.18, 93.02],
      [24.8333, 92.7789],
    ],
    midpoint: [25.76, 92.85],
  },
];

export interface GoogleDisasterMapProps {
  apiKey: string;
  incidents: Incident[];
  userLocation?: { lat: number; lng: number; formattedAddress?: string; isRealGPS?: boolean };
  pickupLocation?: { lat: number; lng: number; name: string };
  destinationLocation?: { lat: number; lng: number; name: string };
  vehicleLocation?: { lat: number; lng: number; label?: string };
  routeAPath?: [number, number][];
  routeBPath?: [number, number][];
  onSelectIncident?: (incident: Incident) => void;
  heightClass?: string;
  onOpenKeyModal?: () => void;
  onAuthError?: () => void;
  activeOverlay?: MapOverlayLayer;
  onOverlayChange?: (layer: MapOverlayLayer) => void;
  reliefCenters?: ReliefCenterItem[];
  trafficSegments?: TrafficDensitySegment[];
}

// Internal watcher for Google Maps API loading status
const ApiAuthWatcher: React.FC<{ onAuthError?: () => void }> = ({ onAuthError }) => {
  const status = useApiLoadingStatus();
  useEffect(() => {
    if (status === APILoadingStatus.AUTH_FAILURE || status === APILoadingStatus.FAILED) {
      console.warn("Google Maps API auth failure or loading failure detected:", status);
      if (onAuthError) {
        onAuthError();
      }
    }
  }, [status, onAuthError]);
  return null;
};

// Helper to center the map when requested
const MapRecenterController: React.FC<{ center: { lat: number; lng: number }; zoom: number }> = ({
  center,
  zoom,
}) => {
  const map = useMap();
  React.useEffect(() => {
    if (map) {
      map.panTo(center);
      map.setZoom(zoom);
    }
  }, [map, center, zoom]);
  return null;
};

// Automatic bounds & dynamic centering controller for Google Maps
const MapAutoFitController: React.FC<{
  pickupLocation?: { lat: number; lng: number };
  destinationLocation?: { lat: number; lng: number };
  userLocation?: { lat: number; lng: number };
  routeAPath?: any[];
}> = ({ pickupLocation, destinationLocation, userLocation, routeAPath }) => {
  const map = useMap();

  React.useEffect(() => {
    if (!map) return;

    // Both pickup and destination exist: fit bounds smoothly
    if (pickupLocation && destinationLocation) {
      try {
        if (typeof google !== "undefined" && google.maps && google.maps.LatLngBounds) {
          const bounds = new google.maps.LatLngBounds();
          bounds.extend({ lat: Number(pickupLocation.lat), lng: Number(pickupLocation.lng) });
          bounds.extend({ lat: Number(destinationLocation.lat), lng: Number(destinationLocation.lng) });

          if (routeAPath && routeAPath.length > 0) {
            const step = Math.max(1, Math.floor(routeAPath.length / 15));
            for (let i = 0; i < routeAPath.length; i += step) {
              const pt = routeAPath[i];
              if (Array.isArray(pt)) {
                bounds.extend({ lat: Number(pt[0]), lng: Number(pt[1]) });
              } else if (pt && "lat" in pt) {
                bounds.extend({ lat: Number(pt.lat), lng: Number(pt.lng) });
              }
            }
          }

          map.fitBounds(bounds, { top: 40, right: 40, bottom: 40, left: 40 });
          return;
        }
      } catch (e) {
        console.warn("fitBounds fallback", e);
      }
    }

    // Only pickup location updated
    if (pickupLocation) {
      map.panTo({ lat: Number(pickupLocation.lat), lng: Number(pickupLocation.lng) });
      map.setZoom(12);
    } else if (userLocation) {
      map.panTo({ lat: Number(userLocation.lat), lng: Number(userLocation.lng) });
      map.setZoom(12);
    }
  }, [
    map,
    pickupLocation?.lat,
    pickupLocation?.lng,
    destinationLocation?.lat,
    destinationLocation?.lng,
    routeAPath,
  ]);

  return null;
};

// Hazard Icon selector
function getHazardIcon(type: string = "") {
  const lower = type.toLowerCase();
  if (lower.includes("landslide") || lower.includes("rockfall")) {
    return <AlertTriangle className="w-3.5 h-3.5 text-amber-300" />;
  }
  if (lower.includes("flood") || lower.includes("water") || lower.includes("submersion")) {
    return <Droplets className="w-3.5 h-3.5 text-cyan-300" />;
  }
  if (lower.includes("bridge") || lower.includes("culvert") || lower.includes("structural")) {
    return <Building className="w-3.5 h-3.5 text-purple-300" />;
  }
  if (lower.includes("fire")) {
    return <Flame className="w-3.5 h-3.5 text-rose-300" />;
  }
  return <Car className="w-3.5 h-3.5 text-orange-300" />;
}

// Severity color helper
function getSeverityBadge(severity: string = "High") {
  switch (severity) {
    case "Critical":
      return { bg: "bg-rose-600", border: "border-rose-400", pinBg: "#e11d48", pinGlyph: "#ffffff" };
    case "High":
      return { bg: "bg-orange-600", border: "border-orange-400", pinBg: "#ea580c", pinGlyph: "#ffffff" };
    case "Medium":
      return { bg: "bg-amber-600", border: "border-amber-400", pinBg: "#d97706", pinGlyph: "#ffffff" };
    default:
      return { bg: "bg-blue-600", border: "border-blue-400", pinBg: "#2563eb", pinGlyph: "#ffffff" };
  }
}

export const GoogleDisasterMap: React.FC<GoogleDisasterMapProps> = ({
  apiKey,
  incidents = [],
  userLocation,
  pickupLocation,
  destinationLocation,
  vehicleLocation,
  routeAPath,
  routeBPath,
  onSelectIncident,
  heightClass = "h-[380px]",
  onOpenKeyModal,
  onAuthError,
  activeOverlay = "Hazard Zones",
  onOverlayChange,
  reliefCenters = DEFAULT_RELIEF_CENTERS,
  trafficSegments = DEFAULT_TRAFFIC_SEGMENTS,
}) => {
  const [selectedIncident, setSelectedIncident] = useState<Incident | null>(null);
  const [selectedReliefCenter, setSelectedReliefCenter] = useState<ReliefCenterItem | null>(null);
  const [localOverlay, setLocalOverlay] = useState<MapOverlayLayer>(activeOverlay);
  const [showCorridors, setShowCorridors] = useState<boolean>(true);
  const [mapTypeId, setMapTypeId] = useState<string>("roadmap");

  const currentOverlay = activeOverlay || localOverlay;

  const handleSelectOverlay = (layer: MapOverlayLayer) => {
    setLocalOverlay(layer);
    if (onOverlayChange) {
      onOverlayChange(layer);
    }
  };

  // Intercept Google Maps global auth failure callback (e.g. InvalidKeyMapError)
  useEffect(() => {
    const handleGmAuthFailure = () => {
      console.warn("Google Maps JavaScript API gm_authFailure called.");
      if (onAuthError) {
        onAuthError();
      }
    };
    const prevGmAuth = (window as unknown as { gm_authFailure?: () => void }).gm_authFailure;
    (window as unknown as { gm_authFailure?: () => void }).gm_authFailure = handleGmAuthFailure;

    return () => {
      if ((window as unknown as { gm_authFailure?: () => void }).gm_authFailure === handleGmAuthFailure) {
        (window as unknown as { gm_authFailure?: () => void }).gm_authFailure = prevGmAuth;
      }
    };
  }, [onAuthError]);

  const defaultCenter = userLocation
    ? { lat: userLocation.lat, lng: userLocation.lng }
    : incidents.length > 0
    ? { lat: incidents[0].lat, lng: incidents[0].lng }
    : { lat: 26.1445, lng: 91.7362 }; // Assam / Guwahati regional hub

  const [cameraCenter, setCameraCenter] = useState(defaultCenter);
  const [cameraZoom, setCameraZoom] = useState(11);

  // Convert route coordinates to Google Maps LatLngLiteral array
  const routeAPathLatLng = React.useMemo(() => {
    if (!routeAPath || routeAPath.length === 0) return [];
    return routeAPath.map((pt: any) => {
      if (Array.isArray(pt)) return { lat: Number(pt[0]), lng: Number(pt[1]) };
      if (pt && typeof pt === "object" && "lat" in pt && "lng" in pt) return { lat: Number(pt.lat), lng: Number(pt.lng) };
      return { lat: 0, lng: 0 };
    });
  }, [routeAPath]);

  const routeBPathLatLng = React.useMemo(() => {
    if (!routeBPath || routeBPath.length === 0) return [];
    return routeBPath.map((pt: any) => {
      if (Array.isArray(pt)) return { lat: Number(pt[0]), lng: Number(pt[1]) };
      if (pt && typeof pt === "object" && "lat" in pt && "lng" in pt) return { lat: Number(pt.lat), lng: Number(pt.lng) };
      return { lat: 0, lng: 0 };
    });
  }, [routeBPath]);

  const handleIncidentMarkerClick = (inc: Incident) => {
    setSelectedIncident(inc);
    if (onSelectIncident) {
      onSelectIncident(inc);
    }
  };

  const handleRecenter = () => {
    if (userLocation) {
      setCameraCenter({ lat: userLocation.lat, lng: userLocation.lng });
      setCameraZoom(13);
    } else if (incidents.length > 0) {
      setCameraCenter({ lat: incidents[0].lat, lng: incidents[0].lng });
      setCameraZoom(11);
    }
  };

  return (
    <div className={`relative w-full ${heightClass} rounded-2xl overflow-hidden border border-slate-800 shadow-2xl bg-slate-950`}>
      <APIProvider apiKey={apiKey} libraries={["marker", "geometry", "routes"]}>
        <ApiAuthWatcher onAuthError={onAuthError} />
        <div style={{ width: "100%", height: "100%" }}>
          <Map
            mapId="DEMO_MAP_ID"
            style={{ width: "100%", height: "100%" }}
            defaultCenter={defaultCenter}
            defaultZoom={11}
            gestureHandling="greedy"
            disableDefaultUI={false}
            mapTypeId={mapTypeId}
            internalUsageAttributionIds={["gmp_git_agentskills_v1", "gmp_mcp_codeassist_v1_aistudio"]}
          >
            <MapRecenterController center={cameraCenter} zoom={cameraZoom} />
            <MapAutoFitController
              pickupLocation={pickupLocation}
              destinationLocation={destinationLocation}
              userLocation={userLocation}
              routeAPath={routeAPathLatLng}
            />

            {/* 1. User Location Advanced Marker */}
            {userLocation && (
              <AdvancedMarker
                position={{ lat: userLocation.lat, lng: userLocation.lng }}
                title="Your Current Location"
              >
                <div className="relative flex items-center justify-center cursor-pointer">
                  <div className="absolute w-8 h-8 rounded-full bg-blue-500/40 animate-ping" />
                  <div className="w-6 h-6 rounded-full bg-blue-600 border-2 border-white shadow-xl flex items-center justify-center text-white text-[10px] font-bold">
                    GPS
                  </div>
                </div>
              </AdvancedMarker>
            )}

            {/* 2. Pickup Location Marker */}
            {pickupLocation && (
              <AdvancedMarker
                position={{ lat: pickupLocation.lat, lng: pickupLocation.lng }}
                title={`Pickup: ${pickupLocation.name}`}
              >
                <div className="flex items-center justify-center w-7 h-7 rounded-full bg-emerald-600 text-white shadow-xl border-2 border-white text-xs font-black">
                  P
                </div>
              </AdvancedMarker>
            )}

            {/* 3. Destination Location Marker */}
            {destinationLocation && (
              <AdvancedMarker
                position={{ lat: destinationLocation.lat, lng: destinationLocation.lng }}
                title={`Destination: ${destinationLocation.name}`}
              >
                <div className="flex items-center justify-center w-7 h-7 rounded-full bg-rose-600 text-white shadow-xl border-2 border-white text-xs font-black">
                  D
                </div>
              </AdvancedMarker>
            )}

            {/* 3b. Vehicle Live Tracking Marker */}
            {vehicleLocation && (
              <AdvancedMarker
                position={{ lat: vehicleLocation.lat, lng: vehicleLocation.lng }}
                title={vehicleLocation.label || "Disaster Relief Transport"}
              >
                <div className="relative flex items-center justify-center">
                  <div className="absolute w-9 h-9 rounded-full bg-blue-500/40 animate-ping" />
                  <div className="w-8 h-8 rounded-full bg-blue-600 border-2 border-white shadow-xl flex items-center justify-center text-white text-sm">
                    🚚
                  </div>
                </div>
              </AdvancedMarker>
            )}

            {/* 4. Disaster Incident Advanced Markers */}
            {incidents.map((inc) => {
              const colors = getSeverityBadge(inc.severity);
              const isSelected = selectedIncident?.id === inc.id;

              return (
                <AdvancedMarker
                  key={inc.id}
                  position={{ lat: inc.lat, lng: inc.lng }}
                  onClick={() => handleIncidentMarkerClick(inc)}
                  title={`${inc.title} (${inc.severity})`}
                >
                  <div
                    className={`group relative flex items-center justify-center p-1.5 rounded-full ${colors.bg} border-2 ${
                      isSelected ? "border-white scale-125 shadow-2xl ring-4 ring-orange-500/50" : colors.border
                    } text-white shadow-lg transition-transform duration-200 hover:scale-115 cursor-pointer`}
                  >
                    {getHazardIcon(inc.type || inc.incidentType)}
                    {inc.isEmergencyPriority && (
                      <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-red-500"></span>
                      </span>
                    )}
                  </div>
                </AdvancedMarker>
              );
            })}

            {/* 5. Geofenced Hazard Danger Zones (Circles) when Hazard Zones overlay is active */}
            {currentOverlay === "Hazard Zones" &&
              incidents.map((inc) => {
                const isCritical = inc.severity === "Critical";
                const isHigh = inc.severity === "High";
                const zoneColor = isCritical ? "#ef4444" : isHigh ? "#f97316" : "#eab308";
                return (
                  <Circle
                    key={`zone-${inc.id}`}
                    center={{ lat: inc.lat, lng: inc.lng }}
                    radius={isCritical ? 2200 : isHigh ? 1400 : 900}
                    strokeColor={zoneColor}
                    strokeOpacity={0.85}
                    strokeWeight={2}
                    fillColor={zoneColor}
                    fillOpacity={0.22}
                  />
                );
              })}

            {/* 5b. Traffic Density Overlay Segments & Speed Telemetry Badges */}
            {currentOverlay === "Traffic Density" &&
              trafficSegments.map((seg) => (
                <React.Fragment key={seg.id}>
                  <Polyline
                    path={seg.coordinates.map(([lat, lng]) => ({ lat, lng }))}
                    strokeColor={seg.color}
                    strokeOpacity={0.95}
                    strokeWeight={7}
                  />
                  <AdvancedMarker
                    position={{ lat: seg.midpoint[0], lng: seg.midpoint[1] }}
                    title={`${seg.corridorName}: ${seg.avgSpeedKmh} km/h (${seg.densityPercent}% density)`}
                  >
                    <div
                      className="px-2 py-1 rounded-lg text-[10px] font-extrabold text-white shadow-xl border border-white/40 backdrop-blur-md flex items-center gap-1"
                      style={{ backgroundColor: seg.color }}
                    >
                      <span>{seg.avgSpeedKmh} km/h</span>
                      <span className="opacity-80">•</span>
                      <span>{seg.densityPercent}%</span>
                    </div>
                  </AdvancedMarker>
                </React.Fragment>
              ))}

            {/* 5c. Relief Centers Overlay Markers & Safe Shelter Coverage Radii */}
            {currentOverlay === "Relief Centers" &&
              reliefCenters.map((rc) => (
                <React.Fragment key={rc.id}>
                  <Circle
                    center={{ lat: rc.lat, lng: rc.lng }}
                    radius={1400}
                    strokeColor="#10b981"
                    strokeOpacity={0.75}
                    strokeWeight={1.5}
                    fillColor="#10b981"
                    fillOpacity={0.14}
                  />
                  <AdvancedMarker
                    position={{ lat: rc.lat, lng: rc.lng }}
                    onClick={() => setSelectedReliefCenter(rc)}
                    title={`${rc.name} (${rc.availableBeds}/${rc.capacityBeds} Beds Available)`}
                  >
                    <div className="relative flex items-center justify-center cursor-pointer group">
                      <div className="absolute w-9 h-9 rounded-full bg-emerald-500/35 animate-ping" />
                      <div className="w-7 h-7 rounded-xl bg-emerald-600 border-2 border-white shadow-xl flex items-center justify-center text-white text-xs font-black">
                        ✚
                      </div>
                    </div>
                  </AdvancedMarker>
                </React.Fragment>
              ))}

            {/* Selected Relief Center InfoWindow */}
            {selectedReliefCenter && currentOverlay === "Relief Centers" && (
              <InfoWindow
                position={{ lat: selectedReliefCenter.lat, lng: selectedReliefCenter.lng }}
                onCloseClick={() => setSelectedReliefCenter(null)}
                pixelOffset={[0, -15]}
              >
                <div className="p-1.5 max-w-xs text-slate-900">
                  <div className="flex items-center gap-1.5 mb-1">
                    <span className="px-2 py-0.5 rounded text-[9px] font-black text-white bg-emerald-600">
                      RELIEF CAMP
                    </span>
                    <span className="text-[10px] font-bold text-slate-500">
                      {selectedReliefCenter.agency}
                    </span>
                  </div>
                  <h4 className="font-bold text-xs text-slate-900 leading-snug mb-1">
                    {selectedReliefCenter.name}
                  </h4>
                  <div className="bg-slate-100 rounded p-1.5 mb-1.5 text-[10px] space-y-0.5">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Shelter Capacity:</span>
                      <span className="font-bold text-emerald-700">
                        {selectedReliefCenter.availableBeds} / {selectedReliefCenter.capacityBeds} Beds Free
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Relief Stockpile:</span>
                      <span className="font-bold text-blue-700">
                        {selectedReliefCenter.stockpilePercent}% Stocked
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Emergency Desk:</span>
                      <span className="font-mono font-semibold text-slate-800">
                        {selectedReliefCenter.contactPhone}
                      </span>
                    </div>
                  </div>
                </div>
              </InfoWindow>
            )}

            {/* 6. Green Safe Relief Corridor (Route A Polyline) */}
            {showCorridors && currentOverlay !== "Traffic Density" && routeAPathLatLng.length > 1 && (
              <Polyline
                path={routeAPathLatLng}
                strokeColor="#10b981"
                strokeOpacity={0.9}
                strokeWeight={5}
              />
            )}

            {/* 7. Alternate Hazard Detour Corridor (Route B Polyline) */}
            {showCorridors && currentOverlay !== "Traffic Density" && routeBPathLatLng.length > 1 && (
              <Polyline
                path={routeBPathLatLng}
                strokeColor="#f97316"
                strokeOpacity={0.7}
                strokeWeight={4}
              />
            )}

            {/* 8. Selected Incident InfoWindow */}
            {selectedIncident && (
              <InfoWindow
                position={{ lat: selectedIncident.lat, lng: selectedIncident.lng }}
                onCloseClick={() => setSelectedIncident(null)}
                pixelOffset={[0, -15]}
              >
                <div className="p-1 max-w-xs text-slate-900">
                  <div className="flex items-center gap-1.5 mb-1">
                    <span
                      className={`px-2 py-0.5 rounded text-[9px] font-black text-white ${
                        selectedIncident.severity === "Critical"
                          ? "bg-rose-600"
                          : selectedIncident.severity === "High"
                          ? "bg-orange-600"
                          : "bg-amber-600"
                      }`}
                    >
                      {selectedIncident.severity}
                    </span>
                    <span className="text-[10px] font-semibold text-slate-500 uppercase">
                      {selectedIncident.type || selectedIncident.incidentType}
                    </span>
                  </div>

                  <h4 className="font-bold text-xs text-slate-900 leading-snug mb-1">
                    {selectedIncident.title}
                  </h4>

                  <p className="text-[11px] text-slate-600 line-clamp-2 mb-2">
                    {selectedIncident.description}
                  </p>

                  <div className="bg-slate-100 rounded p-1.5 mb-2 text-[10px] space-y-0.5">
                    <div className="flex justify-between">
                      <span className="text-slate-500">Crowd Trust:</span>
                      <span className="font-bold text-emerald-700">
                        {selectedIncident.crowdVerification?.confidenceScore ?? 85}% Confirmed
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">Passability:</span>
                      <span className="font-semibold text-rose-700">
                        {selectedIncident.severity === "Critical" ? "Blocked / Closed" : "Single-Lane Escort"}
                      </span>
                    </div>
                  </div>

                  {onSelectIncident && (
                    <button
                      onClick={() => {
                        onSelectIncident(selectedIncident);
                      }}
                      className="w-full py-1 bg-slate-900 hover:bg-slate-800 text-white rounded text-[10px] font-bold text-center transition"
                    >
                      Inspect Hazard Details
                    </button>
                  )}
                </div>
              </InfoWindow>
            )}
          </Map>
        </div>
      </APIProvider>

      {/* Top Controls Overlay */}
      <div className="absolute top-3 left-3 z-10 flex flex-wrap items-center gap-2">
        <div className="bg-slate-900/90 backdrop-blur-md px-2.5 py-1.5 rounded-xl border border-slate-700 text-xs text-white flex items-center gap-2 shadow-lg">
          <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="font-bold text-[11px]">Google Maps Platform</span>
          <span className="text-[10px] text-slate-400 hidden sm:inline">| Live GIS</span>
        </div>

        {/* Map Type Switcher */}
        <div className="bg-slate-900/90 backdrop-blur-md rounded-xl border border-slate-700 p-0.5 flex text-[10px] font-bold shadow-lg">
          <button
            onClick={() => setMapTypeId("roadmap")}
            className={`px-2 py-1 rounded-lg transition ${
              mapTypeId === "roadmap" ? "bg-orange-600 text-white shadow-sm" : "text-slate-300 hover:text-white"
            }`}
          >
            Vector
          </button>
          <button
            onClick={() => setMapTypeId("hybrid")}
            className={`px-2 py-1 rounded-lg transition ${
              mapTypeId === "hybrid" ? "bg-orange-600 text-white shadow-sm" : "text-slate-300 hover:text-white"
            }`}
          >
            Satellite
          </button>
          <button
            onClick={() => setMapTypeId("terrain")}
            className={`px-2 py-1 rounded-lg transition ${
              mapTypeId === "terrain" ? "bg-orange-600 text-white shadow-sm" : "text-slate-300 hover:text-white"
            }`}
          >
            Terrain
          </button>
        </div>

        {/* Layer Toggles */}
        {(["Traffic Density", "Hazard Zones", "Relief Centers"] as MapOverlayLayer[]).map((layer) => (
          <button
            key={layer}
            onClick={() => handleSelectOverlay(layer)}
            className={`px-2 py-1.5 rounded-xl text-[10px] font-bold border backdrop-blur-md transition shadow-lg cursor-pointer ${
              currentOverlay === layer
                ? "bg-gradient-to-r from-[#2563EB] to-[#06B6D4] border-cyan-400 text-white"
                : "bg-slate-900/80 border-slate-700 text-slate-400 hover:text-white"
            }`}
          >
            {currentOverlay === layer ? `✓ ${layer}` : layer}
          </button>
        ))}

        <button
          onClick={() => setShowCorridors((prev) => !prev)}
          className={`px-2 py-1.5 rounded-xl text-[10px] font-bold border backdrop-blur-md transition shadow-lg ${
            showCorridors
              ? "bg-emerald-950/80 border-emerald-600 text-emerald-200"
              : "bg-slate-900/80 border-slate-700 text-slate-400"
          }`}
          title="Toggle Green Relief Corridors"
        >
          {showCorridors ? "✓ Relief Corridors" : "+ Relief Corridors"}
        </button>
      </div>

      {/* Top-Right Quick Actions */}
      <div className="absolute top-3 right-3 z-10 flex items-center gap-2">
        <button
          onClick={handleRecenter}
          className="p-2 rounded-xl bg-slate-900/90 hover:bg-slate-800 text-slate-200 border border-slate-700 shadow-lg text-xs flex items-center gap-1 transition"
          title="Recenter Map View"
        >
          <Compass className="w-3.5 h-3.5 text-orange-400" />
          <span className="text-[10px] font-bold hidden sm:inline">Recenter</span>
        </button>

        {onOpenKeyModal && (
          <button
            onClick={onOpenKeyModal}
            className="px-2.5 py-1.5 rounded-xl bg-slate-900/90 hover:bg-slate-800 text-amber-400 border border-slate-700 shadow-lg text-[10px] font-bold flex items-center gap-1 transition"
            title="Configure Maps API Key"
          >
            <span>Key / Settings</span>
          </button>
        )}
      </div>

      {/* Bottom Map Legend */}
      <div className="absolute bottom-2 left-2 z-10 bg-slate-900/90 backdrop-blur-md px-2.5 py-1.5 rounded-xl border border-slate-700 text-[10px] text-slate-300 flex flex-wrap items-center gap-3 shadow-lg">
        <div className="flex items-center gap-1">
          <span className="w-2.5 h-2.5 rounded-full bg-blue-500"></span>
          <span>User GPS</span>
        </div>
        <div className="flex items-center gap-1">
          <span className="w-2.5 h-2.5 rounded-full bg-rose-600"></span>
          <span>Critical Risk</span>
        </div>
        <div className="flex items-center gap-1">
          <span className="w-2.5 h-2.5 rounded-full bg-orange-500"></span>
          <span>High Hazard</span>
        </div>
        <div className="flex items-center gap-1">
          <span className="w-3 h-1 rounded-full bg-emerald-500"></span>
          <span>Green Corridor</span>
        </div>
        <div className="flex items-center gap-1">
          <span className="w-3 h-1 rounded-full bg-orange-500"></span>
          <span>Detour Corridor</span>
        </div>
      </div>
    </div>
  );
};
