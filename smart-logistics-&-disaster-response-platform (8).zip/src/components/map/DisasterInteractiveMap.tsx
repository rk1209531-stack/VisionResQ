import React, { useEffect, useRef, useState, useCallback } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import "../../utils/leafletPatch";
import { Incident } from "../../types";
import {
  GoogleDisasterMap,
  MapOverlayLayer,
  ReliefCenterItem,
  TrafficDensitySegment,
  DEFAULT_RELIEF_CENTERS,
  DEFAULT_TRAFFIC_SEGMENTS,
} from "./GoogleDisasterMap";
import {
  AlertTriangle,
  Compass,
  Navigation,
  Key,
  ExternalLink,
  Map as MapIcon,
} from "lucide-react";

export type { MapOverlayLayer, ReliefCenterItem, TrafficDensitySegment };
export { DEFAULT_RELIEF_CENTERS, DEFAULT_TRAFFIC_SEGMENTS };

// Helper function to validate Google Maps Platform API key format
export function isValidGoogleMapsKey(key?: string | null): boolean {
  if (!key || typeof key !== "string") return false;
  const trimmed = key.trim();
  const placeholders = [
    "YOUR_API_KEY",
    "YOUR_KEY",
    "YOUR_DEMO_KEY",
    "DEMO_KEY",
    "YOUR_GOOGLE_MAPS_API_KEY",
    "KEY_HERE",
  ];
  if (
    !trimmed ||
    placeholders.includes(trimmed.toUpperCase()) ||
    trimmed.startsWith("<") ||
    trimmed.includes("<") ||
    trimmed.includes(">") ||
    trimmed.includes(" ") ||
    trimmed.includes("\n") ||
    trimmed.length < 20 ||
    !/^[A-Za-z0-9_\-]+$/.test(trimmed)
  ) {
    return false;
  }
  return true;
}

export interface DisasterInteractiveMapProps {
  incidents: Incident[];
  userLocation?: { lat: number; lng: number; formattedAddress?: string; isRealGPS?: boolean };
  pickupLocation?: { lat: number; lng: number; name: string };
  destinationLocation?: { lat: number; lng: number; name: string };
  vehicleLocation?: { lat: number; lng: number; label?: string };
  routeAPath?: [number, number][];
  routeBPath?: [number, number][];
  onSelectIncident?: (incident: Incident) => void;
  heightClass?: string;
  isDemoMode?: boolean;
  activeOverlay?: MapOverlayLayer;
  onOverlayChange?: (layer: MapOverlayLayer) => void;
  reliefCenters?: ReliefCenterItem[];
  trafficSegments?: TrafficDensitySegment[];
  focusLocation?: { lat: number; lng: number; zoom?: number } | null;
}

export const DisasterInteractiveMap: React.FC<DisasterInteractiveMapProps> = ({
  incidents = [],
  userLocation,
  pickupLocation,
  destinationLocation,
  vehicleLocation,
  routeAPath,
  routeBPath,
  onSelectIncident,
  heightClass = "h-[360px]",
  isDemoMode = false,
  activeOverlay = "Hazard Zones",
  onOverlayChange,
  reliefCenters = DEFAULT_RELIEF_CENTERS,
  trafficSegments = DEFAULT_TRAFFIC_SEGMENTS,
  focusLocation = null,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const leafletMapRef = useRef<L.Map | null>(null);
  const leafletMarkersRef = useRef<L.LayerGroup | null>(null);

  // Check client env key or localStorage key first with strict validation
  const viteKey =
    typeof import.meta !== "undefined" && (import.meta as unknown as { env?: Record<string, string> }).env
      ? (import.meta as unknown as { env?: Record<string, string> }).env?.VITE_GOOGLE_MAPS_API_KEY || ""
      : "";

  const rawLocalKey = typeof window !== "undefined" ? localStorage.getItem("gmp_api_key") : null;
  // If stored key in localStorage is corrupted or invalid, clear it
  if (rawLocalKey && !isValidGoogleMapsKey(rawLocalKey)) {
    try {
      localStorage.removeItem("gmp_api_key");
    } catch {
      // ignore
    }
  }

  const validStoredKey = rawLocalKey && isValidGoogleMapsKey(rawLocalKey) ? rawLocalKey.trim() : "";
  const validViteKey = isValidGoogleMapsKey(viteKey) ? viteKey.trim() : "";
  const initialLocalKey = validStoredKey || validViteKey || "";

  const [hasGoogleKey, setHasGoogleKey] = useState<boolean>(Boolean(initialLocalKey));
  const [googleKey, setGoogleKey] = useState<string>(initialLocalKey);
  const [mapEngine, setMapEngine] = useState<"google" | "osm">(initialLocalKey ? "google" : "osm");
  const [showKeyModal, setShowKeyModal] = useState<boolean>(false);
  const [manualKeyInput, setManualKeyInput] = useState<string>("");
  const [keyError, setKeyError] = useState<string | null>(null);
  const [statusNotice, setStatusNotice] = useState<string | null>(null);

  // Fallback handler if Google Maps API throws an auth failure or InvalidKeyMapError
  const handleGoogleMapsAuthError = useCallback(() => {
    console.warn("Google Maps authentication failure intercepted. Falling back to OpenStreetMap GIS.");
    setHasGoogleKey(false);
    setGoogleKey("");
    setMapEngine("osm");
    setStatusNotice("Google Maps API encountered InvalidKeyMapError. Reverted safely to OpenStreetMap GIS.");
    if (typeof window !== "undefined") {
      try {
        localStorage.removeItem("gmp_api_key");
      } catch {
        // ignore
      }
    }
  }, []);

  // Check backend configuration for Google Maps key
  useEffect(() => {
    fetch("/api/config")
      .then((res) => res.json())
      .then((data) => {
        if (data.googleMapsApiKey && isValidGoogleMapsKey(data.googleMapsApiKey)) {
          setGoogleKey(data.googleMapsApiKey);
          setHasGoogleKey(true);
          setMapEngine("google");
        } else if (initialLocalKey && isValidGoogleMapsKey(initialLocalKey)) {
          setGoogleKey(initialLocalKey);
          setHasGoogleKey(true);
          setMapEngine("google");
        } else {
          setHasGoogleKey(false);
          setGoogleKey("");
          setMapEngine("osm");
        }
      })
      .catch(() => {
        if (initialLocalKey && isValidGoogleMapsKey(initialLocalKey)) {
          setGoogleKey(initialLocalKey);
          setHasGoogleKey(true);
          setMapEngine("google");
        } else {
          setHasGoogleKey(false);
          setGoogleKey("");
          setMapEngine("osm");
        }
      });
  }, [initialLocalKey]);

  // Handle saving key to localStorage
  const handleSaveKey = (keyToSave: string) => {
    let candidate = keyToSave.trim();

    // Support pasted HTML or script snippet
    const match = candidate.match(/(?:key|apiKey)[=:]\s*["']?([A-Za-z0-9_\-]+)["']?/i);
    if (match && match[1]) {
      candidate = match[1].trim();
    }
    candidate = candidate.replace(/^["']|["']$/g, "").trim();

    if (isValidGoogleMapsKey(candidate)) {
      if (typeof window !== "undefined") {
        localStorage.setItem("gmp_api_key", candidate);
      }
      setKeyError(null);
      setStatusNotice(null);
      setGoogleKey(candidate);
      setHasGoogleKey(true);
      setMapEngine("google");
      setShowKeyModal(false);
    } else {
      setKeyError("Invalid API key format. Please enter a valid Google Maps Platform API key or Demo Key.");
    }
  };

  // 1. Initialize Leaflet Map Canvas ONCE on mount (if in OSM mode)
  useEffect(() => {
    if (mapEngine !== "osm") return;

    const container = containerRef.current as (HTMLDivElement & { _leaflet_id?: number | null }) | null;
    if (!container) return;

    if (container._leaflet_id && leafletMapRef.current) {
      try {
        leafletMapRef.current.stop();
        leafletMapRef.current.remove();
      } catch {
        // ignore
      }
      leafletMapRef.current = null;
    }
    container._leaflet_id = null;

    const initialLat = userLocation?.lat ?? (incidents.length > 0 ? incidents[0].lat : 26.1445);
    const initialLng = userLocation?.lng ?? (incidents.length > 0 ? incidents[0].lng : 91.7362);

    const map = L.map(container, {
      center: [initialLat, initialLng],
      zoom: 11,
      zoomControl: false,
    });

    L.control.zoom({ position: "bottomright" }).addTo(map);

    // High contrast street tiles (Carto Voyager)
    L.tileLayer("https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png", {
      attribution: '&copy; <a href="https://carto.com/">CARTO</a> & OpenStreetMap contributors',
      maxZoom: 19,
    }).addTo(map);

    const markerGroup = L.layerGroup().addTo(map);
    leafletMarkersRef.current = markerGroup;
    leafletMapRef.current = map;

    return () => {
      if (leafletMapRef.current) {
        try {
          leafletMapRef.current.stop();
          leafletMapRef.current.remove();
        } catch {
          // ignore
        }
        leafletMapRef.current = null;
      }
      leafletMarkersRef.current = null;
      if (container) {
        container._leaflet_id = null;
      }
    };
  }, [mapEngine]);

  // 2. Synchronize Layers, Markers, and Routes whenever props update (OSM mode)
  useEffect(() => {
    if (mapEngine !== "osm") return;
    const map = leafletMapRef.current;
    const markerGroup = leafletMarkersRef.current;
    if (!map || !markerGroup) return;

    try {
      markerGroup.clearLayers();
    } catch {
      // ignore
    }

    // 1. Render User GPS "You are here" Marker
    if (userLocation) {
      const userIcon = L.divIcon({
        className: "custom-gps-marker",
        html: `
          <div class="relative flex items-center justify-center">
            <div class="absolute w-8 h-8 rounded-full bg-blue-500/30 animate-ping"></div>
            <div class="w-5 h-5 rounded-full bg-blue-600 border-2 border-white shadow-lg flex items-center justify-center">
              <div class="w-1.5 h-1.5 rounded-full bg-white"></div>
            </div>
          </div>
        `,
        iconSize: [32, 32],
        iconAnchor: [16, 16],
      });

      const userMarker = L.marker([userLocation.lat, userLocation.lng], { icon: userIcon });
      userMarker.bindTooltip(
        `<b>You are here</b><br/>${userLocation.formattedAddress || `${userLocation.lat.toFixed(4)}, ${userLocation.lng.toFixed(4)}`}<br/><span class="text-xs text-blue-600 font-bold">${userLocation.isRealGPS ? "● Live Device GPS" : "● Demo Coordinate"}</span>`,
        { permanent: false, direction: "top" }
      );
      markerGroup.addLayer(userMarker);
    }

    // 2. Render Pickup & Destination Markers
    if (pickupLocation) {
      const pickupIcon = L.divIcon({
        className: "pickup-marker",
        html: `
          <div class="flex items-center justify-center w-7 h-7 rounded-full bg-emerald-600 text-white shadow-md border-2 border-white text-xs font-black">
            P
          </div>
        `,
        iconSize: [28, 28],
        iconAnchor: [14, 14],
      });
      const pMarker = L.marker([pickupLocation.lat, pickupLocation.lng], { icon: pickupIcon });
      pMarker.bindTooltip(`<b>Pickup:</b> ${pickupLocation.name}`, { direction: "top" });
      markerGroup.addLayer(pMarker);
    }

    if (destinationLocation) {
      const destIcon = L.divIcon({
        className: "dest-marker",
        html: `
          <div class="flex items-center justify-center w-7 h-7 rounded-full bg-rose-600 text-white shadow-md border-2 border-white text-xs font-black">
            D
          </div>
        `,
        iconSize: [28, 28],
        iconAnchor: [14, 14],
      });
      const dMarker = L.marker([destinationLocation.lat, destinationLocation.lng], { icon: destIcon });
      dMarker.bindTooltip(`<b>Destination:</b> ${destinationLocation.name}`, { direction: "top" });
      markerGroup.addLayer(dMarker);
    }

    // 2c. Vehicle Live Marker
    if (vehicleLocation) {
      const vehIcon = L.divIcon({
        className: "vehicle-live-marker",
        html: `
          <div class="relative flex items-center justify-center">
            <div class="w-8 h-8 rounded-full bg-blue-600 border-2 border-white shadow-xl flex items-center justify-center text-white text-sm">
              🚚
            </div>
          </div>
        `,
        iconSize: [32, 32],
        iconAnchor: [16, 16],
      });
      const vMarker = L.marker([vehicleLocation.lat, vehicleLocation.lng], { icon: vehIcon });
      vMarker.bindTooltip(`<b>${vehicleLocation.label || "Relief Transport"}</b>`, { direction: "top" });
      markerGroup.addLayer(vMarker);
    }

    // 3. Render Incident Hazard Markers & (when Hazard Zones overlay is active) Geofenced Danger Perimeters
    incidents.forEach((inc) => {
      const isCritical = inc.severity === "Critical";
      const isHighRisk = isCritical || inc.severity === "High";
      const isMedRisk = inc.severity === "Medium";
      const markerColor = isHighRisk ? "#dc2626" : isMedRisk ? "#ea580c" : "#2563eb";

      if (activeOverlay === "Hazard Zones") {
        const zoneRadius = isCritical ? 6500 : isHighRisk ? 4500 : 2800;
        const zoneColor = isCritical ? "#ef4444" : isHighRisk ? "#f97316" : "#eab308";
        const hazardCircle = L.circle([inc.lat, inc.lng], {
          radius: zoneRadius,
          color: zoneColor,
          weight: 2,
          opacity: 0.85,
          fillColor: zoneColor,
          fillOpacity: 0.22,
          dashArray: isCritical ? undefined : "4, 4",
        });
        hazardCircle.bindTooltip(
          `<b>⚠️ Geofenced Hazard Zone: ${inc.title}</b><br/>Severity: <b>${inc.severity}</b> • Risk Score: <b>${inc.aiAnalysis?.riskScore || 50}%</b><br/>Exclusion Radius: <b>${(zoneRadius / 1000).toFixed(1)} km</b>`,
          { direction: "top" }
        );
        markerGroup.addLayer(hazardCircle);
      }

      const incIcon = L.divIcon({
        className: "hazard-pin",
        html: `
          <div class="relative flex items-center justify-center cursor-pointer">
            ${
              activeOverlay === "Hazard Zones" && isHighRisk
                ? `<div class="absolute w-8 h-8 rounded-full animate-ping opacity-40" style="background-color: ${markerColor}"></div>`
                : ""
            }
            <div class="w-6 h-6 rounded-full border-2 border-white shadow-md flex items-center justify-center text-white text-[10px] font-bold" style="background-color: ${markerColor}">
              !
            </div>
          </div>
        `,
        iconSize: [24, 24],
        iconAnchor: [12, 12],
      });

      const incMarker = L.marker([inc.lat, inc.lng], { icon: incIcon });
      incMarker.on("click", () => {
        if (onSelectIncident) {
          onSelectIncident(inc);
        }
      });

      const popupHtml = `
        <div class="text-xs p-1 max-w-[220px]">
          <div class="font-bold text-slate-900 text-sm mb-1">${inc.title}</div>
          <div class="text-slate-600 mb-1">📍 ${inc.locationName}</div>
          <div class="flex items-center gap-2 mb-1.5">
            <span class="px-1.5 py-0.5 rounded font-bold text-[10px] ${isHighRisk ? "bg-red-100 text-red-700" : isMedRisk ? "bg-amber-100 text-amber-700" : "bg-emerald-100 text-emerald-700"}">
              Risk: ${inc.aiAnalysis?.riskScore || 50}/100
            </span>
            <span class="text-[10px] text-slate-500 font-semibold">${inc.status}</span>
          </div>
          <div class="text-[11px] text-slate-700 line-clamp-2 mb-2 font-medium">
            ${inc.aiAnalysis?.summary || inc.description}
          </div>
          <div class="text-[10px] text-emerald-700 font-bold bg-emerald-50 px-2 py-1 rounded border border-emerald-200">
            ✓ Confirmed: ${inc.crowdVerification?.confirmations || 0} | ✗ Disputed: ${inc.crowdVerification?.rejections || 0}
          </div>
        </div>
      `;
      incMarker.bindPopup(popupHtml);
      markerGroup.addLayer(incMarker);
    });

    // 3b. Render Traffic Density Overlay when activeOverlay === "Traffic Density"
    if (activeOverlay === "Traffic Density") {
      trafficSegments.forEach((seg) => {
        const poly = L.polyline(seg.coordinates, {
          color: seg.color,
          weight: 7,
          opacity: 0.92,
        });
        poly.bindTooltip(
          `<b>🚦 ${seg.corridorName}</b><br/>Status: <b>${seg.congestionLevel}</b><br/>Traffic Density: <b>${seg.densityPercent}%</b> • Avg Speed: <b>${seg.avgSpeedKmh} km/h</b>${
            seg.queueLengthKm > 0 ? `<br/>Queue Length: <b>${seg.queueLengthKm} km</b>` : ""
          }`,
          { sticky: true, direction: "top" }
        );
        markerGroup.addLayer(poly);

        const speedBadgeIcon = L.divIcon({
          className: "traffic-speed-badge",
          html: `
            <div class="px-2 py-0.5 rounded-lg text-[10px] font-extrabold text-white shadow-lg border border-white/60 whitespace-nowrap flex items-center gap-1" style="background-color: ${seg.color}">
              <span>${seg.avgSpeedKmh} km/h</span>
              <span>•</span>
              <span>${seg.densityPercent}%</span>
            </div>
          `,
          iconSize: [84, 22],
          iconAnchor: [42, 11],
        });
        const badgeMarker = L.marker(seg.midpoint, { icon: speedBadgeIcon });
        badgeMarker.bindPopup(`
          <div class="text-xs p-1 max-w-[210px]">
            <div class="font-bold text-slate-900 text-xs mb-1">${seg.corridorName}</div>
            <div class="text-[11px] font-bold mb-1" style="color: ${seg.color}">${seg.congestionLevel}</div>
            <div class="text-[11px] text-slate-700 space-y-0.5">
              <div>• Traffic Density: <b>${seg.densityPercent}%</b></div>
              <div>• Average Speed: <b>${seg.avgSpeedKmh} km/h</b></div>
              <div>• Queue Backlog: <b>${seg.queueLengthKm > 0 ? `${seg.queueLengthKm} km` : "Clear Corridor"}</b></div>
            </div>
          </div>
        `);
        markerGroup.addLayer(badgeMarker);
      });
    }

    // 3c. Render Relief Centers Overlay when activeOverlay === "Relief Centers"
    if (activeOverlay === "Relief Centers") {
      reliefCenters.forEach((rc) => {
        const shelterCircle = L.circle([rc.lat, rc.lng], {
          radius: 4200,
          color: "#10b981",
          weight: 1.5,
          opacity: 0.8,
          fillColor: "#10b981",
          fillOpacity: 0.14,
          dashArray: "5, 5",
        });
        markerGroup.addLayer(shelterCircle);

        const rcIcon = L.divIcon({
          className: "relief-center-pin",
          html: `
            <div class="relative flex items-center justify-center cursor-pointer">
              <div class="absolute w-9 h-9 rounded-full bg-emerald-500/35 animate-ping"></div>
              <div class="w-7 h-7 rounded-xl bg-emerald-600 border-2 border-white shadow-xl flex items-center justify-center text-white text-xs font-black">
                ✚
              </div>
            </div>
          `,
          iconSize: [28, 28],
          iconAnchor: [14, 14],
        });

        const rcMarker = L.marker([rc.lat, rc.lng], { icon: rcIcon });
        const rcPopupHtml = `
          <div class="text-xs p-1 max-w-[230px]">
            <div class="flex items-center gap-1.5 mb-1">
              <span class="px-1.5 py-0.5 rounded bg-emerald-600 text-white font-black text-[9px]">RELIEF CENTER</span>
              <span class="text-[10px] font-bold text-emerald-700">${rc.status}</span>
            </div>
            <div class="font-bold text-slate-900 text-sm mb-0.5">${rc.name}</div>
            <div class="text-[11px] text-slate-500 font-semibold mb-1.5">${rc.agency}</div>
            <div class="bg-slate-100 rounded p-1.5 mb-1.5 text-[10px] text-slate-700 space-y-0.5">
              <div class="flex justify-between"><span>Available Beds:</span><b class="text-emerald-700">${rc.availableBeds} / ${rc.capacityBeds}</b></div>
              <div class="flex justify-between"><span>Supply Stockpile:</span><b class="text-blue-700">${rc.stockpilePercent}% Stocked</b></div>
              <div class="flex justify-between"><span>Emergency Desk:</span><b class="font-mono">${rc.contactPhone}</b></div>
            </div>
            <div class="text-[10px] text-slate-600">
              <b>Facilities:</b> ${rc.facilities.join(" • ")}
            </div>
          </div>
        `;
        rcMarker.bindPopup(rcPopupHtml);
        rcMarker.bindTooltip(
          `<b>✚ ${rc.name}</b><br/>${rc.availableBeds}/${rc.capacityBeds} Beds Free • ${rc.stockpilePercent}% Stocked`,
          { direction: "top" }
        );
        markerGroup.addLayer(rcMarker);
      });
    }

    // 4. Render Route Polylines (when not overridden by Traffic Density layer)
    if (activeOverlay !== "Traffic Density" && routeAPath && routeAPath.length > 1) {
      const safePathA: [number, number][] = routeAPath.map((pt: any) =>
        Array.isArray(pt) ? [Number(pt[0]), Number(pt[1])] : [Number(pt.lat), Number(pt.lng)]
      );
      const rA = L.polyline(safePathA, {
        color: "#10b981",
        weight: 5,
        opacity: 0.9,
      });
      markerGroup.addLayer(rA);
    }

    if (activeOverlay !== "Traffic Density" && routeBPath && routeBPath.length > 1) {
      const safePathB: [number, number][] = routeBPath.map((pt: any) =>
        Array.isArray(pt) ? [Number(pt[0]), Number(pt[1])] : [Number(pt.lat), Number(pt.lng)]
      );
      const rB = L.polyline(safePathB, {
        color: "#f97316",
        weight: 4,
        dashArray: "6, 6",
        opacity: 0.8,
      });
      markerGroup.addLayer(rB);
    }
  }, [
    mapEngine,
    incidents,
    userLocation?.lat,
    userLocation?.lng,
    pickupLocation?.lat,
    pickupLocation?.lng,
    destinationLocation?.lat,
    destinationLocation?.lng,
    routeAPath,
    routeBPath,
    onSelectIncident,
    activeOverlay,
    reliefCenters,
    trafficSegments,
  ]);

  // Pan map when focusLocation updates
  useEffect(() => {
    if (mapEngine === "osm" && leafletMapRef.current && focusLocation) {
      leafletMapRef.current.setView([focusLocation.lat, focusLocation.lng], focusLocation.zoom || 12, {
        animate: true,
      });
    }
  }, [mapEngine, focusLocation]);

  // If in Google Maps Mode and we have a validated key, render GoogleDisasterMap
  if (mapEngine === "google" && googleKey && isValidGoogleMapsKey(googleKey)) {
    return (
      <div className="relative">
        <GoogleDisasterMap
          apiKey={googleKey}
          incidents={incidents}
          userLocation={userLocation}
          pickupLocation={pickupLocation}
          destinationLocation={destinationLocation}
          vehicleLocation={vehicleLocation}
          routeAPath={routeAPath}
          routeBPath={routeBPath}
          onSelectIncident={onSelectIncident}
          heightClass={heightClass}
          onOpenKeyModal={() => setShowKeyModal(true)}
          onAuthError={handleGoogleMapsAuthError}
          activeOverlay={activeOverlay}
          onOverlayChange={onOverlayChange}
          reliefCenters={reliefCenters}
          trafficSegments={trafficSegments}
        />

        {/* Engine switcher quick tab */}
        <div className="absolute bottom-2 right-2 z-20 flex items-center gap-1.5">
          <button
            onClick={() => setMapEngine("osm")}
            className="px-2 py-1 bg-slate-900/90 hover:bg-slate-800 text-slate-400 hover:text-slate-200 text-[10px] font-semibold rounded-lg border border-slate-700 shadow-md backdrop-blur-md transition"
            title="Switch to OpenStreetMap mode"
          >
            OSM Mode
          </button>
        </div>

        {/* Key Modal (shared) */}
        {showKeyModal && (
          <KeyModal
            manualKeyInput={manualKeyInput}
            setManualKeyInput={setManualKeyInput}
            keyError={keyError}
            setKeyError={setKeyError}
            onSave={handleSaveKey}
            onClose={() => {
              setShowKeyModal(false);
              setKeyError(null);
            }}
          />
        )}
      </div>
    );
  }

  // Otherwise, Leaflet fallback with instant option to enable Google Maps
  return (
    <div className="relative w-full rounded-2xl overflow-hidden border border-slate-800 shadow-xl bg-slate-950">
      {/* Map Control Bar */}
      <div className="absolute top-2 left-2 right-2 z-[1000] flex items-center justify-between gap-2 pointer-events-none">
        <div className="flex items-center gap-1.5 bg-slate-900/90 backdrop-blur-md px-2.5 py-1.5 rounded-xl border border-slate-700/80 shadow-md pointer-events-auto">
          <Compass className="w-3.5 h-3.5 text-blue-400" />
          <span className="text-[11px] font-black text-white tracking-wide">
            LIVE DISASTER GIS MAP
          </span>
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
        </div>

        <div className="flex items-center gap-1.5 pointer-events-auto">
          {/* GIS Satellite Layer Toggle */}
          <button
            onClick={() => {
              if (googleKey && isValidGoogleMapsKey(googleKey)) {
                setMapEngine("google");
              } else {
                setKeyError(null);
                setShowKeyModal(true);
              }
            }}
            className="flex items-center gap-1.5 text-[10px] font-bold bg-slate-900/90 hover:bg-slate-800 text-slate-200 hover:text-white px-2.5 py-1.5 rounded-xl border border-slate-700/80 shadow-lg backdrop-blur-md transition cursor-pointer"
            title="Satellite & High-Precision Corridor View"
          >
            <MapIcon className="w-3.5 h-3.5 text-blue-400" />
            <span>GIS Satellite</span>
          </button>

          {/* Recenter button */}
          {userLocation && (
            <button
              onClick={() => {
                if (leafletMapRef.current && userLocation) {
                  leafletMapRef.current.setView([userLocation.lat, userLocation.lng], 13);
                }
              }}
              className="p-1.5 rounded-lg bg-slate-900/90 text-slate-200 hover:text-white border border-slate-700/80 shadow-md backdrop-blur-md"
              title="Recenter to GPS"
            >
              <Navigation className="w-3.5 h-3.5 text-blue-400" />
            </button>
          )}
        </div>
      </div>

      {/* Auth/Notice Alert if fallback happened */}
      {statusNotice && (
        <div className="absolute top-12 left-2 right-2 z-[999] bg-amber-950/95 border border-amber-500/50 rounded-xl p-2.5 shadow-xl backdrop-blur-md">
          <div className="flex items-start justify-between gap-2">
            <div className="flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div className="text-[11px] text-amber-200 leading-snug">
                <span className="font-bold text-white block mb-0.5">Google Maps Mode Notice</span>
                {statusNotice}
              </div>
            </div>
            <button
              onClick={() => setStatusNotice(null)}
              className="text-amber-400 hover:text-white text-xs px-1.5 py-0.5 rounded cursor-pointer"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Primary Map Canvas */}
      <div ref={containerRef} className={`w-full ${heightClass} z-0 bg-slate-950`} />

      {/* Bottom Map Legend */}
      <div className="absolute bottom-2 left-2 z-[1000] bg-slate-900/90 backdrop-blur-md px-2.5 py-1.5 rounded-xl border border-slate-700 text-[10px] text-slate-300 flex flex-wrap items-center gap-3 shadow-lg">
        <div className="flex items-center gap-1">
          <span className="w-2.5 h-2.5 rounded-full bg-blue-500"></span>
          <span>You</span>
        </div>
        {activeOverlay === "Traffic Density" ? (
          <>
            <div className="flex items-center gap-1">
              <span className="w-3 h-1.5 rounded-full bg-red-500"></span>
              <span>Heavy (&lt;15 km/h)</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="w-3 h-1.5 rounded-full bg-amber-500"></span>
              <span>Slow (15–35 km/h)</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="w-3 h-1.5 rounded-full bg-emerald-500"></span>
              <span>Free Flow (&gt;45 km/h)</span>
            </div>
          </>
        ) : activeOverlay === "Relief Centers" ? (
          <>
            <div className="flex items-center gap-1">
              <span className="w-3.5 h-3.5 rounded bg-emerald-600 text-white flex items-center justify-center text-[8px] font-black">
                ✚
              </span>
              <span>NDRF / SDMA Relief Camp</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-full border border-emerald-400 bg-emerald-500/30"></span>
              <span>Safe Triage Perimeter</span>
            </div>
          </>
        ) : (
          <>
            <div className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-full border border-red-400 bg-red-500/40"></span>
              <span>Critical Blast Zone</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-full border border-orange-400 bg-orange-500/40"></span>
              <span>High Hazard Buffer</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
              <span>Relief Route</span>
            </div>
          </>
        )}
      </div>

      {/* Key Input Modal */}
      {showKeyModal && (
        <KeyModal
          manualKeyInput={manualKeyInput}
          setManualKeyInput={setManualKeyInput}
          keyError={keyError}
          setKeyError={setKeyError}
          onSave={handleSaveKey}
          onClose={() => {
            setShowKeyModal(false);
            setKeyError(null);
          }}
        />
      )}
    </div>
  );
};

// Modal for Google Maps Platform Key setup & Demo Key link
const KeyModal: React.FC<{
  manualKeyInput: string;
  setManualKeyInput: (v: string) => void;
  keyError: string | null;
  setKeyError: (err: string | null) => void;
  onSave: (k: string) => void;
  onClose: () => void;
}> = ({ manualKeyInput, setManualKeyInput, keyError, setKeyError, onSave, onClose }) => {
  return (
    <div className="fixed inset-0 z-[2000] bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl p-5 max-w-md w-full text-slate-200 shadow-2xl space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-orange-500/10 text-orange-400">
              <MapIcon className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-white">Google Maps Platform Setup</h3>
              <p className="text-[11px] text-slate-400">Advanced 3D, Satellite, & Disaster Corridors</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white text-sm p-1 rounded-lg hover:bg-slate-800 cursor-pointer"
          >
            ✕
          </button>
        </div>

        <div className="bg-slate-800/80 rounded-xl p-3 border border-slate-700 space-y-2 text-xs text-slate-300">
          <div className="flex items-center justify-between">
            <span className="font-bold text-white text-[11px]">Free Instant Prototyping:</span>
            <span className="px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 text-[10px] font-bold">
              No Billing Required
            </span>
          </div>
          <p className="text-[11px] text-slate-400 leading-relaxed">
            You can get a free Google Maps Demo Key in seconds with no credit card required:
          </p>
          <a
            href="https://mapsplatform.google.com/maps-demo-key?utm_campaign=gmp_mcp_codeassist_v1_aistudio"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-orange-600 hover:bg-orange-500 text-white font-bold text-xs rounded-lg transition shadow-sm"
          >
            <span>Get Free Google Maps Demo Key</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>

        <div>
          <label className="block text-xs font-bold text-slate-300 mb-1.5">
            Enter Google Maps API Key:
          </label>
          <input
            type="text"
            value={manualKeyInput}
            onChange={(e) => {
              setManualKeyInput(e.target.value);
              if (keyError) setKeyError(null);
            }}
            placeholder="AIzaSy... or Demo Key"
            className="w-full px-3 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-orange-500 font-mono"
          />
          {keyError && (
            <p className="text-[11px] text-rose-400 mt-1.5 flex items-center gap-1 font-medium">
              <AlertTriangle className="w-3 h-3 shrink-0" />
              <span>{keyError}</span>
            </p>
          )}
          <p className="text-[10px] text-slate-400 mt-1">
            Keys can also be configured permanently via <code className="text-orange-300 font-mono">GOOGLE_MAPS_API_KEY</code> or <code className="text-orange-300 font-mono">VITE_GOOGLE_MAPS_API_KEY</code>.
          </p>
        </div>

        <div className="flex items-center gap-2 pt-1">
          <button
            onClick={() => onSave(manualKeyInput)}
            disabled={!manualKeyInput.trim()}
            className="flex-1 py-2.5 bg-orange-600 hover:bg-orange-500 disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold text-xs rounded-xl transition-colors shadow-lg cursor-pointer"
          >
            Activate Google Maps
          </button>
          <button
            onClick={onClose}
            className="px-4 py-2.5 bg-slate-800 hover:bg-slate-750 text-slate-300 text-xs rounded-xl font-medium cursor-pointer"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};
