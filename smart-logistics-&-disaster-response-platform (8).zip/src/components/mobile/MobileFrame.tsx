import React from "react";
import { ScreenId, UserRole } from "../../types";
import { useLanguage } from "../../context/LanguageContext";
import {
  Home,
  MapPin,
  Bell,
  ArrowLeft,
  User,
  AlertTriangle,
  AlertOctagon,
  Radio,
  Wifi,
  Truck,
} from "lucide-react";

interface MobileFrameProps {
  currentScreen: ScreenId;
  onNavigate: (screen: ScreenId) => void;
  currentRole: UserRole;
  children: React.ReactNode;
  activeAlertsCount: number;
}

export const MobileFrame: React.FC<MobileFrameProps> = ({
  currentScreen,
  onNavigate,
  currentRole,
  children,
  activeAlertsCount,
}) => {
  const { t } = useLanguage();

  const isBookingActive =
    currentScreen === "book_transport" ||
    currentScreen === "booking_confirmation" ||
    currentScreen === "booking_tracking" ||
    currentScreen === "driver_dashboard";

  const isReportActive =
    currentScreen === "report" || currentScreen === "voice_report" || currentScreen === "ai_analysis";

  return (
    <div className="flex items-center justify-center p-0 sm:p-4 w-full max-w-lg mx-auto">
      {/* Mobile Device Frame */}
      <div className="relative w-full max-w-[430px] sm:aspect-[9/19.2] min-h-[720px] max-h-[920px] h-[calc(100vh-80px)] bg-[#050816] rounded-2xl sm:rounded-[46px] p-2 sm:p-3 shadow-[0_25px_70px_-15px_rgba(37,99,235,0.28)] sm:border-[6px] sm:border-[#0F172A] ring-1 ring-white/[0.12] flex flex-col overflow-hidden transition-all">
        
        {/* Dynamic Island / Status Bar */}
        <div className="w-full pt-1.5 pb-2 px-5 flex items-center justify-between text-[11px] text-slate-400 z-30 select-none">
          <span className="font-bold font-mono text-white tracking-tight">09:41</span>
          
          {/* Dynamic Island Capsule */}
          <div className="w-28 h-5.5 bg-black/95 rounded-full flex items-center justify-center gap-2 border border-white/[0.1] shadow-inner px-2.5">
            <span className="w-2 h-2 rounded-full bg-[#10B981] animate-pulse shadow-[0_0_8px_#10B981]" />
            <span className="text-[9px] font-extrabold font-mono text-slate-200 tracking-wider">GPS LIVE</span>
          </div>

          <div className="flex items-center gap-1.5 text-[10px] text-slate-200 font-mono">
            <Wifi className="w-3.5 h-3.5 text-[#06B6D4]" />
            <span className="font-bold">5G</span>
            <div className="w-4.5 h-2.5 border border-slate-400/80 rounded-xs p-0.5 flex items-center">
              <div className="w-3 h-1.5 bg-[#10B981] rounded-2xs" />
            </div>
          </div>
        </div>

        {/* Mobile Header Bar with Back Button & Screen Title */}
        {currentScreen !== "emergency" && (
          <div className="px-4 py-2.5 flex items-center justify-between border-b border-white/[0.08] bg-[#0B1126]/80 backdrop-blur-xl z-20">
            <div className="flex items-center gap-2.5 min-w-0">
              {currentScreen !== "home" && currentScreen !== "splash" && (
                <button
                  onClick={() => onNavigate("home")}
                  className="p-2 rounded-xl bg-white/[0.06] hover:bg-white/[0.12] border border-white/[0.08] text-slate-200 hover:text-white transition-all duration-200 active:scale-95 cursor-pointer flex-shrink-0"
                  title="Back to Dashboard"
                >
                  <ArrowLeft className="w-4 h-4" />
                </button>
              )}
              <div className="min-w-0">
                <span className="text-sm font-extrabold text-white capitalize truncate block tracking-tight">
                  {currentScreen === "home"
                    ? "Situation Command"
                    : currentScreen === "report" || currentScreen === "voice_report"
                    ? "Incident Report"
                    : currentScreen === "live_map"
                    ? "Live Hazard Map"
                    : currentScreen === "smart_route"
                    ? "Safe Route Bypass"
                    : currentScreen === "alerts"
                    ? "Disaster Alerts"
                    : currentScreen === "profile"
                    ? "Profile & Status"
                    : currentScreen.replace(/_/g, " ")}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2 flex-shrink-0">
              <button
                onClick={() => onNavigate("alerts")}
                className="relative p-2 rounded-xl bg-white/[0.06] hover:bg-white/[0.12] border border-white/[0.08] text-slate-200 hover:text-white transition-all duration-200 active:scale-95 cursor-pointer"
                title="Disaster Broadcasts"
              >
                <Bell className="w-4 h-4 text-[#F59E0B]" />
                {activeAlertsCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-[#EF4444] text-[9px] font-black font-mono text-white flex items-center justify-center ring-2 ring-[#050816] animate-pulse">
                    {activeAlertsCount}
                  </span>
                )}
              </button>
              <button
                onClick={() => onNavigate("profile")}
                className="p-2 rounded-xl bg-white/[0.06] hover:bg-white/[0.12] border border-white/[0.08] text-slate-200 hover:text-white transition-all duration-200 active:scale-95 cursor-pointer"
                title="Responder Profile"
              >
                <User className="w-4 h-4 text-[#06B6D4]" />
              </button>
            </div>
          </div>
        )}

        {/* Screen Content Scrollable Container */}
        <div className="relative flex-1 min-h-0">
          <div className="h-full overflow-y-auto overflow-x-hidden bg-[#050816]">
            {children}
          </div>

          {/* Floating Global Emergency SOS Button */}
          {currentScreen !== "emergency" && (
            <button
              id="global-floating-sos-btn"
              onClick={() => onNavigate("emergency")}
              aria-label="Trigger Emergency SOS"
              className="absolute bottom-4 right-4 z-40 px-4 py-2.5 rounded-full bg-gradient-to-r from-[#EF4444] via-rose-600 to-red-700 hover:from-red-500 hover:to-rose-500 text-white font-black text-xs flex items-center gap-1.5 ring-2 ring-red-400/40 transition-all duration-200 hover:scale-105 active:scale-95 cursor-pointer vrq-sos-pulse"
              title="Emergency SOS Green Corridor"
            >
              <AlertOctagon className="w-4 h-4 text-white" />
              <span className="tracking-wider font-extrabold">SOS</span>
            </button>
          )}
        </div>

        {/* Modern Bottom Navigation Bar */}
        <nav
          id="mobile-bottom-navigation"
          aria-label="Main Navigation"
          className="px-2 py-2 border-t border-white/[0.08] bg-[#070B1E]/95 backdrop-blur-2xl grid grid-cols-5 gap-1 text-[10px] text-slate-400 z-30 shadow-[0_-8px_24px_rgba(2,6,23,0.65)]"
        >
          {/* 1. Home */}
          <button
            id="nav-tab-home"
            onClick={() => onNavigate("home")}
            className={`relative min-h-[48px] flex flex-col items-center justify-center gap-1 transition-all duration-200 rounded-xl px-1 cursor-pointer active:scale-95 ${
              currentScreen === "home"
                ? "text-white font-bold bg-gradient-to-b from-[#2563EB]/25 to-[#06B6D4]/10 border border-[#2563EB]/40 shadow-[0_0_16px_rgba(37,99,235,0.25)]"
                : "text-slate-400 hover:text-slate-200 hover:bg-white/[0.04]"
            }`}
          >
            {currentScreen === "home" && (
              <span className="absolute top-0 inset-x-4 h-0.5 rounded-full bg-gradient-to-r from-[#2563EB] to-[#06B6D4]" />
            )}
            <Home className={`w-[18px] h-[18px] ${currentScreen === "home" ? "text-[#06B6D4]" : ""}`} />
            <span className="tracking-tight text-[10px] leading-none">{t.home}</span>
          </button>

          {/* 2. Map */}
          <button
            id="nav-tab-map"
            onClick={() => onNavigate("live_map")}
            className={`relative min-h-[48px] flex flex-col items-center justify-center gap-1 transition-all duration-200 rounded-xl px-1 cursor-pointer active:scale-95 ${
              currentScreen === "live_map"
                ? "text-white font-bold bg-gradient-to-b from-[#2563EB]/25 to-[#06B6D4]/10 border border-[#2563EB]/40 shadow-[0_0_16px_rgba(37,99,235,0.25)]"
                : "text-slate-400 hover:text-slate-200 hover:bg-white/[0.04]"
            }`}
          >
            {currentScreen === "live_map" && (
              <span className="absolute top-0 inset-x-4 h-0.5 rounded-full bg-gradient-to-r from-[#2563EB] to-[#06B6D4]" />
            )}
            <MapPin className={`w-[18px] h-[18px] ${currentScreen === "live_map" ? "text-[#06B6D4]" : ""}`} />
            <span className="tracking-tight text-[10px] leading-none">{t.map}</span>
          </button>

          {/* 3. Report Hazard / Incident */}
          <button
            id="nav-tab-report"
            onClick={() => onNavigate("report")}
            className={`relative min-h-[48px] flex flex-col items-center justify-center gap-1 transition-all duration-200 rounded-xl px-1 cursor-pointer active:scale-95 ${
              isReportActive
                ? "text-white font-bold bg-gradient-to-b from-[#F59E0B]/25 to-[#F59E0B]/5 border border-[#F59E0B]/40 shadow-[0_0_16px_rgba(245,158,11,0.25)]"
                : "text-slate-400 hover:text-slate-200 hover:bg-white/[0.04]"
            }`}
          >
            {isReportActive && (
              <span className="absolute top-0 inset-x-4 h-0.5 rounded-full bg-[#F59E0B]" />
            )}
            <AlertTriangle className={`w-[18px] h-[18px] ${isReportActive ? "text-[#F59E0B]" : ""}`} />
            <span className="tracking-tight text-[10px] leading-none">Report</span>
          </button>

          {/* 4. Booking & Relief Transport */}
          <button
            id="nav-tab-fleet"
            onClick={() => onNavigate(currentRole === "driver" ? "driver_dashboard" : "book_transport")}
            className={`relative min-h-[48px] flex flex-col items-center justify-center gap-1 transition-all duration-200 rounded-xl px-1 cursor-pointer active:scale-95 ${
              isBookingActive
                ? "text-white font-bold bg-gradient-to-b from-[#06B6D4]/25 to-[#2563EB]/10 border border-[#06B6D4]/40 shadow-[0_0_16px_rgba(6,182,212,0.25)]"
                : "text-slate-400 hover:text-slate-200 hover:bg-white/[0.04]"
            }`}
          >
            {isBookingActive && (
              <span className="absolute top-0 inset-x-4 h-0.5 rounded-full bg-[#06B6D4]" />
            )}
            <Truck className={`w-[18px] h-[18px] ${isBookingActive ? "text-[#06B6D4]" : ""}`} />
            <span className="tracking-tight text-[10px] leading-none">{t.booking || "Booking"}</span>
          </button>

          {/* 5. Alerts */}
          <button
            id="nav-tab-alerts"
            onClick={() => onNavigate("alerts")}
            className={`relative min-h-[48px] flex flex-col items-center justify-center gap-1 transition-all duration-200 rounded-xl px-1 cursor-pointer active:scale-95 ${
              currentScreen === "alerts"
                ? "text-white font-bold bg-gradient-to-b from-[#2563EB]/25 to-[#06B6D4]/10 border border-[#2563EB]/40 shadow-[0_0_16px_rgba(37,99,235,0.25)]"
                : "text-slate-400 hover:text-slate-200 hover:bg-white/[0.04]"
            }`}
          >
            {currentScreen === "alerts" && (
              <span className="absolute top-0 inset-x-4 h-0.5 rounded-full bg-gradient-to-r from-[#2563EB] to-[#06B6D4]" />
            )}
            <div className="relative">
              <Bell className={`w-[18px] h-[18px] ${currentScreen === "alerts" ? "text-[#06B6D4]" : ""}`} />
              {activeAlertsCount > 0 && (
                <span className="absolute -top-1.5 -right-2 px-1 min-w-[15px] h-[15px] rounded-full bg-[#EF4444] text-[8px] font-black font-mono text-white flex items-center justify-center ring-2 ring-[#070B1E] animate-pulse">
                  {activeAlertsCount}
                </span>
              )}
            </div>
            <span className="tracking-tight text-[10px] leading-none">{t.alerts}</span>
          </button>
        </nav>

        {/* Device Home Indicator Bar */}
        <div className="w-28 h-1 bg-slate-700/60 rounded-full mx-auto my-1 flex-shrink-0" />
      </div>
    </div>
  );
};
