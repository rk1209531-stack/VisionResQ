import React from "react";
import { RealWeatherData } from "../../hooks/useRealWeather";
import {
  CloudRain,
  Wind,
  Eye,
  AlertTriangle,
  Clock,
  MapPin,
  RefreshCw,
  ShieldAlert,
  Sun,
  CloudLightning,
} from "lucide-react";

interface RealWeatherWidgetProps {
  weather: RealWeatherData | null;
  isLoading: boolean;
  error: string | null;
  onRefresh?: () => void;
  compact?: boolean;
}

export const RealWeatherWidget: React.FC<RealWeatherWidgetProps> = ({
  weather,
  isLoading,
  error,
  onRefresh,
  compact = false,
}) => {
  if (isLoading && !weather) {
    return (
      <div className="p-4 vrq-card text-slate-300 flex items-center justify-center gap-2 text-xs">
        <RefreshCw className="w-4 h-4 animate-spin text-[#06B6D4]" />
        <span>Fetching live meteorological observations...</span>
      </div>
    );
  }

  // Explicit Prompt Mandate: "If the weather API fails, show: 'Weather data temporarily unavailable.' Do NOT invent weather values."
  if (error || !weather) {
    return (
      <div className="p-4 rounded-2xl bg-[#F59E0B]/10 border border-[#F59E0B]/30 text-amber-200 flex items-start gap-2.5 text-xs">
        <AlertTriangle className="w-4 h-4 text-[#F59E0B] shrink-0 mt-0.5" />
        <div className="flex-1">
          <div className="font-bold">Weather data temporarily unavailable.</div>
          <div className="text-[11px] text-amber-200/80 mt-0.5">
            Unable to fetch real-time satellite radar telemetry for coordinates. Risk calculator will operate on ground sensor baseline.
          </div>
        </div>
        {onRefresh && (
          <button
            onClick={onRefresh}
            className="p-1.5 rounded-xl bg-[#F59E0B]/20 hover:bg-[#F59E0B]/30 text-amber-200 transition-all active:scale-95 cursor-pointer"
            title="Retry Weather Query"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        )}
      </div>
    );
  }

  const isHighRisk = weather.weatherRisk === "High";
  const isMedRisk = weather.weatherRisk === "Medium";

  const riskBadgeBg = isHighRisk
    ? "bg-[#EF4444]/20 text-red-300 border-[#EF4444]/40"
    : isMedRisk
    ? "bg-[#F59E0B]/20 text-amber-300 border-[#F59E0B]/40"
    : "bg-[#10B981]/20 text-emerald-300 border-[#10B981]/40";

  if (compact) {
    return (
      <div className="flex items-center justify-between px-3.5 py-2.5 vrq-card text-xs">
        <div className="flex items-center gap-2">
          {isHighRisk ? (
            <CloudLightning className="w-4 h-4 text-[#EF4444]" />
          ) : weather.rainfall > 0 ? (
            <CloudRain className="w-4 h-4 text-[#06B6D4]" />
          ) : (
            <Sun className="w-4 h-4 text-[#F59E0B]" />
          )}
          <div>
            <span className="font-bold font-mono text-white">{weather.temperature}°C</span>
            <span className="text-slate-300 ml-2 font-medium">{weather.weatherCondition}</span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className={`text-[10px] font-bold font-mono px-2.5 py-0.5 rounded-full border ${riskBadgeBg}`}>
            +{weather.weatherRiskScoreDelta}% Weather Risk
          </span>
          {onRefresh && (
            <button
              onClick={onRefresh}
              className="p-1 rounded-lg bg-white/[0.05] hover:bg-white/[0.1] text-slate-300 hover:text-white transition cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? "animate-spin" : ""}`} />
            </button>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="vrq-card p-4 text-slate-200">
      {/* Header with mandatory metadata */}
      <div className="flex items-start justify-between gap-2 mb-3 pb-3 border-b border-white/[0.08]">
        <div>
          <div className="flex items-center gap-1.5 text-xs text-slate-300 font-medium">
            <MapPin className="w-3.5 h-3.5 text-[#06B6D4] shrink-0" />
            <span className="font-bold text-white truncate max-w-[200px]">{weather.location}</span>
          </div>
          <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-1 font-mono">
            <span className="flex items-center gap-1">
              <Clock className="w-3 h-3 text-slate-500" />
              <span>Time: {weather.currentTime}</span>
            </span>
            <span>·</span>
            <span>Updated: {weather.lastUpdatedTime}</span>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <span className={`text-[10px] font-extrabold font-mono px-2.5 py-0.5 rounded-full border ${riskBadgeBg}`}>
            {weather.weatherRisk} Risk (+{weather.weatherRiskScoreDelta})
          </span>
          {onRefresh && (
            <button
              onClick={onRefresh}
              className="p-1.5 text-slate-400 hover:text-white rounded-xl bg-white/[0.05] hover:bg-white/[0.1] transition-all active:scale-95 cursor-pointer"
              title="Refresh Meteorological Telemetry"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? "animate-spin" : ""}`} />
            </button>
          )}
        </div>
      </div>

      {/* Primary Metrics Grid */}
      <div className="grid grid-cols-4 gap-2 mb-3">
        {/* Temp */}
        <div className="p-2.5 rounded-xl bg-[#050816]/70 border border-white/[0.08] flex flex-col items-center text-center">
          <span className="text-[10px] text-slate-400 font-medium">Temp</span>
          <span className="text-base font-extrabold font-mono text-white mt-0.5">{weather.temperature}°C</span>
          <span className="text-[9px] text-slate-400 truncate max-w-[65px]">{weather.weatherCondition}</span>
        </div>

        {/* Rain Probability / Rainfall */}
        <div className="p-2.5 rounded-xl bg-[#050816]/70 border border-white/[0.08] flex flex-col items-center text-center">
          <span className="text-[10px] text-slate-400 font-medium">Rain Prob</span>
          <span className="text-base font-extrabold font-mono text-[#06B6D4] mt-0.5">{weather.rainProbability}%</span>
          <span className="text-[9px] text-slate-400 font-mono">{weather.rainfall} mm/hr</span>
        </div>

        {/* Wind Speed */}
        <div className="p-2.5 rounded-xl bg-[#050816]/70 border border-white/[0.08] flex flex-col items-center text-center">
          <span className="text-[10px] text-slate-400 font-medium">Wind</span>
          <span className="text-base font-extrabold font-mono text-[#F59E0B] mt-0.5">{weather.windSpeed}</span>
          <span className="text-[9px] text-slate-400">km/h</span>
        </div>

        {/* Visibility */}
        <div className="p-2.5 rounded-xl bg-[#050816]/70 border border-white/[0.08] flex flex-col items-center text-center">
          <span className="text-[10px] text-slate-400 font-medium">Visibility</span>
          <span className="text-base font-extrabold font-mono text-[#10B981] mt-0.5">{weather.visibility}</span>
          <span className="text-[9px] text-slate-400">km range</span>
        </div>
      </div>

      {/* Active Weather Advisory */}
      {weather.weatherAlert && (
        <div className="p-3 rounded-xl bg-[#050816]/80 border border-white/[0.08] text-[11px] flex items-start gap-2 mb-2.5">
          <ShieldAlert className="w-4 h-4 text-[#F59E0B] shrink-0 mt-0.5" />
          <div className="text-slate-200 leading-relaxed font-medium">
            {weather.weatherAlert}
          </div>
        </div>
      )}

      {/* Mandatory Data Source */}
      <div className="text-[10px] text-slate-400 flex items-center justify-between pt-2 border-t border-white/[0.06]">
        <span className="truncate">Source: {weather.dataSource}</span>
        <span className="text-[#10B981] font-bold shrink-0 ml-2">● Real Live API</span>
      </div>
    </div>
  );
};
