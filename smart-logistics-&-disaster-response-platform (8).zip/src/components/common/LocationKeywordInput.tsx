import React, { useState, useRef, useEffect, useCallback } from "react";
import { LocationPreset } from "../../transportData";
import {
  searchPlacesAutocomplete,
  getPlaceLocationDetails,
  geocodeLocation,
  getCurrentDeviceLocation,
  PlaceSuggestion,
} from "../../services/googleMapsService";
import {
  MapPin,
  Search,
  X,
  Crosshair,
  AlertTriangle,
  Check,
  ShieldCheck,
  Loader2,
  Globe2,
} from "lucide-react";

interface LocationKeywordInputProps {
  id?: string;
  label: string;
  dotColor?: "emerald" | "orange" | "cyan" | "rose";
  value: string;
  selectedPreset?: LocationPreset;
  onSelectLocation: (preset: LocationPreset) => void;
  placeholder?: string;
  presets?: LocationPreset[];
  onUseGps?: () => void;
  helperText?: string;
}

export const LocationKeywordInput: React.FC<LocationKeywordInputProps> = ({
  id,
  label,
  dotColor = "emerald",
  value,
  selectedPreset,
  onSelectLocation,
  placeholder = "Search any city, road, or landmark in India...",
  presets = [],
  onUseGps,
  helperText,
}) => {
  const [query, setQuery] = useState(value);
  const [isOpen, setIsOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [gpsLoading, setGpsLoading] = useState(false);
  const [googleSuggestions, setGoogleSuggestions] = useState<PlaceSuggestion[]>([]);
  const [highlightIndex, setHighlightIndex] = useState(0);

  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const debounceTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Synchronize internal query with external value prop
  useEffect(() => {
    setQuery(value);
  }, [value]);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Live Google Places Autocomplete search with debounce
  useEffect(() => {
    const trimmed = query.trim();

    // If query is empty or same as selected preset name, clear live suggestions
    if (!trimmed || (selectedPreset && trimmed === selectedPreset.name)) {
      setGoogleSuggestions([]);
      setIsLoading(false);
      return;
    }

    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current);
    }

    setIsLoading(true);
    debounceTimerRef.current = setTimeout(async () => {
      try {
        const results = await searchPlacesAutocomplete(trimmed);
        setGoogleSuggestions(results);
      } catch (err) {
        console.error("Autocomplete fetch error:", err);
      } finally {
        setIsLoading(false);
      }
    }, 280);

    return () => {
      if (debounceTimerRef.current) {
        clearTimeout(debounceTimerRef.current);
      }
    };
  }, [query, selectedPreset]);

  // Handle selecting a Google Places suggestion
  const handleSelectGooglePlace = async (suggestion: PlaceSuggestion) => {
    setIsLoading(true);
    try {
      const details = await getPlaceLocationDetails(suggestion.placeId);
      if (details) {
        const newPreset: LocationPreset = {
          name: details.name,
          region: details.region || "India",
          lat: details.lat,
          lng: details.lng,
        };
        setQuery(details.name);
        onSelectLocation(newPreset);
        setIsOpen(false);
      } else {
        // Fallback to geocoding the full text
        const geo = await geocodeLocation(suggestion.fullText);
        if (geo) {
          const newPreset: LocationPreset = {
            name: geo.name,
            region: geo.region || "India",
            lat: geo.lat,
            lng: geo.lng,
          };
          setQuery(geo.name);
          onSelectLocation(newPreset);
          setIsOpen(false);
        }
      }
    } catch (err) {
      console.error("Failed to resolve place coordinates:", err);
    } finally {
      setIsLoading(false);
    }
  };

  // Handle selecting a quick preset location
  const handleSelectPreset = (preset: LocationPreset) => {
    setQuery(preset.name);
    onSelectLocation(preset);
    setIsOpen(false);
  };

  // Handle typing custom query & pressing Enter
  const handleCustomGeocode = async () => {
    const clean = query.trim();
    if (!clean) return;

    setIsLoading(true);
    try {
      const geo = await geocodeLocation(clean);
      if (geo) {
        const newPreset: LocationPreset = {
          name: geo.name,
          region: geo.region || "India",
          lat: geo.lat,
          lng: geo.lng,
        };
        setQuery(geo.name);
        onSelectLocation(newPreset);
        setIsOpen(false);
      }
    } catch (err) {
      console.error("Geocode error on custom query:", err);
    } finally {
      setIsLoading(false);
    }
  };

  // Handle Live Device GPS Button
  const handleTriggerGps = async () => {
    if (onUseGps) {
      onUseGps();
      return;
    }

    setGpsLoading(true);
    try {
      const place = await getCurrentDeviceLocation();
      const newPreset: LocationPreset = {
        name: place.name,
        region: place.region || "Current Device GPS",
        lat: place.lat,
        lng: place.lng,
      };
      setQuery(place.name);
      onSelectLocation(newPreset);
      setIsOpen(false);
    } catch (err: any) {
      console.warn("GPS acquisition failed:", err);
    } finally {
      setGpsLoading(false);
    }
  };

  // Keyboard navigation
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (!isOpen && (e.key === "ArrowDown" || e.key === "Enter")) {
      setIsOpen(true);
      return;
    }

    if (e.key === "Enter") {
      e.preventDefault();
      if (googleSuggestions.length > 0) {
        handleSelectGooglePlace(googleSuggestions[highlightIndex] || googleSuggestions[0]);
      } else {
        handleCustomGeocode();
      }
    } else if (e.key === "Escape") {
      setIsOpen(false);
    }
  };

  const dotClass =
    dotColor === "emerald"
      ? "bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.6)]"
      : dotColor === "orange"
      ? "bg-orange-500 shadow-[0_0_8px_rgba(249,115,22,0.6)]"
      : dotColor === "cyan"
      ? "bg-cyan-400 shadow-[0_0_8px_rgba(34,211,238,0.6)]"
      : "bg-rose-500 shadow-[0_0_8px_rgba(244,63,94,0.6)]";

  return (
    <div ref={containerRef} className="relative space-y-1.5">
      {/* Header Label & GPS Action */}
      <div className="flex items-center justify-between">
        <label className="text-[11px] font-bold text-slate-300 flex items-center gap-2">
          <span className={`w-2 h-2 rounded-full ${dotClass}`} />
          <span>{label}</span>
        </label>
        <button
          type="button"
          onClick={handleTriggerGps}
          disabled={gpsLoading}
          className="text-[11px] text-[#06B6D4] hover:text-cyan-300 flex items-center gap-1 font-semibold cursor-pointer transition-colors disabled:opacity-50"
          title="Use real device GPS location"
        >
          {gpsLoading ? (
            <Loader2 className="w-3.5 h-3.5 animate-spin text-[#06B6D4]" />
          ) : (
            <Crosshair className="w-3.5 h-3.5" />
          )}
          <span>{gpsLoading ? "Acquiring GPS..." : "Use Device GPS"}</span>
        </button>
      </div>

      {/* Input Box with live Search Indicator */}
      <div className="relative flex items-center">
        <div className="absolute left-3.5 text-slate-400 pointer-events-none">
          {isLoading ? (
            <Loader2 className="w-4 h-4 text-[#06B6D4] animate-spin" />
          ) : (
            <Search className="w-4 h-4 text-slate-400" />
          )}
        </div>

        <input
          ref={inputRef}
          id={id}
          type="text"
          value={query}
          onFocus={() => {
            setIsOpen(true);
            setHighlightIndex(0);
          }}
          onChange={(e) => {
            setQuery(e.target.value);
            setIsOpen(true);
            setHighlightIndex(0);
          }}
          onKeyDown={handleKeyDown}
          placeholder={placeholder}
          autoComplete="off"
          className="w-full bg-[#050816]/90 border border-white/[0.1] focus:border-[#06B6D4] focus:ring-2 focus:ring-[#06B6D4]/20 rounded-xl pl-10 pr-9 py-2.5 text-xs font-medium text-white placeholder-slate-500 focus:outline-none transition-all shadow-inner"
        />

        {query && (
          <button
            type="button"
            onClick={() => {
              setQuery("");
              inputRef.current?.focus();
              setIsOpen(true);
            }}
            className="absolute right-2.5 p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/[0.08] transition cursor-pointer"
            title="Clear text"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* Autocomplete Dropdown: Google Places API Live Suggestions */}
      {isOpen && (
        <div className="absolute left-0 right-0 top-full mt-2 z-[1200] bg-[#0B1126]/98 border border-white/[0.12] rounded-2xl shadow-2xl backdrop-blur-xl overflow-hidden max-h-72 overflow-y-auto">
          {/* Header indicator */}
          <div className="px-3.5 py-2 bg-[#050816]/90 border-b border-white/[0.08] flex items-center justify-between text-[10px] text-slate-400">
            <span className="font-semibold flex items-center gap-1.5 text-slate-300">
              <Globe2 className="w-3.5 h-3.5 text-[#06B6D4]" />
              <span>
                {googleSuggestions.length > 0
                  ? "Google Places API (Live India Search)"
                  : query.trim()
                  ? `Searching "${query}" via Google...`
                  : "Quick Suggested Relief Centers"}
              </span>
            </span>
            <span className="text-[10px] text-[#10B981] font-mono font-bold">Google Connected</span>
          </div>

          <div className="py-1">
            {/* Live Google Places API Results */}
            {googleSuggestions.map((suggestion, idx) => {
              const isHighlighted = highlightIndex === idx;

              return (
                <button
                  key={suggestion.placeId}
                  type="button"
                  onClick={() => handleSelectGooglePlace(suggestion)}
                  onMouseEnter={() => setHighlightIndex(idx)}
                  className={`w-full px-3 py-2 text-left flex items-start justify-between gap-2 transition cursor-pointer border-b border-slate-800/40 last:border-b-0 ${
                    isHighlighted ? "bg-slate-800/90 text-white" : "text-slate-300 hover:bg-slate-800/50"
                  }`}
                >
                  <div className="flex items-start gap-2 min-w-0">
                    <MapPin className="w-3.5 h-3.5 mt-0.5 shrink-0 text-orange-400" />
                    <div className="min-w-0">
                      <div className="text-xs font-semibold text-white truncate">
                        {suggestion.mainText}
                      </div>
                      <div className="text-[10px] text-slate-400 truncate mt-0.5">
                        {suggestion.secondaryText || suggestion.fullText}
                      </div>
                    </div>
                  </div>
                  <span className="text-[9px] bg-slate-800 px-1.5 py-0.5 rounded text-slate-400 shrink-0">
                    Google Place
                  </span>
                </button>
              );
            })}

            {/* If user typed a query, offer to geocode custom query via Google Geocoding API */}
            {query.trim().length > 1 && (
              <button
                type="button"
                onClick={handleCustomGeocode}
                className="w-full px-3 py-2 text-left bg-orange-950/40 hover:bg-orange-900/50 border-t border-slate-800 text-orange-200 transition flex items-center justify-between cursor-pointer"
              >
                <div className="flex items-center gap-2">
                  <Search className="w-3.5 h-3.5 text-orange-400 shrink-0" />
                  <span className="text-xs font-semibold">
                    Geocode location &ldquo;{query.trim()}&rdquo; in India
                  </span>
                </div>
                <span className="text-[10px] bg-orange-500/20 text-orange-300 px-1.5 py-0.5 rounded font-mono">
                  Google Geocode
                </span>
              </button>
            )}

            {/* Quick Strategic Presets (shown when query is short) */}
            {googleSuggestions.length === 0 && presets.length > 0 && query.trim().length <= 1 && (
              <>
                <div className="px-3 py-1 text-[9px] uppercase tracking-wider text-slate-500 font-semibold bg-slate-950/50">
                  Quick Strategic Logistics Bases
                </div>
                {presets.slice(0, 6).map((preset, idx) => {
                  const isSelected = selectedPreset?.name === preset.name;
                  return (
                    <button
                      key={`preset-${preset.name}-${idx}`}
                      type="button"
                      onClick={() => handleSelectPreset(preset)}
                      className={`w-full px-3 py-2 text-left flex items-start justify-between gap-2 transition cursor-pointer hover:bg-slate-800/50 ${
                        isSelected ? "border-l-2 border-orange-500 bg-orange-950/20" : ""
                      }`}
                    >
                      <div className="flex items-start gap-2 min-w-0">
                        <MapPin className="w-3.5 h-3.5 mt-0.5 shrink-0 text-cyan-400" />
                        <div className="min-w-0">
                          <div className="text-xs font-semibold text-white truncate flex items-center gap-1.5">
                            <span>{preset.name}</span>
                            {isSelected && <Check className="w-3 h-3 text-orange-400 shrink-0" />}
                          </div>
                          <div className="text-[10px] text-slate-400 flex items-center gap-2 mt-0.5">
                            <span className="bg-slate-800 px-1.5 py-0.2 rounded text-slate-300 font-medium">
                              {preset.region}
                            </span>
                            <span className="font-mono text-[9px] text-slate-400">
                              {preset.lat.toFixed(3)}, {preset.lng.toFixed(3)}
                            </span>
                          </div>
                        </div>
                      </div>
                    </button>
                  );
                })}
              </>
            )}
          </div>
        </div>
      )}

      {helperText && <p className="text-[10px] text-slate-400">{helperText}</p>}
    </div>
  );
};
