import React from "react";
import { UserRole, ScreenId } from "../../types";
import { useLanguage } from "../../context/LanguageContext";
import {
  ShieldAlert,
  Wifi,
  WifiOff,
  Smartphone,
  Maximize2,
  FileCode2,
  Users,
  AlertOctagon,
  RefreshCw,
  Award,
  Sparkles,
  Database,
} from "lucide-react";

interface HeaderProps {
  currentRole: UserRole;
  onRoleChange: (role: UserRole) => void;
  isOnline: boolean;
  onToggleOnline: () => void;
  offlineCount: number;
  onSyncOffline?: () => void;
  viewMode?: "mobile" | "fullscreen" | "deliverables";
  onViewModeChange?: (mode: "mobile" | "fullscreen" | "deliverables") => void;
  activeScreen: ScreenId;
  onNavigate: (screen: ScreenId) => void;
  emergencyCount?: number;
  firebaseConnected?: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  currentRole,
  onRoleChange,
  isOnline,
  onToggleOnline,
  offlineCount = 0,
  onSyncOffline = () => {},
  viewMode = "mobile",
  onViewModeChange = (_mode: "mobile" | "fullscreen" | "deliverables") => {},
  activeScreen,
  onNavigate,
  emergencyCount = 0,
  firebaseConnected = true,
}) => {
  const { t } = useLanguage();

  return (
    <header className="sticky top-0 z-50 bg-[#050816]/85 backdrop-blur-2xl border-b border-white/[0.08] px-4 py-3 sm:px-6 transition-all shadow-[0_8px_30px_rgba(2,6,23,0.65)]">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        {/* Brand & Platform Identity */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-tr from-[#2563EB] via-blue-600 to-[#06B6D4] shadow-[0_0_20px_rgba(37,99,235,0.35)] text-white font-black ring-1 ring-white/20">
              <ShieldAlert className="w-5 h-5" />
              <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-[#10B981] border-2 border-[#050816]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-base sm:text-lg tracking-tight text-white">
                  VisionResQ
                </span>
                <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-[#2563EB]/15 text-[#06B6D4] border border-[#06B6D4]/25">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#06B6D4] animate-pulse" />
                  Live Command
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block font-medium">
                AI Disaster Logistics & Emergency Fleet Coordination
              </p>
            </div>
          </div>

          {/* Mobile direct trigger for Deliverables */}
          <div className="flex md:hidden items-center gap-2">
            <button
              onClick={() => onViewModeChange?.(viewMode === "deliverables" ? "mobile" : "deliverables")}
              className={`px-3 py-1.5 text-xs rounded-xl font-semibold transition-all duration-200 active:scale-95 flex items-center gap-1.5 ${
                viewMode === "deliverables"
                  ? "bg-[#F59E0B] text-slate-950 font-bold shadow-md shadow-[#F59E0B]/25"
                  : "bg-white/[0.05] border border-white/[0.08] text-slate-300 hover:bg-white/[0.1]"
              }`}
            >
              <Award className="w-3.5 h-3.5" />
              <span>Specs</span>
            </button>
          </div>
        </div>

        {/* Controls: Role Selector, Network Mode, View Mode, Emergency SOS */}
        <div className="flex flex-wrap items-center gap-2 sm:gap-3">
          {/* Executive Role Switcher (Segmented Control) */}
          <div className="flex items-center bg-[#0B1126]/90 border border-white/[0.08] rounded-xl p-1 text-xs shadow-inner">
            <span className="px-2.5 text-slate-400 text-[11px] hidden lg:inline-flex items-center gap-1.5 font-medium">
              <Users className="w-3.5 h-3.5 text-[#06B6D4]" />
              Role
            </span>
            {(
              [
                { id: "citizen", label: "Citizen" },
                { id: "driver", label: "Driver" },
                { id: "authority", label: "Authority" },
                { id: "emergency", label: "Emergency" },
              ] as const
            ).map((role) => (
              <button
                key={role.id}
                onClick={() => onRoleChange(role.id)}
                className={`px-3 py-1.5 rounded-lg transition-all duration-200 text-xs font-semibold cursor-pointer active:scale-95 ${
                  currentRole === role.id
                    ? "bg-gradient-to-r from-[#2563EB] to-[#06B6D4] text-white shadow-[0_2px_12px_rgba(37,99,235,0.4)]"
                    : "text-slate-400 hover:text-slate-100 hover:bg-white/[0.05]"
                }`}
              >
                {role.label}
              </button>
            ))}
          </div>

          {/* Cloud Database Status Pill */}
          <div
            title={firebaseConnected ? "Cloud Sync Active • Firestore Connected" : "Connecting to Cloud..."}
            className="hidden xl:flex items-center gap-2 px-3 py-1.5 rounded-xl text-[11px] font-semibold bg-[#0B1126]/85 border border-white/[0.08] text-slate-300"
          >
            <Database className="w-3.5 h-3.5 text-[#06B6D4]" />
            <span className="w-1.5 h-1.5 rounded-full bg-[#10B981] animate-pulse" />
            <span className="text-slate-300 font-medium">Cloud DB</span>
          </div>

          {/* Network Simulator (Online / Offline) */}
          <div className="flex items-center gap-2">
            <button
              onClick={onToggleOnline}
              title={isOnline ? "Simulate Disrupted/Offline Network" : "Restore Online Network Connection"}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all duration-200 active:scale-95 cursor-pointer ${
                isOnline
                  ? "bg-[#0B1126]/85 border-white/[0.08] text-slate-200 hover:bg-white/[0.08] hover:text-white"
                  : "bg-[#F59E0B]/15 border-[#F59E0B]/40 text-[#F59E0B] hover:bg-[#F59E0B]/25"
              }`}
            >
              {isOnline ? (
                <>
                  <Wifi className="w-3.5 h-3.5 text-[#10B981]" />
                  <span className="hidden sm:inline">Online</span>
                </>
              ) : (
                <>
                  <WifiOff className="w-3.5 h-3.5 text-[#F59E0B]" />
                  <span>Offline Mesh</span>
                </>
              )}
            </button>

            {/* Offline sync button when reports pending */}
            {offlineCount > 0 && (
              <button
                onClick={onSyncOffline}
                title="Sync offline reports to cloud"
                className="flex items-center gap-1.5 px-3 py-1.5 bg-[#F59E0B] hover:bg-amber-400 text-slate-950 rounded-xl text-xs font-bold transition-all duration-200 active:scale-95 shadow-md shadow-[#F59E0B]/20 animate-pulse cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Sync ({offlineCount})</span>
              </button>
            )}
          </div>

          {/* Emergency SOS Shortcut Button */}
          <button
            onClick={() => onNavigate("emergency")}
            className="relative flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-black bg-gradient-to-r from-[#EF4444] to-rose-600 hover:from-red-500 hover:to-rose-500 text-white shadow-[0_4px_16px_rgba(239,68,68,0.4)] transition-all duration-200 active:scale-95 cursor-pointer"
          >
            <AlertOctagon className="w-3.5 h-3.5 animate-pulse" />
            <span>SOS</span>
            {emergencyCount > 0 && (
              <span className="w-4 h-4 rounded-full bg-white text-red-700 text-[10px] font-black flex items-center justify-center font-mono">
                {emergencyCount}
              </span>
            )}
          </button>

          {/* View Mode Switcher */}
          <div className="hidden md:flex items-center bg-[#0B1126]/90 border border-white/[0.08] rounded-xl p-1 text-xs shadow-inner">
            <button
              onClick={() => onViewModeChange?.("mobile")}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all duration-200 font-semibold text-xs cursor-pointer ${
                viewMode === "mobile"
                  ? "bg-white/[0.1] text-white shadow-sm"
                  : "text-slate-400 hover:text-slate-200"
              }`}
              title="Mobile Device Simulation View"
            >
              <Smartphone className="w-3.5 h-3.5 text-[#06B6D4]" />
              <span>Mobile</span>
            </button>
            <button
              onClick={() => onViewModeChange?.("fullscreen")}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all duration-200 font-semibold text-xs cursor-pointer ${
                viewMode === "fullscreen"
                  ? "bg-white/[0.1] text-white shadow-sm"
                  : "text-slate-400 hover:text-slate-200"
              }`}
              title="Expanded Command Center View"
            >
              <Maximize2 className="w-3.5 h-3.5 text-[#2563EB]" />
              <span>Command Deck</span>
            </button>
            <button
              onClick={() => onViewModeChange?.("deliverables")}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all duration-200 font-semibold text-xs cursor-pointer ${
                viewMode === "deliverables"
                  ? "bg-[#F59E0B]/20 text-[#F59E0B] border border-[#F59E0B]/40"
                  : "text-slate-400 hover:text-[#F59E0B]"
              }`}
              title="Platform Documentation & Deliverables"
            >
              <Award className="w-3.5 h-3.5" />
              <span>Docs Hub</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
