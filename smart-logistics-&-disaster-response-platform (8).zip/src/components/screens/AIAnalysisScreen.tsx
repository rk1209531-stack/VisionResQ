import React from "react";
import { Incident, ScreenId } from "../../types";
import {
  Sparkles,
  AlertTriangle,
  ShieldCheck,
  CheckCircle2,
  Clock,
  ArrowRight,
  Layers,
  MapPin,
  Share2,
} from "lucide-react";

interface AIAnalysisScreenProps {
  incident: Incident | null;
  onNavigate: (screen: ScreenId) => void;
}

export const AIAnalysisScreen: React.FC<AIAnalysisScreenProps> = ({
  incident,
  onNavigate,
}) => {
  if (!incident) {
    return (
      <div className="p-6 text-center text-slate-400">
        <p>No active incident selected for analysis.</p>
        <button
          onClick={() => onNavigate("report")}
          className="mt-3 px-4 py-2 bg-orange-600 text-white text-xs font-bold rounded-xl"
        >
          Submit a Report First
        </button>
      </div>
    );
  }

  const { aiAnalysis } = incident;

  const severityBadge =
    aiAnalysis.severity === "Critical"
      ? "bg-[#EF4444]/20 text-[#EF4444] border-[#EF4444]/35"
      : aiAnalysis.severity === "High"
      ? "bg-[#F59E0B]/20 text-[#F59E0B] border-[#F59E0B]/35"
      : aiAnalysis.severity === "Medium"
      ? "bg-amber-500/20 text-amber-400 border-amber-500/30"
      : "bg-[#10B981]/20 text-[#10B981] border-[#10B981]/35";

  return (
    <div className="p-4 space-y-4 pb-12">
      {/* Top AI Scan Banner */}
      <div className="vrq-card p-4 bg-gradient-to-r from-[#2563EB]/20 via-[#050816]/90 to-[#06B6D4]/20 border-[#06B6D4]/30 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#2563EB]/20 text-[#06B6D4] border border-[#06B6D4]/30 flex items-center justify-center">
            <Sparkles className="w-5 h-5 animate-spin-slow" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-extrabold text-white">Step 2: AI Vision Analysis</span>
              <span className="text-[9px] font-bold px-2 py-0.5 rounded-full bg-[#06B6D4]/15 text-[#06B6D4] border border-[#06B6D4]/30">
                {aiAnalysis.modelUsed}
              </span>
            </div>
            <p className="text-[10px] text-slate-400 mt-0.5">Multimodal Neural Assessment</p>
          </div>
        </div>
        <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-[#10B981]/15 text-[#10B981] border border-[#10B981]/30">
          Scanned
        </span>
      </div>

      {/* Scanned Image with HUD Overlay */}
      <div className="relative rounded-2xl overflow-hidden border border-white/[0.1] bg-[#050816] aspect-video shadow-[0_12px_32px_rgba(2,6,23,0.65)]">
        <img
          src={incident.imageUrl}
          alt={incident.title}
          className="w-full h-full object-cover"
        />

        {/* HUD Scanner Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#050816] via-transparent to-transparent flex flex-col justify-between p-3.5">
          <div className="flex items-center justify-between">
            <span className="px-2.5 py-1 rounded-lg bg-[#050816]/85 text-[10px] font-mono text-[#10B981] border border-[#10B981]/35 backdrop-blur-md">
              LAT: {incident.lat.toFixed(3)} | LNG: {incident.lng.toFixed(3)}
            </span>
            <span className="px-2.5 py-1 rounded-lg bg-[#2563EB]/90 text-white text-[10px] font-bold border border-white/20 backdrop-blur-md">
              {aiAnalysis.incidentType}
            </span>
          </div>

          <div className="text-[11px] text-white font-semibold drop-shadow flex items-center gap-1.5">
            <MapPin className="w-3.5 h-3.5 text-[#06B6D4] flex-shrink-0" />
            <span className="truncate">{incident.locationName}</span>
          </div>
        </div>
      </div>

      {/* Primary AI Metrics Card (Exact output required in problem statement!) */}
      <div className="vrq-card p-4 space-y-3.5">
        {/* Risk Score Meter */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <div>
              <span className="text-xs font-extrabold text-white">Smart Hazard Risk Score</span>
              <span className="text-[10px] text-slate-400 block">
                Normalized multi-factor score: Incident + Weather + Road + Crowd
              </span>
            </div>
            <div className="text-right">
              <span className="text-base font-black font-mono text-[#06B6D4]">
                {aiAnalysis.riskScore} / 100
              </span>
              <span className={`text-[10px] font-bold block ${
                aiAnalysis.riskScore <= 30
                  ? "text-[#10B981]"
                  : aiAnalysis.riskScore <= 70
                  ? "text-[#F59E0B]"
                  : "text-[#EF4444]"
              }`}>
                {aiAnalysis.riskScore <= 30 ? "LOW RISK (0-30)" : aiAnalysis.riskScore <= 70 ? "MEDIUM RISK (31-70)" : "HIGH RISK (71-100)"}
              </span>
            </div>
          </div>
          <div className="w-full h-3 bg-[#050816] rounded-full overflow-hidden p-0.5 border border-white/10">
            <div
              style={{ width: `${Math.min(100, Math.max(5, aiAnalysis.riskScore))}%` }}
              className={`h-full rounded-full transition-all duration-700 ${
                aiAnalysis.riskScore >= 71
                  ? "bg-gradient-to-r from-[#F59E0B] to-[#EF4444]"
                  : aiAnalysis.riskScore >= 31
                  ? "bg-gradient-to-r from-[#06B6D4] to-[#F59E0B]"
                  : "bg-gradient-to-r from-[#10B981] to-[#06B6D4]"
              }`}
            />
          </div>
        </div>

        {/* Mandatory AI Verification Disclaimer */}
        <div className="p-3 rounded-xl bg-[#F59E0B]/15 border border-[#F59E0B]/35 text-amber-200 text-xs flex items-center gap-2.5">
          <ShieldCheck className="w-4 h-4 text-[#F59E0B] shrink-0" />
          <span className="font-semibold text-[11px]">
            AI-generated assessment — requires human/authority verification.
          </span>
        </div>


        {/* 2-Column Summary: Type & Severity */}
        <div className="grid grid-cols-2 gap-2.5 text-xs">
          <div className="p-3 rounded-xl bg-[#050816]/85 border border-white/[0.08]">
            <span className="text-[10px] text-slate-400 block mb-0.5">Detected Incident Type</span>
            <span className="font-extrabold text-white text-xs">{aiAnalysis.incidentType}</span>
          </div>

          <div className="p-3 rounded-xl bg-[#050816]/85 border border-white/[0.08]">
            <span className="text-[10px] text-slate-400 block mb-0.5">Assessed Severity</span>
            <span className={`inline-block px-2.5 py-0.5 rounded-full text-[11px] font-bold border ${severityBadge}`}>
              {aiAnalysis.severity}
            </span>
          </div>
        </div>

        {/* AI Incident Summary */}
        <div className="p-3.5 rounded-xl bg-[#050816]/85 border border-white/[0.08]">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
            AI Incident Summary
          </span>
          <p className="text-xs text-slate-200 leading-relaxed font-medium">
            {aiAnalysis.summary}
          </p>
        </div>

        {/* Recommended Action (Key requirement!) */}
        <div className="p-3.5 rounded-xl bg-[#2563EB]/15 border border-[#06B6D4]/30">
          <span className="text-[10px] font-bold uppercase tracking-wider text-[#06B6D4] block mb-1">
            Recommended Action
          </span>
          <p className="text-xs font-bold text-white leading-snug">
            {aiAnalysis.recommendedAction}
          </p>
        </div>

        {/* Affected Infrastructure Tags & ETA */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-2.5 border-t border-white/[0.08] text-[11px]">
          <div className="flex items-center gap-1.5 text-slate-400">
            <Clock className="w-3.5 h-3.5 text-[#F59E0B]" />
            <span>Est. Clearance: <strong className="text-slate-200">{aiAnalysis.estimatedClearanceHours || 12} hrs</strong></span>
          </div>

          <div className="flex items-center gap-1.5 text-slate-400">
            <ShieldCheck className="w-3.5 h-3.5 text-[#10B981]" />
            <span>
              Green Corridor:{" "}
              <strong className={aiAnalysis.greenCorridorViability ? "text-[#10B981]" : "text-[#EF4444]"}>
                {aiAnalysis.greenCorridorViability ? "Viable" : "Blocked (Divert)"}
              </strong>
            </span>
          </div>
        </div>

        {aiAnalysis.affectedInfrastructure && aiAnalysis.affectedInfrastructure.length > 0 && (
          <div className="flex flex-wrap gap-1.5 pt-1">
            {aiAnalysis.affectedInfrastructure.map((item) => (
              <span
                key={item}
                className="text-[10px] px-2.5 py-0.5 rounded-md bg-white/[0.06] text-slate-300 border border-white/[0.08]"
              >
                {item}
              </span>
            ))}
          </div>
        )}
      </div>

      {/* Next Step Action Buttons */}
      <div className="grid grid-cols-2 gap-2.5 pt-2">
        <button
          onClick={() => onNavigate("crowd_verify")}
          className="py-3 px-3 rounded-2xl bg-gradient-to-r from-[#2563EB] to-[#06B6D4] hover:brightness-110 text-white font-extrabold text-xs flex items-center justify-center gap-1.5 shadow-[0_6px_20px_rgba(37,99,235,0.35)] transition vrq-btn-press cursor-pointer"
        >
          <span>Crowd Verify</span>
          <ArrowRight className="w-4 h-4" />
        </button>

        <button
          onClick={() => onNavigate("smart_route")}
          className="py-3 px-3 rounded-2xl bg-[#0b132b]/80 hover:bg-white/[0.08] text-slate-200 font-bold text-xs flex items-center justify-center gap-1.5 border border-white/[0.08] transition vrq-btn-press cursor-pointer"
        >
          <span>Calculate Safe Route</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
