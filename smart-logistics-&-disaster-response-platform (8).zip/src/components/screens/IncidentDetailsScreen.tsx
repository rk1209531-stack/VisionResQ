import React from "react";
import { Incident, ScreenId } from "../../types";
import {
  MapPin,
  Clock,
  Shield,
  CheckCircle,
  ThumbsUp,
  ThumbsDown,
  AlertTriangle,
  Ambulance,
  Phone,
  User,
  Share2,
  ArrowRight,
} from "lucide-react";

interface IncidentDetailsScreenProps {
  incident: Incident | null;
  onNavigate: (screen: ScreenId) => void;
  onVote: (incidentId: string, type: "confirm" | "reject") => void;
  onTogglePriority: (incidentId: string) => void;
}

export const IncidentDetailsScreen: React.FC<IncidentDetailsScreenProps> = ({
  incident,
  onNavigate,
  onVote,
  onTogglePriority,
}) => {
  if (!incident) {
    return (
      <div className="p-6 text-center text-slate-400">
        <p>No incident selected.</p>
        <button
          onClick={() => onNavigate("home")}
          className="mt-3 px-4 py-2 bg-orange-600 text-white text-xs font-bold rounded-xl"
        >
          Return to Home
        </button>
      </div>
    );
  }

  const { crowdVerification, aiAnalysis, assignedTeam, resolutionTimeline } = incident;

  return (
    <div className="p-4 space-y-4 pb-12">
      {/* Hero Image with Badges */}
      <div className="relative rounded-2xl overflow-hidden border border-white/[0.1] bg-[#050816] aspect-video shadow-[0_12px_32px_rgba(2,6,23,0.65)]">
        <img
          src={incident.imageUrl}
          alt={incident.title}
          className="w-full h-full object-cover"
        />

        <div className="absolute top-3 left-3 flex items-center gap-1.5">
          <span className="px-2.5 py-1 rounded-lg bg-[#2563EB]/90 text-white font-black text-[10px] shadow-md backdrop-blur-md border border-white/20">
            {incident.type}
          </span>
          <span className="px-2.5 py-1 rounded-lg bg-[#050816]/85 text-white font-bold text-[10px] border border-white/15 backdrop-blur-md">
            {incident.status}
          </span>
        </div>

        <div className="absolute top-3 right-3">
          <span className="px-3 py-1 rounded-full bg-[#EF4444]/95 text-white font-black text-xs shadow-[0_6px_20px_rgba(239,68,68,0.45)] flex items-center gap-1 border border-white/20 backdrop-blur-md">
            Risk {aiAnalysis.riskScore}%
          </span>
        </div>

        <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-[#050816] via-[#050816]/85 to-transparent p-4 pt-8">
          <h2 className="text-sm font-extrabold text-white leading-snug">
            {incident.title}
          </h2>
          <p className="text-[11px] text-slate-300 flex items-center gap-1.5 mt-1">
            <MapPin className="w-3.5 h-3.5 text-[#06B6D4] flex-shrink-0" />
            <span className="truncate">{incident.locationName}</span>
          </p>
        </div>
      </div>

      {/* Emergency Priority Toggle & Reporter Info */}
      <div className="vrq-card p-4 flex items-center justify-between text-xs">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-[#2563EB]/15 border border-[#2563EB]/30 flex items-center justify-center text-[#06B6D4]">
            <User className="w-4 h-4" />
          </div>
          <div>
            <span className="font-bold text-white block text-xs">{incident.reportedBy.name}</span>
            <span className="text-[10px] text-slate-400 capitalize">{incident.reportedBy.role} • {incident.reportedAt}</span>
          </div>
        </div>

        <button
          onClick={() => onTogglePriority(incident.id)}
          className={`px-3 py-1.5 rounded-xl text-[10px] font-bold border transition flex items-center gap-1.5 vrq-btn-press cursor-pointer ${
            incident.isEmergencyPriority
              ? "bg-[#EF4444] text-white border-red-400 shadow-[0_4px_14px_rgba(239,68,68,0.35)]"
              : "bg-[#050816]/85 text-slate-300 border-white/[0.08] hover:text-white"
          }`}
        >
          <Ambulance className="w-3.5 h-3.5" />
          <span>{incident.isEmergencyPriority ? "Priority Active" : "Set SOS Priority"}</span>
        </button>
      </div>

      {/* Crowd Verification Stats Box (Step 3 Requirement) */}
      <div className="vrq-card p-4 space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-extrabold text-white uppercase tracking-wider flex items-center gap-2">
            <Shield className="w-4 h-4 text-[#10B981]" />
            <span>Crowd Verification & Confidence</span>
          </h3>
          <span className="text-xs font-black font-mono text-[#10B981] bg-[#10B981]/15 px-2.5 py-0.5 rounded-full border border-[#10B981]/30">
            {crowdVerification.confidenceScore}% Confidence
          </span>
        </div>

        <div className="grid grid-cols-2 gap-2.5 text-center text-xs">
          <button
            onClick={() => onVote(incident.id, "confirm")}
            className={`p-3 rounded-xl border flex items-center justify-center gap-2 transition vrq-btn-press cursor-pointer ${
              crowdVerification.userVoted === "confirm"
                ? "bg-[#10B981] text-white border-emerald-400 font-bold shadow-[0_4px_14px_rgba(16,185,129,0.35)]"
                : "bg-[#050816]/85 hover:bg-[#10B981]/15 text-slate-300 border-white/[0.08]"
            }`}
          >
            <ThumbsUp className="w-4 h-4 text-[#10B981]" />
            <span>Confirm ({crowdVerification.confirmations})</span>
          </button>

          <button
            onClick={() => onVote(incident.id, "reject")}
            className={`p-3 rounded-xl border flex items-center justify-center gap-2 transition vrq-btn-press cursor-pointer ${
              crowdVerification.userVoted === "reject"
                ? "bg-[#EF4444] text-white border-red-400 font-bold shadow-[0_4px_14px_rgba(239,68,68,0.35)]"
                : "bg-[#050816]/85 hover:bg-[#EF4444]/15 text-slate-300 border-white/[0.08]"
            }`}
          >
            <ThumbsDown className="w-4 h-4 text-[#EF4444]" />
            <span>Reject ({crowdVerification.rejections})</span>
          </button>
        </div>
      </div>

      {/* AI Diagnosis Summary */}
      <div className="vrq-card p-4 space-y-2.5">
        <div className="flex items-center justify-between text-xs">
          <span className="text-[11px] font-black text-[#06B6D4] uppercase tracking-wider">
            Gemini Vision Diagnosis
          </span>
          <button
            onClick={() => onNavigate("ai_analysis")}
            className="text-[10px] text-[#06B6D4] hover:text-cyan-300 font-bold cursor-pointer"
          >
            View Full AI Metrics →
          </button>
        </div>
        <p className="text-xs text-slate-200 leading-relaxed font-medium">
          {aiAnalysis.summary}
        </p>
        <div className="p-2.5 rounded-xl bg-[#050816]/90 border border-white/[0.08] text-[11px] text-slate-300">
          <strong className="text-[#06B6D4]">Action:</strong> {aiAnalysis.recommendedAction}
        </div>
      </div>

      {/* Assigned Response Unit */}
      {assignedTeam && (
        <div className="vrq-card p-4 flex items-center justify-between text-xs">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#2563EB]/20 text-[#06B6D4] border border-[#06B6D4]/30 flex items-center justify-center font-black">
              {assignedTeam.agency}
            </div>
            <div>
              <span className="font-bold text-white block text-xs">{assignedTeam.teamName}</span>
              <span className="text-[10px] text-slate-400">Dispatched: {assignedTeam.dispatchedAt || "Just now"}</span>
            </div>
          </div>
          <a
            href={`tel:${assignedTeam.contactNumber}`}
            className="p-2.5 rounded-xl bg-[#10B981]/15 border border-[#10B981]/30 hover:bg-[#10B981]/25 text-[#10B981] transition"
          >
            <Phone className="w-4 h-4" />
          </a>
        </div>
      )}

      {/* Resolution Timeline Flow */}
      <div className="vrq-card p-4 space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-extrabold text-white uppercase tracking-wider flex items-center gap-2">
            <Clock className="w-4 h-4 text-[#06B6D4]" />
            <span>Resolution Timeline Flow</span>
          </h3>
          <button
            onClick={() => onNavigate("resolution_tracking")}
            className="text-[10px] text-[#06B6D4] font-bold hover:underline cursor-pointer"
          >
            Full Audit →
          </button>
        </div>

        <div className="space-y-3 pl-2 border-l-2 border-white/10 ml-2">
          {resolutionTimeline.map((step, idx) => (
            <div key={idx} className="relative pl-3">
              <div className="absolute -left-[19px] top-1 w-2.5 h-2.5 rounded-full bg-[#06B6D4] ring-2 ring-[#050816]" />
              <div className="flex items-center justify-between text-[11px]">
                <span className="font-bold text-white">{step.step}</span>
                <span className="text-[10px] text-slate-400">{step.timestamp}</span>
              </div>
              <p className="text-[11px] text-slate-300 mt-0.5">{step.note}</p>
              <span className="text-[9px] text-slate-500 block">By: {step.updatedBy}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom Route Action */}
      <button
        onClick={() => onNavigate("smart_route")}
        className="w-full py-3 bg-gradient-to-r from-[#2563EB] to-[#06B6D4] hover:brightness-110 text-white font-extrabold text-xs rounded-2xl shadow-[0_8px_24px_rgba(37,99,235,0.35)] flex items-center justify-center gap-2 transition vrq-btn-press cursor-pointer"
      >
        <span>Calculate Alternate Bypass Route</span>
        <ArrowRight className="w-4 h-4" />
      </button>
    </div>
  );
};
