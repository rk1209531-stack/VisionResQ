import React, { useState, useMemo, useEffect } from "react";
import {
  ScreenId,
  VehicleType,
  TripPurpose,
  BookingPriority,
  TransportBooking,
  VehiclePricingConfig,
  RouteOption,
  Incident,
} from "../../types";
import {
  INITIAL_VEHICLE_PRICING,
  PRESET_LOCATIONS,
  calculateEstimatedFare,
  getCorridorRoutes,
  LocationPreset,
} from "../../transportData";
import { INITIAL_INCIDENTS } from "../../mockData";
import { DisasterInteractiveMap } from "../map/DisasterInteractiveMap";
import { LocationKeywordInput } from "../common/LocationKeywordInput";
import { computeRealGoogleRoute } from "../../services/googleMapsService";
import {
  Truck,
  Bike,
  Navigation,
  Shield,
  AlertTriangle,
  CheckCircle2,
  Clock,
  ArrowRight,
  Sparkles,
  Package,
  Ambulance,
  Crosshair,
  Info,
  Layers,
  MapPin,
  ChevronRight,
  HelpCircle,
  Loader2,
  Globe2,
} from "lucide-react";

interface BookTransportScreenProps {
  onNavigate: (screen: ScreenId) => void;
  onInitiateBooking: (booking: TransportBooking) => void;
  vehiclePricing: VehiclePricingConfig[];
  userRole?: string;
  incidents?: Incident[];
}

export const BookTransportScreen: React.FC<BookTransportScreenProps> = ({
  onNavigate,
  onInitiateBooking,
  vehiclePricing = INITIAL_VEHICLE_PRICING,
  incidents = INITIAL_INCIDENTS,
}) => {
  // Booking Form State - real locations
  const [pickupLocation, setPickupLocation] = useState<LocationPreset>(PRESET_LOCATIONS[0]);
  const [destinationLocation, setDestinationLocation] = useState<LocationPreset>(PRESET_LOCATIONS[1]);
  const [selectedVehicle, setSelectedVehicle] = useState<VehicleType>("Mini Truck");
  const [tripPurpose, setTripPurpose] = useState<TripPurpose>("Disaster Relief");
  const [priority, setPriority] = useState<BookingPriority>("EMERGENCY");
  const [selectedRouteId, setSelectedRouteId] = useState<"Route A" | "Route B">("Route B");

  // Optional Package Information
  const [packageWeight, setPackageWeight] = useState<string>("1400");
  const [packageDescription, setPackageDescription] = useState<string>(
    "WHO Emergency Medical Rations, Antivenom Kits, and Purified Water Tablets"
  );
  const [isFragile, setIsFragile] = useState<boolean>(true);
  const [recipientName, setRecipientName] = useState<string>("Dr. Ananya Kaul (Jammu GMC)");
  const [recipientPhone, setRecipientPhone] = useState<string>("+91 94191 33201");
  const [showPackageModal, setShowPackageModal] = useState<boolean>(false);

  // Real Google Route computation state
  const [corridorData, setCorridorData] = useState(() =>
    getCorridorRoutes(pickupLocation, destinationLocation)
  );
  const [isComputingRoute, setIsComputingRoute] = useState(false);
  const [routeSource, setRouteSource] = useState<string>("Google Routes API v2");

  // Re-compute route with real Google Routes API v2 automatically whenever
  // origin, destination, or incidents change
  useEffect(() => {
    let isCancelled = false;
    setIsComputingRoute(true);

    computeRealGoogleRoute(pickupLocation, destinationLocation, incidents)
      .then((res) => {
        if (isCancelled) return;
        if (res) {
          setCorridorData({
            routeA: res.routeA,
            routeB: res.routeB,
          });
          setRouteSource(res.source);
          if (res.routeB.isRecommended) {
            setSelectedRouteId("Route B");
          } else {
            setSelectedRouteId("Route A");
          }
        } else {
          // Dynamic fallback based on real coordinates
          setCorridorData(getCorridorRoutes(pickupLocation, destinationLocation));
        }
      })
      .catch((err) => {
        console.warn("Real route compute fallback:", err);
        if (!isCancelled) {
          setCorridorData(getCorridorRoutes(pickupLocation, destinationLocation));
        }
      })
      .finally(() => {
        if (!isCancelled) {
          setIsComputingRoute(false);
        }
      });

    return () => {
      isCancelled = true;
    };
  }, [
    pickupLocation.lat,
    pickupLocation.lng,
    destinationLocation.lat,
    destinationLocation.lng,
    incidents,
  ]);

  const activeRoute = useMemo(() => {
    return selectedRouteId === "Route A" ? corridorData.routeA : corridorData.routeB;
  }, [selectedRouteId, corridorData]);

  // Fare Calculation
  const fareResult = useMemo(() => {
    return calculateEstimatedFare(
      selectedVehicle,
      activeRoute.distanceKm,
      activeRoute,
      priority,
      vehiclePricing
    );
  }, [selectedVehicle, activeRoute, priority, vehiclePricing]);

  // Handle Preset Swap
  const handleSwapLocations = () => {
    const temp = pickupLocation;
    setPickupLocation(destinationLocation);
    setDestinationLocation(temp);
  };

  // Proceed to Confirmation
  const handleProceedToConfirmation = () => {
    const bookingId = `BK-2026-${Math.floor(1000 + Math.random() * 9000)}`;
    const newBooking: TransportBooking = {
      bookingId,
      userId: "usr_citizen_demo",
      userName: "SIH Citizen / Logistics Officer",
      userPhone: "+91 98100 12345",
      vehicleType: selectedVehicle,
      purpose: tripPurpose,
      priority,
      isEmergency: priority === "EMERGENCY",
      pickupLocation: {
        name: pickupLocation.name,
        lat: pickupLocation.lat,
        lng: pickupLocation.lng,
      },
      destinationLocation: {
        name: destinationLocation.name,
        lat: destinationLocation.lat,
        lng: destinationLocation.lng,
      },
      distanceKm: activeRoute.distanceKm,
      estimatedMinutes: activeRoute.estimatedMinutes,
      fareBreakdown: {
        baseFare: fareResult.baseFare,
        distanceCharge: fareResult.distanceCharge,
        riskDetourCharge: fareResult.riskDetourCharge,
        totalEstimatedFare: fareResult.totalEstimatedFare,
      },
      selectedRoute: selectedRouteId,
      routeDetails: activeRoute,
      status: "Searching",
      packageInfo: {
        weightKg: packageWeight ? parseFloat(packageWeight) : undefined,
        description: packageDescription,
        isFragileOrPerishable: isFragile,
        recipientName,
        recipientPhone,
      },
      driverProgressPercent: 0,
      greenCorridorApproved: priority === "EMERGENCY",
      createdAt: "Just now",
      updatedAt: "Just now",
    };

    onInitiateBooking(newBooking);
    onNavigate("booking_confirmation");
  };

  return (
    <div className="p-4 space-y-4 pb-12 text-slate-100">
      {/* Top Banner: Central Concept Differentiator */}
      <div className="vrq-card p-4 bg-gradient-to-r from-[#2563EB]/20 via-[#050816]/90 to-[#06B6D4]/20 border-[#06B6D4]/30">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4 text-[#06B6D4]" />
            <span className="text-[11px] font-black uppercase tracking-wider text-[#06B6D4]">
              Disaster-Aware Smart Logistics
            </span>
          </div>
          <span className="text-[9px] font-bold px-2.5 py-0.5 rounded-full bg-[#10B981]/15 text-[#10B981] border border-[#10B981]/30">
            SIH Problem SIH26002
          </span>
        </div>
        <p className="text-[11px] text-slate-300 leading-relaxed">
          Unlike standard taxi apps, we calculate estimated delivery fares while actively checking{" "}
          <strong className="text-white">route risk, active landslides, and road accessibility</strong>.
        </p>
      </div>

      {/* 1. PICKUP & DESTINATION SELECTION */}
      <div className="vrq-card p-4 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-extrabold text-white uppercase tracking-wider flex items-center gap-2">
            <Navigation className="w-4 h-4 text-[#06B6D4]" />
            <span>1. Locations (Google Maps / GIS)</span>
          </h3>
          <button
            onClick={() => {
              // Current GPS Simulator
              setPickupLocation({
                name: "Current GPS Location (Rajouri Sector)",
                region: "Jammu & Kashmir",
                lat: 33.3765,
                lng: 74.3103,
                isHighRiskZone: true,
              });
            }}
            className="text-[10px] text-[#06B6D4] hover:text-cyan-300 flex items-center gap-1 font-bold px-2 py-1 rounded-lg bg-[#06B6D4]/10 border border-[#06B6D4]/25 transition vrq-btn-press cursor-pointer"
          >
            <Crosshair className="w-3 h-3" />
            <span>Use Current GPS</span>
          </button>
        </div>

        {/* Pickup Input with Google Places Autocomplete */}
        <LocationKeywordInput
          id="pickup-keyword-input"
          label="A. Origin / Pickup Location (Search any Indian place)"
          dotColor="emerald"
          value={pickupLocation.name}
          selectedPreset={pickupLocation}
          presets={PRESET_LOCATIONS}
          placeholder="Search any city, district, road, or landmark..."
          onSelectLocation={(preset) => setPickupLocation(preset)}
          helperText="Google Places autocomplete enabled — search any place in India or use GPS"
        />

        {/* Swap Button & Quick Popular Chips */}
        <div className="flex items-center justify-between gap-2 py-0.5">
          <div className="flex items-center gap-1.5 overflow-x-auto py-0.5 text-[10px] scrollbar-none">
            <span className="text-[9px] uppercase font-bold text-slate-400 shrink-0">Quick Relief Routes:</span>
            {[
              {
                label: "Rishikesh ⇄ Devprayag",
                orig: { name: "Rishikesh", region: "Uttarakhand", lat: 30.0869, lng: 78.2676 },
                dest: { name: "Devprayag", region: "Uttarakhand", lat: 30.1459, lng: 78.5989 },
              },
              {
                label: "New Delhi ⇄ Dehradun",
                orig: { name: "New Delhi", region: "Delhi", lat: 28.6139, lng: 77.209 },
                dest: { name: "Dehradun", region: "Uttarakhand", lat: 30.3165, lng: 78.0322 },
              },
              {
                label: "Guwahati ⇄ Tezpur",
                orig: { name: "Guwahati", region: "Assam", lat: 26.1445, lng: 91.7362 },
                dest: { name: "Tezpur", region: "Assam", lat: 26.6528, lng: 92.7926 },
              },
              {
                label: "Mandi ⇄ Manali",
                orig: { name: "Mandi", region: "Himachal Pradesh", lat: 31.7088, lng: 76.932 },
                dest: { name: "Manali", region: "Himachal Pradesh", lat: 32.2396, lng: 77.1887 },
              },
            ].map((c) => (
              <button
                key={c.label}
                type="button"
                onClick={() => {
                  setPickupLocation(c.orig);
                  setDestinationLocation(c.dest);
                }}
                className="px-2.5 py-1 rounded-lg bg-[#050816]/90 hover:bg-white/[0.08] text-slate-300 hover:text-white border border-white/[0.08] whitespace-nowrap shrink-0 transition text-[9px] font-semibold cursor-pointer vrq-btn-press"
              >
                {c.label}
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={handleSwapLocations}
            className="p-1.5 px-2.5 rounded-xl bg-[#050816]/90 hover:bg-white/[0.08] text-slate-200 transition text-[10px] flex items-center gap-1 border border-white/[0.08] shrink-0 cursor-pointer shadow-sm vrq-btn-press"
            title="Swap Pickup and Destination"
          >
            <span className="font-bold text-xs text-[#06B6D4]">⇅</span>
            <span className="hidden sm:inline text-[10px] font-bold">Swap</span>
          </button>
        </div>

        {/* Destination Input with Google Places Autocomplete */}
        <LocationKeywordInput
          id="destination-keyword-input"
          label="B. Destination (Search any Indian place)"
          dotColor="orange"
          value={destinationLocation.name}
          selectedPreset={destinationLocation}
          presets={PRESET_LOCATIONS}
          placeholder="Search any hospital, relief depot, town..."
          onSelectLocation={(preset) => setDestinationLocation(preset)}
          helperText="Google Places autocomplete enabled — dynamic coordinates resolution"
        />

        {/* Interactive Corridor Google Map Preview */}
        <div className="space-y-2 pt-1">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-300 flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-[#06B6D4]" />
              <span>Route Corridor Map (Google Maps Platform)</span>
            </span>
            <div className="flex items-center gap-2">
              {isComputingRoute && (
                <span className="text-[10px] text-[#06B6D4] flex items-center gap-1">
                  <Loader2 className="w-3 h-3 animate-spin" />
                  <span>Calculating Route...</span>
                </span>
              )}
              <span className="text-[10px] text-[#10B981] font-mono bg-[#10B981]/15 px-2.5 py-0.5 rounded-full border border-[#10B981]/30 flex items-center gap-1 font-bold">
                <Globe2 className="w-2.5 h-2.5" />
                <span>{routeSource}</span>
              </span>
            </div>
          </div>

          <DisasterInteractiveMap
            incidents={incidents}
            pickupLocation={{ lat: pickupLocation.lat, lng: pickupLocation.lng, name: pickupLocation.name }}
            destinationLocation={{ lat: destinationLocation.lat, lng: destinationLocation.lng, name: destinationLocation.name }}
            routeAPath={corridorData.routeA.pathCoordinates}
            routeBPath={corridorData.routeB.pathCoordinates}
            userLocation={{ lat: pickupLocation.lat, lng: pickupLocation.lng, formattedAddress: pickupLocation.name }}
            heightClass="h-56 sm:h-64"
          />

          <div className="flex items-center justify-between text-[10px] text-slate-400 px-1">
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-1 bg-[#10B981] rounded" />
              <span>Safe Corridor (Route B)</span>
              <span className="w-2.5 h-1 bg-[#EF4444] rounded ml-2" />
              <span>Direct Hazard (Route A)</span>
            </span>
            <span className="text-slate-500">
              Pickup (P) & Destination (D) live synced
            </span>
          </div>
        </div>
      </div>

      {/* 2. VEHICLE SELECTION (Uber / Rapido Style Interface) */}
      <div className="vrq-card p-4 space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-extrabold text-white uppercase tracking-wider flex items-center gap-2">
            <Truck className="w-4 h-4 text-[#2563EB]" />
            <span>2. Select Vehicle / Relief Transport</span>
          </h3>
          <span className="text-[10px] text-[#06B6D4] font-bold bg-[#06B6D4]/15 px-2.5 py-0.5 rounded-full border border-[#06B6D4]/30">
            Uber-Style Relief Fleet
          </span>
        </div>

        <div className="grid grid-cols-2 gap-3">
          {vehiclePricing.map((veh) => {
            const isSelected = selectedVehicle === veh.type;
            const vehFare = calculateEstimatedFare(
              veh.type,
              activeRoute.distanceKm,
              activeRoute,
              priority,
              vehiclePricing
            ).totalEstimatedFare;

            const vehicleEta =
              veh.type === "Bike"
                ? "8 min away"
                : veh.type === "Ambulance"
                ? "5 min (SDRF Siren)"
                : veh.type === "Mini Truck"
                ? "14 min away"
                : "22 min away";

            const VehicleIcon =
              veh.type === "Bike"
                ? Bike
                : veh.type === "Ambulance"
                ? Ambulance
                : Truck;

            return (
              <button
                key={veh.type}
                type="button"
                onClick={() => setSelectedVehicle(veh.type)}
                className={`p-3.5 rounded-2xl border text-left transition-all duration-200 flex flex-col justify-between relative group vrq-btn-press cursor-pointer ${
                  isSelected
                    ? "bg-gradient-to-br from-[#2563EB]/25 via-[#0b132b] to-[#050816] border-[#2563EB] ring-1 ring-[#06B6D4]/50 shadow-[0_8px_24px_rgba(37,99,235,0.25)]"
                    : "bg-[#050816]/80 border-white/[0.08] hover:border-white/20 hover:bg-white/[0.03]"
                }`}
              >
                <div className="flex items-start justify-between w-full mb-1.5">
                  <div className="flex items-center gap-2.5">
                    <div
                      className={`w-9 h-9 rounded-xl flex items-center justify-center transition ${
                        isSelected
                          ? "bg-gradient-to-br from-[#2563EB] to-[#06B6D4] text-white shadow-[0_4px_12px_rgba(37,99,235,0.4)]"
                          : "bg-white/[0.05] text-slate-300 border border-white/[0.06]"
                      }`}
                    >
                      <VehicleIcon className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-xs font-extrabold text-white block leading-tight">
                        {veh.type}
                      </span>
                      <span className="text-[9px] text-[#10B981] font-bold flex items-center gap-1 mt-0.5">
                        <Clock className="w-2.5 h-2.5" />
                        {vehicleEta}
                      </span>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-sm font-black font-mono text-white block leading-tight">
                      ₹{vehFare.toLocaleString("en-IN")}
                    </span>
                    <span className="text-[8px] text-slate-400">est. fare</span>
                  </div>
                </div>

                <div className="mt-1 pt-2 border-t border-white/[0.06] flex items-center justify-between text-[9px] text-slate-400">
                  <span className="truncate max-w-[140px]">{veh.capacity}</span>
                  <span className="font-mono text-slate-300 font-bold shrink-0">₹{veh.ratePerKm}/km</span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* 3. TRIP PURPOSE & EMERGENCY PRIORITY */}
      <div className="vrq-card p-4 space-y-4">
        <h3 className="text-xs font-extrabold text-white uppercase tracking-wider flex items-center gap-2">
          <Shield className="w-4 h-4 text-[#06B6D4]" />
          <span>3. Trip Purpose & Priority Tier</span>
        </h3>

        {/* Purpose Pills */}
        <div>
          <label className="text-[10px] uppercase font-bold text-slate-400 block mb-2">
            Purpose of Movement:
          </label>
          <div className="grid grid-cols-3 gap-2">
            {[
              "Disaster Relief",
              "Medicine Delivery",
              "Food Delivery",
              "Construction Materials",
              "Agricultural Produce",
              "Other",
            ].map((purpose) => (
              <button
                key={purpose}
                onClick={() => setTripPurpose(purpose as TripPurpose)}
                className={`px-2.5 py-2 rounded-xl text-[10px] font-bold border transition text-center truncate vrq-btn-press cursor-pointer ${
                  tripPurpose === purpose
                    ? "bg-gradient-to-r from-[#2563EB] to-[#06B6D4] text-white border-[#06B6D4]/50 shadow-[0_4px_14px_rgba(37,99,235,0.3)]"
                    : "bg-[#050816]/80 text-slate-300 border-white/[0.08] hover:border-white/20"
                }`}
              >
                {purpose}
              </button>
            ))}
          </div>
        </div>

        {/* Priority Tier Selection */}
        <div>
          <label className="text-[10px] uppercase font-bold text-slate-400 block mb-2">
            Emergency Priority Level:
          </label>
          <div className="grid grid-cols-3 gap-2">
            <button
              onClick={() => setPriority("NORMAL")}
              className={`p-2.5 rounded-xl border text-center transition vrq-btn-press cursor-pointer ${
                priority === "NORMAL"
                  ? "bg-white/[0.1] text-white border-white/30"
                  : "bg-[#050816]/80 text-slate-400 border-white/[0.08]"
              }`}
            >
              <span className="text-[10px] font-bold block">NORMAL</span>
              <span className="text-[9px] text-slate-400">Standard Transit</span>
            </button>

            <button
              onClick={() => setPriority("URGENT")}
              className={`p-2.5 rounded-xl border text-center transition vrq-btn-press cursor-pointer ${
                priority === "URGENT"
                  ? "bg-[#F59E0B]/15 text-[#F59E0B] border-[#F59E0B]/60"
                  : "bg-[#050816]/80 text-slate-400 border-white/[0.08]"
              }`}
            >
              <span className="text-[10px] font-bold block text-[#F59E0B]">URGENT</span>
              <span className="text-[9px] text-slate-400">Fast Dispatch</span>
            </button>

            <button
              onClick={() => setPriority("EMERGENCY")}
              className={`p-2.5 rounded-xl border text-center transition relative overflow-hidden vrq-btn-press cursor-pointer ${
                priority === "EMERGENCY"
                  ? "bg-[#EF4444]/20 text-red-200 border-[#EF4444] ring-1 ring-[#EF4444]/50 shadow-[0_0_16px_rgba(239,68,68,0.25)]"
                  : "bg-[#050816]/80 text-slate-400 border-white/[0.08]"
              }`}
            >
              <div className="flex items-center justify-center gap-1">
                <Ambulance className="w-3 h-3 text-[#EF4444] animate-pulse" />
                <span className="text-[10px] font-black text-[#EF4444]">EMERGENCY</span>
              </div>
              <span className="text-[9px] text-slate-300 block mt-0.5">Green Corridor</span>
            </button>
          </div>
        </div>

        {/* Optional Package Details Collapsible / Button */}
        <div className="pt-2.5 border-t border-white/[0.08]">
          <button
            onClick={() => setShowPackageModal(!showPackageModal)}
            className="w-full flex items-center justify-between text-xs text-slate-300 hover:text-white cursor-pointer"
          >
            <div className="flex items-center gap-2">
              <Package className="w-3.5 h-3.5 text-[#06B6D4]" />
              <span className="font-semibold">Optional Package Information</span>
              {packageWeight && (
                <span className="text-[10px] text-[#06B6D4] font-mono">({packageWeight} kg)</span>
              )}
            </div>
            <span className="text-[11px] text-[#06B6D4] font-bold">
              {showPackageModal ? "Hide ▲" : "Configure ▼"}
            </span>
          </button>

          {showPackageModal && (
            <div className="mt-3 p-3 bg-[#050816]/90 rounded-2xl border border-white/[0.08] space-y-2.5 text-xs">
              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="text-[9px] font-bold text-slate-400 block mb-1">Weight (kg):</label>
                  <input
                    type="number"
                    value={packageWeight}
                    onChange={(e) => setPackageWeight(e.target.value)}
                    placeholder="e.g. 1400"
                    className="w-full bg-[#0b132b]/80 border border-white/10 rounded-xl px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-[#06B6D4]"
                  />
                </div>
                <div className="flex items-center pt-4">
                  <label className="flex items-center gap-2 cursor-pointer text-[10px] text-slate-300">
                    <input
                      type="checkbox"
                      checked={isFragile}
                      onChange={(e) => setIsFragile(e.target.checked)}
                      className="rounded accent-[#2563EB]"
                    />
                    <span>Perishable / Fragile</span>
                  </label>
                </div>
              </div>

              <div>
                <label className="text-[9px] font-bold text-slate-400 block mb-1">Description / Rations:</label>
                <input
                  type="text"
                  value={packageDescription}
                  onChange={(e) => setPackageDescription(e.target.value)}
                  className="w-full bg-[#0b132b]/80 border border-white/10 rounded-xl px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-[#06B6D4]"
                />
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="text-[9px] font-bold text-slate-400 block mb-1">Recipient Official:</label>
                  <input
                    type="text"
                    value={recipientName}
                    onChange={(e) => setRecipientName(e.target.value)}
                    className="w-full bg-[#0b132b]/80 border border-white/10 rounded-xl px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-[#06B6D4]"
                  />
                </div>
                <div>
                  <label className="text-[9px] font-bold text-slate-400 block mb-1">Recipient Contact:</label>
                  <input
                    type="text"
                    value={recipientPhone}
                    onChange={(e) => setRecipientPhone(e.target.value)}
                    className="w-full bg-[#0b132b]/80 border border-white/10 rounded-xl px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-[#06B6D4]"
                  />
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 4. DISASTER-AWARE ROUTE ANALYSIS (THE PRIMARY DIFFERENTIATING FEATURE) */}
      <div className="vrq-card p-4 space-y-3 border-[#06B6D4]/35 relative overflow-hidden">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-[#06B6D4] animate-pulse" />
            <h3 className="text-xs font-extrabold uppercase tracking-wider text-white">
              4. Disaster-Aware Route Analysis
            </h3>
          </div>
          <span className="text-[9px] font-bold px-2.5 py-0.5 rounded-full bg-[#06B6D4]/15 text-[#06B6D4] border border-[#06B6D4]/30">
            Differentiator
          </span>
        </div>

        <p className="text-[11px] text-slate-300">
          Our AI road safety engine evaluates multiple paths against real-time landslide reports,
          flood radar, and road blockages:
        </p>

        {/* Route A vs Route B Comparison Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {/* Route A (High Risk) */}
          <div
            onClick={() => setSelectedRouteId("Route A")}
            className={`cursor-pointer p-3.5 rounded-2xl border transition relative ${
              selectedRouteId === "Route A"
                ? "bg-[#EF4444]/15 border-[#EF4444] ring-1 ring-[#EF4444]/50"
                : "bg-[#050816]/85 border-white/[0.08] hover:border-white/20"
            }`}
          >
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-black text-[#EF4444]">ROUTE A (Direct Highway)</span>
              <span className="text-[9px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-[#EF4444]/20 text-red-300 border border-[#EF4444]/40">
                ❌ {corridorData.routeA.riskLevel}
              </span>
            </div>
            <div className="text-[11px] text-slate-300 font-semibold">{corridorData.routeA.via}</div>

            <div className="grid grid-cols-3 gap-1.5 mt-2.5 text-center text-[10px]">
              <div className="bg-[#0b132b]/80 p-1.5 rounded-xl border border-white/[0.05]">
                <span className="text-slate-400 block text-[8px]">Distance</span>
                <span className="font-bold text-white">{corridorData.routeA.distanceKm} km</span>
              </div>
              <div className="bg-[#0b132b]/80 p-1.5 rounded-xl border border-white/[0.05]">
                <span className="text-slate-400 block text-[8px]">Est. Time</span>
                <span className="font-bold text-white">{Math.floor(corridorData.routeA.estimatedMinutes / 60)}h {corridorData.routeA.estimatedMinutes % 60}m</span>
              </div>
              <div className="bg-[#EF4444]/15 p-1.5 rounded-xl border border-[#EF4444]/30">
                <span className="text-red-300 block text-[8px]">Risk Score</span>
                <span className="font-black text-[#EF4444]">{corridorData.routeA.riskScore}/100</span>
              </div>
            </div>

            <div className="mt-2.5 text-[10px] text-red-200 flex items-start gap-1.5 bg-[#EF4444]/10 p-2 rounded-xl border border-[#EF4444]/25">
              <AlertTriangle className="w-3.5 h-3.5 text-[#EF4444] flex-shrink-0 mt-0.5" />
              <span>{corridorData.routeA.incidentSummary}</span>
            </div>
          </div>

          {/* Route B (Low Risk - Recommended) */}
          <div
            onClick={() => setSelectedRouteId("Route B")}
            className={`cursor-pointer p-3.5 rounded-2xl border transition relative ${
              selectedRouteId === "Route B"
                ? "bg-[#10B981]/15 border-[#10B981] ring-1 ring-[#10B981]/50"
                : "bg-[#050816]/85 border-white/[0.08] hover:border-white/20"
            }`}
          >
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-black text-[#10B981]">ROUTE B (Safe Bypass)</span>
              <span className="text-[9px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-[#10B981]/20 text-emerald-300 border border-[#10B981]/40">
                ✅ RECOMMENDED
              </span>
            </div>
            <div className="text-[11px] text-slate-300 font-semibold">{corridorData.routeB.via}</div>

            <div className="grid grid-cols-3 gap-1.5 mt-2.5 text-center text-[10px]">
              <div className="bg-[#0b132b]/80 p-1.5 rounded-xl border border-white/[0.05]">
                <span className="text-slate-400 block text-[8px]">Distance</span>
                <span className="font-bold text-white">{corridorData.routeB.distanceKm} km</span>
              </div>
              <div className="bg-[#0b132b]/80 p-1.5 rounded-xl border border-white/[0.05]">
                <span className="text-slate-400 block text-[8px]">Est. Time</span>
                <span className="font-bold text-white">{Math.floor(corridorData.routeB.estimatedMinutes / 60)}h {corridorData.routeB.estimatedMinutes % 60}m</span>
              </div>
              <div className="bg-[#10B981]/15 p-1.5 rounded-xl border border-[#10B981]/30">
                <span className="text-emerald-300 block text-[8px]">Risk Score</span>
                <span className="font-black text-[#10B981]">{corridorData.routeB.riskScore}/100</span>
              </div>
            </div>

            <div className="mt-2.5 text-[10px] text-emerald-200 flex items-start gap-1.5 bg-[#10B981]/10 p-2 rounded-xl border border-[#10B981]/25">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#10B981] flex-shrink-0 mt-0.5" />
              <span>{corridorData.routeB.incidentSummary}</span>
            </div>
          </div>
        </div>

        {/* Clear Explanation Callout (Requirement 3) */}
        <div className="bg-[#050816]/90 border border-[#10B981]/30 rounded-2xl p-3.5 flex items-start gap-2.5">
          <div className="w-7 h-7 rounded-xl bg-[#10B981]/15 text-[#10B981] flex items-center justify-center flex-shrink-0 mt-0.5 border border-[#10B981]/30">
            <Sparkles className="w-3.5 h-3.5" />
          </div>
          <div>
            <span className="text-xs font-bold text-[#10B981] block">
              AI Corridor Recommendation:
            </span>
            <p className="text-[11px] text-slate-200 mt-0.5 font-medium leading-relaxed">
              &quot;Route B is {corridorData.routeB.distanceKm - corridorData.routeA.distanceKm} km longer
              but has significantly lower disaster risk ({corridorData.routeB.riskScore}/100 vs{" "}
              {corridorData.routeA.riskScore}/100). Avoids active landslide zone on the direct canyon corridor.&quot;
            </p>
          </div>
        </div>
      </div>

      {/* 5. DISTANCE AND FARE BREAKDOWN (Requirement 2) */}
      <div className="vrq-card p-4 space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-extrabold text-white uppercase tracking-wider flex items-center gap-2">
            <span className="font-mono text-[#06B6D4]">₹</span>
            <span>5. Distance & Fare Calculation</span>
          </h3>
          <span className="text-[9px] font-bold px-2.5 py-0.5 rounded-full bg-white/[0.06] text-slate-300 border border-white/[0.08]">
            Configurable Formula
          </span>
        </div>

        {/* Formula Reference */}
        <div className="text-[10px] text-slate-300 bg-[#050816]/90 p-2.5 rounded-xl font-mono border border-white/[0.06]">
          Estimated Fare = Base Fare + (Distance in km × Rate per km) + Risk/Detour Charge
        </div>

        {/* Breakdown Items */}
        <div className="space-y-1.5 text-xs">
          <div className="flex items-center justify-between text-slate-300">
            <span>Pickup to Destination:</span>
            <span className="font-semibold text-white">
              {pickupLocation.name.split(" ")[0]} → {destinationLocation.name.split(" ")[0]}
            </span>
          </div>

          <div className="flex items-center justify-between text-slate-300">
            <span>Selected Corridor & Distance:</span>
            <span className="font-semibold text-white">
              {selectedRouteId} ({activeRoute.distanceKm} km • {Math.floor(activeRoute.estimatedMinutes / 60)}h {activeRoute.estimatedMinutes % 60}m)
            </span>
          </div>

          <div className="flex items-center justify-between text-slate-300">
            <span>Selected Vehicle:</span>
            <span className="font-semibold text-white">{selectedVehicle}</span>
          </div>

          <div className="pt-2.5 border-t border-white/[0.08] space-y-1.5 text-[11px]">
            <div className="flex items-center justify-between text-slate-400">
              <span>Base Fare ({selectedVehicle}):</span>
              <span className="font-mono text-slate-200">₹{fareResult.baseFare.toLocaleString("en-IN")}</span>
            </div>

            <div className="flex items-center justify-between text-slate-400">
              <span>Distance Charge ({activeRoute.distanceKm} km × ₹{vehiclePricing.find((v) => v.type === selectedVehicle)?.ratePerKm}/km):</span>
              <span className="font-mono text-slate-200">₹{fareResult.distanceCharge.toLocaleString("en-IN")}</span>
            </div>

            <div className="flex items-center justify-between text-slate-400">
              <span>Risk/Detour Charge:</span>
              <span className="font-mono text-slate-200">₹{fareResult.riskDetourCharge.toLocaleString("en-IN")}</span>
            </div>

            {priority === "EMERGENCY" && (
              <div className="flex items-center justify-between text-[#10B981] text-[10px] font-semibold">
                <span>Emergency Surcharge Waiver:</span>
                <span>₹0 (100% Disaster Relief Subsidized)</span>
              </div>
            )}
          </div>

          {/* Grand Total */}
          <div className="pt-2.5 border-t border-white/[0.08] flex items-center justify-between">
            <div>
              <span className="text-xs font-black uppercase tracking-wider text-slate-400 block">
                Estimated Total:
              </span>
              <span className="text-[9px] text-slate-500 font-medium">
                *Estimated Fare (MVP calculation - not real market price)
              </span>
            </div>
            <div className="text-right">
              <span className="text-2xl font-black font-mono text-[#10B981]">
                ₹{fareResult.totalEstimatedFare.toLocaleString("en-IN")}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* 6. PROCEED TO BOOKING CONFIRMATION ACTION BUTTON */}
      <div className="space-y-2 pt-2">
        <button
          onClick={handleProceedToConfirmation}
          className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-[#2563EB] via-[#1D4ED8] to-[#06B6D4] hover:brightness-110 text-white font-extrabold text-sm shadow-[0_8px_28px_rgba(37,99,235,0.4)] flex items-center justify-center gap-2 transition vrq-btn-press cursor-pointer border border-[#06B6D4]/40"
        >
          <span>Confirm Booking & Route ({selectedRouteId})</span>
          <ArrowRight className="w-4 h-4" />
        </button>

        <div className="flex items-center justify-center gap-2 text-[10px] text-slate-400">
          <Shield className="w-3 h-3 text-[#10B981]" />
          <span>Automatic dispatch to verified relief drivers & SDRF escort units</span>
        </div>
      </div>
    </div>
  );
};
