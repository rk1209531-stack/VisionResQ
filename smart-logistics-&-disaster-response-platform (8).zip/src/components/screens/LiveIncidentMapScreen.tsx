import React, { useState, useMemo } from "react";
import { Incident, ScreenId } from "../../types";
import {
  DisasterInteractiveMap,
  MapOverlayLayer,
  DEFAULT_RELIEF_CENTERS,
  DEFAULT_TRAFFIC_SEGMENTS,
  ReliefCenterItem,
  TrafficDensitySegment,
} from "../map/DisasterInteractiveMap";
import { RealWeatherWidget } from "../weather/RealWeatherWidget";
import { useDeviceGPS } from "../../hooks/useDeviceGPS";
import { useRealWeather } from "../../hooks/useRealWeather";
import { voteServerIncident } from "../../services/api";
import {
  Layers,
  Filter,
  MapPin,
  AlertTriangle,
  Route,
  ChevronRight,
  Shield,
  Compass,
  ThumbsUp,
  ThumbsDown,
  Navigation,
  RefreshCw,
  PlusCircle,
  AlertOctagon,
  Sparkles,
  Activity,
  HeartPulse,
  Phone,
} from "lucide-react";

interface LiveIncidentMapScreenProps {
  incidents: Incident[];
  onSelectIncident: (incident: Incident) => void;
  onNavigate: (screen: ScreenId) => void;
  isDemoMode?: boolean;
  onToggleDemoMode?: () => void;
  onVoteIncident?: (incidentId: string, type: "confirm" | "reject") => void;
}

// Sample corridor routes for live map visualization
const STATIC_ROUTE_A_PATH: [number, number][] = [
  [26.1445, 91.7362], // Guwahati
  [26.1112, 92.1001], // Jagiroad
  [25.132, 92.361],  // Sonapur Landslide hazard
  [24.8333, 92.7789], // Silchar destination
];

const STATIC_ROUTE_B_PATH: [number, number][] = [
  [26.1445, 91.7362], // Guwahati
  [26.345, 92.684],  // Nagaon Bypass
  [25.180, 93.020],  // Haflong Green Corridor
  [24.8333, 92.7789], // Silchar destination
];

const OVERLAY_OPTIONS: {
  id: MapOverlayLayer;
  label: MapOverlayLayer;
  badge: string;
  description: string;
}[] = [
  {
    id: "Traffic Density",
    label: "Traffic Density",
    badge: "4 Corridors",
    description: "Live highway speed telemetry, congestion bottlenecks, and green-corridor flow rates.",
  },
  {
    id: "Hazard Zones",
    label: "Hazard Zones",
    badge: "Geofenced",
    description: "Active landslide & flood exclusion perimeters with AI-calculated impact radii.",
  },
  {
    id: "Relief Centers",
    label: "Relief Centers",
    badge: "5 Camps",
    description: "NDRF/SDMA emergency shelters, trauma triage units, and relief supply stockpiles.",
  },
];

export const LiveIncidentMapScreen: React.FC<LiveIncidentMapScreenProps> = ({
  incidents,
  onSelectIncident,
  onNavigate,
  isDemoMode = false,
  onToggleDemoMode,
  onVoteIncident,
}) => {
  const [selectedFilter, setSelectedFilter] = useState<string>("All");
  const [activeOverlay, setActiveOverlay] = useState<MapOverlayLayer>("Hazard Zones");
  const [focusLocation, setFocusLocation] = useState<{ lat: number; lng: number; zoom?: number } | null>(null);
  const [activeReliefCenter, setActiveReliefCenter] = useState<ReliefCenterItem | null>(
    DEFAULT_RELIEF_CENTERS[0]
  );
  const [activeTrafficSegment, setActiveTrafficSegment] = useState<TrafficDensitySegment | null>(
    DEFAULT_TRAFFIC_SEGMENTS[0]
  );
  const [activePopupIncident, setActivePopupIncident] = useState<Incident | null>(
    incidents.length > 0 ? incidents[0] : null
  );

  // Live Device GPS
  const { location: userGps, refreshGPS } = useDeviceGPS(isDemoMode);

  // Live Meteorological Telemetry
  const {
    weather,
    isLoading: weatherLoading,
    error: weatherError,
    refetch: refetchWeather,
  } = useRealWeather(userGps.lat, userGps.lng, userGps.formattedAddress, isDemoMode);

  const filteredIncidents = useMemo(() => {
    if (!incidents || !Array.isArray(incidents)) return [];
    if (selectedFilter === "All") return incidents;
    return incidents.filter((i) => i.type === selectedFilter || i.incidentType === selectedFilter);
  }, [incidents, selectedFilter]);

  const handleVote = async (incidentId: string, action: "confirm" | "reject") => {
    if (onVoteIncident) {
      onVoteIncident(incidentId, action);
    }
    await voteServerIncident(incidentId, action);

    // Update active incident in-place
    if (activePopupIncident && activePopupIncident.id === incidentId) {
      const conf = activePopupIncident.crowdVerification.confirmations + (action === "confirm" ? 1 : 0);
      const rej = activePopupIncident.crowdVerification.rejections + (action === "reject" ? 1 : 0);
      const total = conf + rej;
      setActivePopupIncident({
        ...activePopupIncident,
        crowdVerification: {
          confirmations: conf,
          rejections: rej,
          confidenceScore: total > 0 ? Math.round((conf / total) * 100) : 50,
        },
      });
    }
  };

  return (
    <div className="flex flex-col h-full space-y-4 p-4 pb-12 max-w-4xl mx-auto">
      {/* Top Header & GIS Status */}
      <div className="vrq-card p-4 flex items-center justify-between gap-2">
        <div>
          <div className="flex items-center gap-2">
            <Compass className="w-4 h-4 text-[#06B6D4]" />
            <h2 className="text-sm font-bold text-white tracking-tight">
              Interactive Disaster GIS & Road Condition Map
            </h2>
          </div>
          <p className="text-[11px] text-slate-400 mt-0.5 font-medium">
            Real-time hazard telemetry, crowd-verified road closures, and live GPS positioning.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <span className="px-3 py-1 rounded-full text-[10px] font-bold border bg-[#10B981]/15 text-[#10B981] border-[#10B981]/30 flex items-center gap-1.5 shadow-sm">
            <span className="w-1.5 h-1.5 rounded-full bg-[#10B981] animate-pulse" />
            <span>GIS LIVE</span>
          </span>
        </div>
      </div>

      {/* Real Weather Telemetry Bar */}
      <RealWeatherWidget
        weather={weather}
        isLoading={weatherLoading}
        error={weatherError}
        onRefresh={refetchWeather}
        compact={true}
      />

      {/* Filter Category Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
        {["All", "Landslide", "Flood", "Bridge Damage", "Traffic Blockage"].map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedFilter(cat)}
            className={`px-3.5 py-1.5 rounded-xl flex-shrink-0 font-bold transition-all duration-200 active:scale-95 text-xs border cursor-pointer ${
              selectedFilter === cat
                ? "bg-gradient-to-r from-[#2563EB] to-[#06B6D4] text-white border-[#06B6D4]/50 shadow-[0_4px_14px_rgba(37,99,235,0.35)]"
                : "bg-[#0B1126]/85 text-slate-400 border-white/[0.08] hover:text-white hover:bg-white/[0.08]"
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Layer Toggle Control ('Traffic Density', 'Hazard Zones', 'Relief Centers') */}
      <div className="vrq-card p-3.5 space-y-3" data-testid="map-layer-toggle-control">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-[#2563EB]/20 border border-[#06B6D4]/30 flex items-center justify-center text-[#06B6D4]">
              <Layers className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-extrabold text-white tracking-tight block">
                GIS Map Overlay Layer
              </span>
              <span className="text-[10px] text-slate-400 block">
                {OVERLAY_OPTIONS.find((o) => o.id === activeOverlay)?.description}
              </span>
            </div>
          </div>

          <span className="px-2.5 py-1 rounded-lg bg-[#050816]/90 border border-white/[0.08] text-[10px] font-bold text-[#06B6D4]">
            Active: {activeOverlay}
          </span>
        </div>

        {/* 3-Way Segmented Overlay Switcher */}
        <div
          role="group"
          aria-label="Map overlay layer toggle"
          className="grid grid-cols-3 gap-2 p-1 rounded-xl bg-[#050816]/90 border border-white/[0.08]"
        >
          {OVERLAY_OPTIONS.map((option) => {
            const isActive = activeOverlay === option.id;
            const Icon =
              option.id === "Traffic Density"
                ? Activity
                : option.id === "Hazard Zones"
                ? AlertTriangle
                : HeartPulse;
            return (
              <button
                key={option.id}
                type="button"
                onClick={() => setActiveOverlay(option.id)}
                aria-pressed={isActive}
                className={`py-2 px-2.5 rounded-lg text-xs font-bold transition-all duration-200 flex items-center justify-center gap-1.5 cursor-pointer active:scale-95 ${
                  isActive
                    ? "bg-gradient-to-r from-[#2563EB] to-[#06B6D4] text-white shadow-[0_4px_14px_rgba(6,182,212,0.3)] border border-white/20"
                    : "text-slate-400 hover:text-white hover:bg-white/[0.04]"
                }`}
              >
                <Icon
                  className={`w-3.5 h-3.5 shrink-0 ${
                    isActive
                      ? "text-white"
                      : option.id === "Traffic Density"
                      ? "text-[#F59E0B]"
                      : option.id === "Hazard Zones"
                      ? "text-[#EF4444]"
                      : "text-[#10B981]"
                  }`}
                />
                <span className="truncate">{option.label}</span>
                <span
                  className={`hidden sm:inline-block text-[9px] px-1.5 py-0.5 rounded-md font-extrabold ${
                    isActive
                      ? "bg-slate-950/35 text-cyan-100"
                      : "bg-slate-900 text-slate-400"
                  }`}
                >
                  {option.badge}
                </span>
              </button>
            );
          })}
        </div>

        {/* Contextual Quick-Inspect Chips for Active Overlay */}
        {activeOverlay === "Traffic Density" && (
          <div className="pt-1 space-y-2">
            <div className="flex items-center justify-between text-[11px]">
              <span className="text-slate-400 font-semibold">
                Corridor Flow Telemetry (Click to focus on map):
              </span>
              <span className="text-[10px] font-mono text-[#F59E0B] font-bold">
                Avg Speed: 29.5 km/h
              </span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {DEFAULT_TRAFFIC_SEGMENTS.map((seg) => {
                const isSelected = activeTrafficSegment?.id === seg.id;
                return (
                  <button
                    key={seg.id}
                    type="button"
                    onClick={() => {
                      setActiveTrafficSegment(seg);
                      setFocusLocation({ lat: seg.midpoint[0], lng: seg.midpoint[1], zoom: 10 });
                    }}
                    className={`p-2.5 rounded-xl text-left border transition-all cursor-pointer flex items-center justify-between gap-2 ${
                      isSelected
                        ? "bg-[#0B1126] border-[#06B6D4]/50 shadow-md"
                        : "bg-[#050816]/70 border-white/[0.06] hover:border-white/20"
                    }`}
                  >
                    <div className="min-w-0">
                      <div className="text-[11px] font-bold text-white truncate">
                        {seg.corridorName}
                      </div>
                      <div className="text-[10px] text-slate-400 flex items-center gap-1.5 mt-0.5">
                        <span
                          className="w-2 h-2 rounded-full shrink-0"
                          style={{ backgroundColor: seg.color }}
                        />
                        <span>{seg.congestionLevel}</span>
                        {seg.queueLengthKm > 0 && (
                          <span className="text-slate-500">• {seg.queueLengthKm} km queue</span>
                        )}
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <span
                        className="text-xs font-extrabold font-mono block"
                        style={{ color: seg.color }}
                      >
                        {seg.avgSpeedKmh} km/h
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono">
                        {seg.densityPercent}% load
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {activeOverlay === "Hazard Zones" && (
          <div className="pt-1 flex flex-wrap items-center justify-between gap-2 text-[11px] bg-[#050816]/70 p-2.5 rounded-xl border border-white/[0.06]">
            <div className="flex flex-wrap items-center gap-3">
              <span className="flex items-center gap-1.5 text-red-300 font-bold">
                <span className="w-2.5 h-2.5 rounded-full bg-[#EF4444] animate-pulse" />
                Critical Zone: 6.5 km Radius
              </span>
              <span className="flex items-center gap-1.5 text-amber-300 font-bold">
                <span className="w-2.5 h-2.5 rounded-full bg-[#F59E0B]" />
                High Buffer: 4.5 km Radius
              </span>
            </div>
            <span className="text-[10px] font-mono text-slate-400">
              {filteredIncidents.length} Active Perimeters Monitored
            </span>
          </div>
        )}

        {activeOverlay === "Relief Centers" && (
          <div className="pt-1 space-y-2">
            <div className="flex items-center justify-between text-[11px]">
              <span className="text-slate-400 font-semibold">
                Verified NDRF / SDMA Relief Shelters (Click to locate):
              </span>
              <span className="text-[10px] font-mono text-[#10B981] font-bold">
                1,847 Total Beds Free
              </span>
            </div>
            <div className="flex items-center gap-2 overflow-x-auto pb-1">
              {DEFAULT_RELIEF_CENTERS.map((rc) => {
                const isSelected = activeReliefCenter?.id === rc.id;
                return (
                  <button
                    key={rc.id}
                    type="button"
                    onClick={() => {
                      setActiveReliefCenter(rc);
                      setFocusLocation({ lat: rc.lat, lng: rc.lng, zoom: 11 });
                    }}
                    className={`p-2.5 rounded-xl text-left border transition-all shrink-0 w-56 cursor-pointer ${
                      isSelected
                        ? "bg-[#0B1126] border-[#10B981]/60 shadow-md"
                        : "bg-[#050816]/70 border-white/[0.06] hover:border-white/20"
                    }`}
                  >
                    <div className="flex items-center justify-between gap-1 mb-1">
                      <span className="px-1.5 py-0.5 rounded bg-[#10B981]/20 text-[#10B981] text-[9px] font-extrabold">
                        ✚ {rc.status}
                      </span>
                      <span className="text-[10px] font-mono font-bold text-cyan-300">
                        {rc.stockpilePercent}% Stocked
                      </span>
                    </div>
                    <div className="text-xs font-bold text-white truncate">{rc.name}</div>
                    <div className="text-[10px] text-slate-400 flex items-center justify-between mt-1">
                      <span>
                        <b className="text-[#10B981]">{rc.availableBeds}</b>/{rc.capacityBeds} beds
                      </span>
                      <span className="font-mono text-slate-400 flex items-center gap-0.5">
                        <Phone className="w-2.5 h-2.5 text-[#06B6D4]" />
                        {rc.contactPhone}
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* Full Interactive Map Container */}
      <div className="relative rounded-2xl overflow-hidden border border-white/[0.1] bg-[#050816] shadow-2xl">
        <DisasterInteractiveMap
          incidents={filteredIncidents}
          userLocation={{
            lat: userGps.lat,
            lng: userGps.lng,
            formattedAddress: userGps.formattedAddress,
            isRealGPS: userGps.isRealGPS,
          }}
          routeAPath={STATIC_ROUTE_A_PATH}
          routeBPath={STATIC_ROUTE_B_PATH}
          onSelectIncident={(inc) => setActivePopupIncident(inc)}
          heightClass="h-[420px]"
          isDemoMode={isDemoMode}
          activeOverlay={activeOverlay}
          onOverlayChange={setActiveOverlay}
          reliefCenters={DEFAULT_RELIEF_CENTERS}
          trafficSegments={DEFAULT_TRAFFIC_SEGMENTS}
          focusLocation={focusLocation}
        />

        {/* Floating Route & Active Overlay Legend HUD on Map */}
        <div className="absolute top-12 left-3 z-[1000] flex flex-wrap items-center gap-1.5 pointer-events-none">
          <div className="px-3 py-1.5 rounded-xl bg-[#050816]/90 border border-white/[0.12] text-[10px] font-bold text-slate-200 backdrop-blur-xl shadow-lg flex items-center gap-2">
            {activeOverlay === "Traffic Density" ? (
              <>
                <span className="flex items-center gap-1.5 text-[#EF4444]">
                  <span className="w-2 h-2 rounded-full bg-[#EF4444] inline-block" />
                  NH-6 Jam (8 km/h)
                </span>
                <span className="text-slate-600">|</span>
                <span className="flex items-center gap-1.5 text-[#10B981]">
                  <span className="w-2 h-2 rounded-full bg-[#10B981] inline-block" />
                  Green Bypass (58 km/h)
                </span>
              </>
            ) : activeOverlay === "Relief Centers" ? (
              <>
                <span className="flex items-center gap-1.5 text-[#10B981]">
                  <span className="w-2 h-2 rounded-full bg-[#10B981] inline-block" />
                  5 Active NDRF/SDMA Camps
                </span>
                <span className="text-slate-600">|</span>
                <span className="text-cyan-300">Medical & Ration Hubs</span>
              </>
            ) : (
              <>
                <span className="flex items-center gap-1.5 text-[#10B981]">
                  <span className="w-2 h-2 rounded-full bg-[#10B981] inline-block" />
                  Route B Safe Bypass
                </span>
                <span className="text-slate-600">|</span>
                <span className="flex items-center gap-1.5 text-[#EF4444]">
                  <span className="w-2 h-2 rounded-full bg-[#EF4444] inline-block" />
                  Route A Direct Hazard
                </span>
              </>
            )}
          </div>
        </div>

        {/* Floating Safe Route Trigger Button */}
        <button
          id="floating-calculate-safe-route-btn"
          onClick={() => onNavigate("smart_route")}
          className="absolute bottom-4 right-4 z-[1000] px-4 py-2 rounded-xl bg-gradient-to-r from-[#2563EB] to-[#06B6D4] hover:opacity-95 text-white font-bold text-xs shadow-2xl flex items-center gap-2 transition-all duration-200 hover:scale-105 active:scale-95 border border-white/20 backdrop-blur-md cursor-pointer group"
        >
          <Route className="w-4 h-4 text-white" />
          <span>Calculate Safe Route</span>
          <ChevronRight className="w-3.5 h-3.5 text-cyan-100" />
        </button>
      </div>

      {/* Active Incident Inspection Card */}
      {activePopupIncident ? (
        <div className="vrq-card p-4 space-y-3">
          <div className="flex items-start justify-between gap-2">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="px-2 py-0.5 rounded-lg bg-[#F59E0B]/15 text-[#F59E0B] border border-[#F59E0B]/30 text-[10px] font-bold">
                  {activePopupIncident.type || activePopupIncident.incidentType}
                </span>
                <span className="text-[11px] text-slate-400 font-medium">
                  · {activePopupIncident.reportedAt} ·
                </span>
                <span className="text-[10px] font-bold text-[#10B981]">
                  {activePopupIncident.status}
                </span>
              </div>
              <h3 className="text-sm font-bold text-white tracking-tight">{activePopupIncident.title}</h3>
              <div className="flex flex-wrap items-center gap-x-2 gap-y-1 mt-1 text-xs text-slate-400">
                <span className="flex items-center gap-1 min-w-0">
                  <MapPin className="w-3.5 h-3.5 text-[#06B6D4] shrink-0" />
                  <span className="truncate text-slate-200 font-medium">{activePopupIncident.locationName}</span>
                </span>
                <span className="font-mono text-[10px] text-[#06B6D4] bg-[#050816] px-2 py-0.5 rounded-lg border border-white/[0.08]">
                  {activePopupIncident.lat.toFixed(4)}° N, {activePopupIncident.lng.toFixed(4)}° E
                </span>
              </div>
            </div>

            <div className="text-right shrink-0">
              <span className="text-lg font-extrabold font-mono text-[#F59E0B] block leading-tight">
                {activePopupIncident.aiAnalysis?.riskScore || 50}%
              </span>
              <span className="text-[10px] text-slate-400 font-medium block">Risk Rating</span>
            </div>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed font-medium">
            {activePopupIncident.aiAnalysis?.summary || activePopupIncident.description}
          </p>

          {/* Crowd Verification Actions */}
          <div className="pt-3 border-t border-white/[0.08] flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 flex-1">
              <button
                onClick={() => handleVote(activePopupIncident.id, "confirm")}
                className="flex-1 py-2 px-3 rounded-xl bg-[#050816]/80 hover:bg-[#10B981]/15 text-[#10B981] border border-[#10B981]/30 text-xs font-bold flex items-center justify-center gap-1.5 transition-all active:scale-95 cursor-pointer"
              >
                <ThumbsUp className="w-3.5 h-3.5 text-[#10B981]" />
                <span>Confirm ({activePopupIncident.crowdVerification?.confirmations || 0})</span>
              </button>

              <button
                onClick={() => handleVote(activePopupIncident.id, "reject")}
                className="flex-1 py-2 px-3 rounded-xl bg-[#050816]/80 hover:bg-[#EF4444]/15 text-[#EF4444] border border-[#EF4444]/30 text-xs font-bold flex items-center justify-center gap-1.5 transition-all active:scale-95 cursor-pointer"
              >
                <ThumbsDown className="w-3.5 h-3.5 text-[#EF4444]" />
                <span>Dispute ({activePopupIncident.crowdVerification?.rejections || 0})</span>
              </button>
            </div>

            <button
              onClick={() => {
                onSelectIncident(activePopupIncident);
                onNavigate("incident_details");
              }}
              className="py-2 px-4 rounded-xl bg-gradient-to-r from-[#2563EB] to-[#06B6D4] hover:opacity-95 text-white font-bold text-xs flex items-center gap-1 transition-all active:scale-95 shadow-md cursor-pointer"
            >
              <span>Inspect</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      ) : (
        <div className="p-4 vrq-card text-xs text-slate-300 flex items-center justify-between">
          <span>Select any hazard pin on the map to inspect ground conditions.</span>
          <button
            onClick={() => onNavigate("report")}
            className="px-3.5 py-2 bg-gradient-to-r from-[#2563EB] to-[#06B6D4] text-white font-bold text-xs rounded-xl flex items-center gap-1.5 transition-all active:scale-95 shadow-sm cursor-pointer"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            <span>Report Incident</span>
          </button>
        </div>
      )}

      {/* Quick Navigation Footer */}
      <div className="grid grid-cols-2 gap-3 pt-1">
        <button
          onClick={() => onNavigate("emergency")}
          className="py-3 px-4 rounded-2xl bg-[#EF4444]/15 hover:bg-[#EF4444]/25 text-red-200 font-bold text-xs flex items-center justify-center gap-2 border border-[#EF4444]/35 transition-all active:scale-95 cursor-pointer"
        >
          <AlertOctagon className="w-4 h-4 text-[#EF4444]" />
          <span>Emergency SOS</span>
        </button>

        <button
          onClick={() => onNavigate("smart_route")}
          className="py-3 px-4 vrq-card-interactive text-slate-100 font-bold text-xs flex items-center justify-center gap-2 cursor-pointer"
        >
          <Route className="w-4 h-4 text-[#10B981]" />
          <span>Safe Route Bypass</span>
        </button>
      </div>
    </div>
  );
};
