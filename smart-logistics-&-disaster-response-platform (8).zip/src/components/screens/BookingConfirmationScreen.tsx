import React, { useState } from "react";
import { ScreenId, TransportBooking } from "../../types";
import { INITIAL_INCIDENTS } from "../../mockData";
import { DisasterInteractiveMap } from "../map/DisasterInteractiveMap";
import {
  Shield,
  Truck,
  MapPin,
  Clock,
  Route,
  AlertTriangle,
  CheckCircle2,
  AlertOctagon,
  ArrowRight,
  Package,
  Sparkles,
  Phone,
  User,
  Radio,
} from "lucide-react";

interface BookingConfirmationScreenProps {
  booking: TransportBooking | null;
  onNavigate: (screen: ScreenId) => void;
  onConfirmBooking: (bookingId: string) => void;
}

export const BookingConfirmationScreen: React.FC<BookingConfirmationScreenProps> = ({
  booking,
  onNavigate,
  onConfirmBooking,
}) => {
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!booking) {
    return (
      <div className="p-6 text-center space-y-4">
        <p className="text-sm text-slate-400">No active transport booking found.</p>
        <button
          onClick={() => onNavigate("book_transport")}
          className="px-4 py-2 bg-orange-600 hover:bg-orange-500 text-white rounded-xl text-xs font-bold"
        >
          Go to Booking
        </button>
      </div>
    );
  }

  const handleConfirm = () => {
    setIsSubmitting(true);
    setTimeout(() => {
      onConfirmBooking(booking.bookingId);
      setIsSubmitting(false);
      onNavigate("booking_tracking");
    }, 800);
  };

  const isLowRisk = booking.routeDetails.riskScore <= 30;
  const isHighRisk = booking.routeDetails.riskScore >= 71;

  return (
    <div className="p-4 space-y-4 pb-12 text-slate-100">
      {/* Header */}
      <div className="vrq-card p-4 flex items-center justify-between">
        <div>
          <span className="text-[10px] font-bold text-[#06B6D4] uppercase tracking-wider block">
            Step 6: Review & Finalize
          </span>
          <h2 className="text-base font-extrabold text-white">Smart Logistics Booking</h2>
        </div>
        <span className="text-[10px] font-mono px-2.5 py-1 rounded-xl bg-[#050816]/90 text-slate-300 border border-white/[0.08]">
          {booking.bookingId}
        </span>
      </div>

      {/* Emergency Priority Highlight */}
      {booking.isEmergency && (
        <div className="vrq-card border-[#EF4444]/60 p-3.5 flex items-center gap-3 shadow-[0_8px_24px_rgba(239,68,68,0.2)]">
          <div className="w-10 h-10 rounded-xl bg-[#EF4444]/20 text-[#EF4444] border border-[#EF4444]/35 flex items-center justify-center flex-shrink-0 animate-pulse">
            <AlertOctagon className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full bg-[#EF4444] text-white">
                🚨 EMERGENCY PRIORITY
              </span>
              <span className="text-[11px] text-red-300 font-bold">Green Corridor Clearance</span>
            </div>
            <p className="text-[10px] text-slate-300 mt-1">
              Priority signal preemption, BRO heavy recovery escort, and toll-free transit enabled.
            </p>
          </div>
        </div>
      )}

      {/* Main Confirmation Receipt Card */}
      <div className="vrq-card p-4 space-y-4 relative overflow-hidden">
        {/* Subtle Watermark Badge */}
        <div className="absolute -right-6 -bottom-6 w-32 h-32 bg-[#2563EB]/10 rounded-full blur-2xl pointer-events-none" />

        <div className="text-center pb-3 border-b border-white/[0.08]">
          <span className="text-xs font-black tracking-widest text-slate-300 uppercase block">
            CONFIRMATION OVERVIEW
          </span>
          <p className="text-[11px] text-slate-400 mt-0.5">
            Validated against live National Highway landslide telemetry
          </p>
        </div>

        {/* Origin & Destination */}
        <div className="space-y-2.5">
          <div className="flex items-start gap-3">
            <div className="w-7 h-7 rounded-xl bg-[#10B981]/15 text-[#10B981] border border-[#10B981]/30 flex items-center justify-center flex-shrink-0 mt-0.5">
              <MapPin className="w-3.5 h-3.5" />
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Pickup Location</span>
              <span className="text-xs font-extrabold text-white">{booking.pickupLocation.name}</span>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="w-7 h-7 rounded-xl bg-[#06B6D4]/15 text-[#06B6D4] border border-[#06B6D4]/30 flex items-center justify-center flex-shrink-0 mt-0.5">
              <MapPin className="w-3.5 h-3.5" />
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Destination</span>
              <span className="text-xs font-extrabold text-white">{booking.destinationLocation.name}</span>
            </div>
          </div>
        </div>

        {/* Confirmed Corridor Route Google Map Preview */}
        <div className="space-y-1.5 pt-1">
          <div className="flex items-center justify-between text-[11px] font-bold text-slate-300">
            <span className="flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-[#10B981]" />
              <span>Confirmed Relief Corridor Map</span>
            </span>
            <span className="text-[10px] text-slate-400 font-normal">Google Maps / GIS Live</span>
          </div>
          <DisasterInteractiveMap
            incidents={INITIAL_INCIDENTS}
            pickupLocation={{ lat: booking.pickupLocation.lat, lng: booking.pickupLocation.lng, name: booking.pickupLocation.name }}
            destinationLocation={{ lat: booking.destinationLocation.lat, lng: booking.destinationLocation.lng, name: booking.destinationLocation.name }}
            routeAPath={booking.routeDetails?.pathCoordinates}
            userLocation={{ lat: booking.pickupLocation.lat, lng: booking.pickupLocation.lng }}
            heightClass="h-44 sm:h-52"
          />
        </div>

        {/* Key Metrics Grid */}
        <div className="grid grid-cols-2 gap-2.5 pt-3 border-t border-white/[0.08] text-xs">
          <div className="bg-[#050816]/85 p-3 rounded-xl border border-white/[0.08]">
            <span className="text-[9px] uppercase font-bold text-slate-400 block">Vehicle</span>
            <div className="flex items-center gap-1.5 mt-1">
              <Truck className="w-3.5 h-3.5 text-[#06B6D4]" />
              <span className="font-extrabold text-white">{booking.vehicleType}</span>
            </div>
          </div>

          <div className="bg-[#050816]/85 p-3 rounded-xl border border-white/[0.08]">
            <span className="text-[9px] uppercase font-bold text-slate-400 block">Distance</span>
            <div className="flex items-center gap-1.5 mt-1">
              <Route className="w-3.5 h-3.5 text-[#06B6D4]" />
              <span className="font-extrabold text-white">{booking.distanceKm} km</span>
            </div>
          </div>

          <div className="bg-[#050816]/85 p-3 rounded-xl border border-white/[0.08]">
            <span className="text-[9px] uppercase font-bold text-slate-400 block">Trip Purpose</span>
            <div className="flex items-center gap-1.5 mt-1">
              <Shield className="w-3.5 h-3.5 text-[#2563EB]" />
              <span className="font-extrabold text-white truncate">{booking.purpose}</span>
            </div>
          </div>

          <div className="bg-[#050816]/85 p-3 rounded-xl border border-white/[0.08]">
            <span className="text-[9px] uppercase font-bold text-slate-400 block">Priority Tier</span>
            <div className="flex items-center gap-1.5 mt-1">
              <span
                className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-full ${
                  booking.priority === "EMERGENCY"
                    ? "bg-[#EF4444]/20 text-[#EF4444] border border-[#EF4444]/35"
                    : booking.priority === "URGENT"
                    ? "bg-[#F59E0B]/20 text-[#F59E0B] border border-[#F59E0B]/35"
                    : "bg-white/[0.08] text-slate-300 border border-white/10"
                }`}
              >
                {booking.priority}
              </span>
            </div>
          </div>

          <div className="bg-[#050816]/85 p-3 rounded-xl border border-white/[0.08]">
            <span className="text-[9px] uppercase font-bold text-slate-400 block">Estimated Time</span>
            <div className="flex items-center gap-1.5 mt-1">
              <Clock className="w-3.5 h-3.5 text-[#F59E0B]" />
              <span className="font-extrabold text-white">
                {Math.floor(booking.estimatedMinutes / 60)} hr {booking.estimatedMinutes % 60} min
              </span>
            </div>
          </div>

          <div className="bg-[#050816]/85 p-3 rounded-xl border border-white/[0.08]">
            <span className="text-[9px] uppercase font-bold text-slate-400 block">Recommended Route</span>
            <div className="flex items-center gap-1.5 mt-1">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#10B981]" />
              <span className="font-extrabold text-white">{booking.selectedRoute}</span>
            </div>
          </div>
        </div>

        {/* Risk Score Assessment Badge */}
        <div
          className={`p-3.5 rounded-2xl border flex items-center justify-between ${
            isLowRisk
              ? "bg-[#10B981]/15 border-[#10B981]/35 text-emerald-300"
              : isHighRisk
              ? "bg-[#EF4444]/15 border-[#EF4444]/35 text-red-300"
              : "bg-[#F59E0B]/15 border-[#F59E0B]/35 text-amber-300"
          }`}
        >
          <div>
            <span className="text-[9px] uppercase font-bold block opacity-80">Route Risk Score</span>
            <span className="text-sm font-black">
              {booking.routeDetails.riskScore}/100 - {booking.routeDetails.riskLevel}
            </span>
          </div>
          <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-white/10">
            {booking.routeDetails.roadAccessibility}
          </span>
        </div>

        {/* Package info if available */}
        {booking.packageInfo?.description && (
          <div className="bg-[#050816]/85 p-3 rounded-xl border border-white/[0.08] text-xs">
            <div className="flex items-center gap-1.5 text-slate-400 text-[10px] uppercase font-bold mb-1">
              <Package className="w-3.5 h-3.5 text-[#06B6D4]" />
              <span>Package & Consignment:</span>
            </div>
            <p className="text-slate-200 font-medium">{booking.packageInfo.description}</p>
            {booking.packageInfo.weightKg && (
              <span className="text-[10px] text-slate-400 mt-0.5 block">
                Total Weight: {booking.packageInfo.weightKg} kg •{" "}
                {booking.packageInfo.isFragileOrPerishable ? "⚠️ Perishable / Medical" : "Standard Cargo"}
              </span>
            )}
          </div>
        )}

        {/* Fare Summary Breakdown */}
        <div className="pt-2.5 border-t border-white/[0.08] space-y-1.5 text-xs">
          <div className="flex justify-between text-slate-400 text-[11px]">
            <span>Base Fare:</span>
            <span className="font-mono text-slate-200">
              ₹{booking.fareBreakdown.baseFare.toLocaleString("en-IN")}
            </span>
          </div>
          <div className="flex justify-between text-slate-400 text-[11px]">
            <span>Distance Charge ({booking.distanceKm} km):</span>
            <span className="font-mono text-slate-200">
              ₹{booking.fareBreakdown.distanceCharge.toLocaleString("en-IN")}
            </span>
          </div>
          <div className="flex justify-between text-slate-400 text-[11px]">
            <span>Risk / Safe Detour Charge:</span>
            <span className="font-mono text-slate-200">
              ₹{booking.fareBreakdown.riskDetourCharge.toLocaleString("en-IN")}
            </span>
          </div>

          <div className="pt-2.5 border-t border-white/[0.08] flex items-center justify-between">
            <div>
              <span className="text-xs font-black uppercase text-slate-300 block">
                Estimated Total Fare:
              </span>
              <span className="text-[9px] text-slate-400">
                *Dynamic Relief Fleet Rate (Configured via SDMA Distance & Risk Matrix)
              </span>
            </div>
            <span className="text-2xl font-black font-mono text-[#10B981]">
              ₹{booking.fareBreakdown.totalEstimatedFare.toLocaleString("en-IN")}
            </span>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="space-y-2.5 pt-2">
        <button
          onClick={handleConfirm}
          disabled={isSubmitting}
          className="w-full py-4 px-4 rounded-2xl bg-gradient-to-r from-[#2563EB] via-[#1D4ED8] to-[#06B6D4] hover:brightness-110 text-white font-black text-sm shadow-[0_8px_28px_rgba(37,99,235,0.4)] flex items-center justify-center gap-2 transition vrq-btn-press cursor-pointer border border-[#06B6D4]/40"
        >
          {isSubmitting ? (
            <div className="flex items-center gap-2">
              <Radio className="w-4 h-4 animate-spin text-white" />
              <span>Broadcasting to Verified Relief Drivers...</span>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <span>CONFIRM BOOKING</span>
              <ArrowRight className="w-4 h-4" />
            </div>
          )}
        </button>

        <div className="grid grid-cols-2 gap-2.5">
          <button
            onClick={() => onNavigate("book_transport")}
            className="py-2.5 px-3 bg-[#0b132b]/80 hover:bg-white/[0.08] text-slate-300 rounded-xl text-xs font-semibold border border-white/[0.08] transition text-center vrq-btn-press cursor-pointer"
          >
            ← Modify Route / Vehicle
          </button>
          <button
            onClick={() => onNavigate("driver_dashboard")}
            className="py-2.5 px-3 bg-[#0b132b]/80 hover:bg-white/[0.08] text-[#06B6D4] rounded-xl text-xs font-semibold border border-[#06B6D4]/30 transition text-center vrq-btn-press cursor-pointer"
          >
            View Driver Portal ↗
          </button>
        </div>
      </div>
    </div>
  );
};
