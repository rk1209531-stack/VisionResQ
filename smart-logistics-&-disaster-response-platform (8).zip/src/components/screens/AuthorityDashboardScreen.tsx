import React, { useState } from "react";
import { Incident, ScreenId, UserRole, TransportBooking, VehiclePricingConfig, VehicleType } from "../../types";
import {
  Shield,
  AlertTriangle,
  Flame,
  Activity,
  MapPin,
  Clock,
  ArrowRight,
  CheckCircle,
  Truck,
  Users,
  Compass,
  FileText,
  Sliders,
  DollarSign,
  Save,
  Radio,
  Ambulance,
  CheckCircle2,
  ChevronRight,
  Sparkles,
} from "lucide-react";

interface AuthorityDashboardScreenProps {
  incidents: Incident[];
  onNavigate: (screen: ScreenId) => void;
  onSelectIncident: (incident: Incident) => void;
  bookings?: TransportBooking[];
  vehiclePricing?: VehiclePricingConfig[];
  onUpdateVehiclePricing?: (pricing: VehiclePricingConfig[]) => void;
  onApproveGreenCorridor?: (bookingId: string) => void;
}

export const AuthorityDashboardScreen: React.FC<AuthorityDashboardScreenProps> = ({
  incidents,
  onNavigate,
  onSelectIncident,
  bookings = [],
  vehiclePricing = [],
  onUpdateVehiclePricing,
  onApproveGreenCorridor,
}) => {
  // Pricing Editor State
  const [editingPricing, setEditingPricing] = useState<VehiclePricingConfig[]>(vehiclePricing);
  const [pricingSavedMessage, setPricingSavedMessage] = useState<string | null>(null);
  const [showPricingModal, setShowPricingModal] = useState<boolean>(false);
  const [bookingFilter, setBookingFilter] = useState<"ALL" | "EMERGENCY" | "IN_TRANSIT">("ALL");

  // Keep local pricing state in sync if parent pricing updates
  React.useEffect(() => {
    if (vehiclePricing.length > 0) {
      setEditingPricing(vehiclePricing);
    }
  }, [vehiclePricing]);

  // Handle saving pricing
  const handleSavePricing = () => {
    if (onUpdateVehiclePricing) {
      onUpdateVehiclePricing(editingPricing);
    }
    setPricingSavedMessage("Vehicle base fares & km rates updated successfully!");
    setTimeout(() => setPricingSavedMessage(null), 3000);
  };

  const handlePriceChange = (type: VehicleType, field: "baseFare" | "ratePerKm", value: number) => {
    setEditingPricing((prev) =>
      prev.map((p) => (p.type === type ? { ...p, [field]: value } : p))
    );
  };

  // Compute required KPI buckets
  const activeTotal = incidents.length;
  const highRisk = incidents.filter((i) => i.aiAnalysis.riskScore >= 75);
  const mediumRisk = incidents.filter((i) => i.aiAnalysis.riskScore >= 40 && i.aiAnalysis.riskScore < 75);
  const lowRisk = incidents.filter((i) => i.aiAnalysis.riskScore < 40);

  // Status breakdown
  const reportedCount = incidents.filter((i) => i.status === "Reported").length;
  const verifiedCount = incidents.filter((i) => i.status === "Verified").length;
  const dispatchedCount = incidents.filter((i) => i.status === "Team Dispatched").length;
  const wipCount = incidents.filter((i) => i.status === "Work In Progress").length;
  const resolvedCount = incidents.filter((i) => i.status === "Resolved").length;

  // Logistics Bookings Metrics
  const emergencyBookings = bookings.filter((b) => b.isEmergency);
  const inTransitBookings = bookings.filter((b) => b.status === "Trip Started" || b.status === "On the Way");
  const filteredBookings = bookings.filter((b) => {
    if (bookingFilter === "EMERGENCY") return b.isEmergency;
    if (bookingFilter === "IN_TRANSIT") return b.status === "Trip Started" || b.status === "On the Way";
    return true;
  });

  return (
    <div className="p-4 space-y-4 pb-12 max-w-4xl mx-auto">
      {/* Header Banner */}
      <div className="vrq-card p-4 bg-gradient-to-r from-[#2563EB]/20 via-[#050816]/90 to-[#06B6D4]/20 border-[#06B6D4]/30">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#2563EB] to-[#06B6D4] text-white flex items-center justify-center font-black shadow-[0_6px_18px_rgba(37,99,235,0.4)]">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm font-extrabold text-white tracking-tight">
                  Disaster Command & Control Desk
                </h2>
                <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-[#10B981]/15 text-[#10B981] border border-[#10B981]/30">
                  SDMA / NDRF Cell
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5 font-medium">
                Corridor triage, emergency convoy dispatch, and road clearance verification.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* 4 KPI Stat Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
        {/* Active Incidents */}
        <div className="vrq-card p-3.5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[10px] font-bold">Active Incidents</span>
            <Activity className="w-3.5 h-3.5 text-[#06B6D4]" />
          </div>
          <div className="mt-2">
            <span className="text-2xl font-black font-mono text-white block">{activeTotal}</span>
            <span className="text-[9px] text-slate-400 font-medium">Total registered</span>
          </div>
        </div>

        {/* High Risk Incidents */}
        <div className="vrq-card border-[#EF4444]/30 p-3.5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[10px] font-bold text-[#EF4444]">High Risk (75%+)</span>
            <AlertTriangle className="w-3.5 h-3.5 text-[#EF4444]" />
          </div>
          <div className="mt-2">
            <span className="text-2xl font-black font-mono text-[#EF4444] block">{highRisk.length}</span>
            <span className="text-[9px] text-red-300 font-medium">Immediate hazard</span>
          </div>
        </div>

        {/* Medium Risk Incidents */}
        <div className="vrq-card border-[#F59E0B]/30 p-3.5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[10px] font-bold text-[#F59E0B]">Medium Caution</span>
            <Flame className="w-3.5 h-3.5 text-[#F59E0B]" />
          </div>
          <div className="mt-2">
            <span className="text-2xl font-black font-mono text-[#F59E0B] block">{mediumRisk.length}</span>
            <span className="text-[9px] text-amber-300 font-medium">Monitor roadbed</span>
          </div>
        </div>

        {/* Low Risk Incidents */}
        <div className="vrq-card border-[#10B981]/30 p-3.5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[10px] font-bold text-[#10B981]">Clear / Managed</span>
            <CheckCircle className="w-3.5 h-3.5 text-[#10B981]" />
          </div>
          <div className="mt-2">
            <span className="text-2xl font-black font-mono text-[#10B981] block">{lowRisk.length}</span>
            <span className="text-[9px] text-emerald-300 font-medium">Passable route</span>
          </div>
        </div>
      </div>

      {/* Live Operations GIS Launcher */}
      <div
        onClick={() => onNavigate("live_map")}
        className="cursor-pointer vrq-card p-4 flex items-center justify-between hover:border-[#06B6D4]/40 transition group"
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#2563EB]/20 text-[#06B6D4] border border-[#06B6D4]/30 flex items-center justify-center">
            <MapPin className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-extrabold text-white">Tactical Operations GIS Map</span>
              <span className="text-[9px] font-bold px-2.5 py-0.5 rounded-full bg-[#06B6D4]/15 text-[#06B6D4] border border-[#06B6D4]/30">
                Satellite Layer
              </span>
            </div>
            <p className="text-[11px] text-slate-400 mt-0.5 font-medium">
              Interactive Leaflet GIS with road blockages and green corridors
            </p>
          </div>
        </div>
        <ChevronRight className="w-4 h-4 text-slate-400 group-hover:translate-x-1 transition" />
      </div>

      {/* Verification & AI Diagnostic Triage */}
      <div className="vrq-card p-4 space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-extrabold uppercase tracking-wider text-white flex items-center gap-2">
            <Users className="w-4 h-4 text-[#06B6D4]" />
            <span>Field Intelligence & AI Diagnostic Triage</span>
          </h3>
          <button
            onClick={() => onNavigate("incident_mgmt")}
            className="text-[11px] text-[#06B6D4] hover:text-cyan-300 font-bold flex items-center gap-1 cursor-pointer"
          >
            <span>Manage All ({incidents.length})</span>
            <ChevronRight className="w-3 h-3" />
          </button>
        </div>

        <div className="space-y-2.5 text-xs">
          {(incidents || []).slice(0, 3).map((incident) => (
            <div
              key={incident.id}
              onClick={() => {
                onSelectIncident(incident);
                onNavigate("incident_details");
              }}
              className="cursor-pointer bg-[#050816]/85 hover:bg-white/[0.06] border border-white/[0.08] rounded-2xl p-3 flex items-center justify-between gap-3 transition"
            >
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-white truncate">
                    {incident.title}
                  </span>
                </div>
                <span className="text-[10px] text-slate-400 truncate block mt-0.5">
                  {incident.locationName}
                </span>
              </div>

              <div className="text-right flex-shrink-0">
                <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-[#EF4444]/15 text-[#EF4444] border border-[#EF4444]/30">
                  Risk {incident.aiAnalysis.riskScore}%
                </span>
                <span className="text-[9px] text-[#10B981] font-medium block mt-1">
                  {incident.crowdVerification.confidenceScore}% verified
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Resolution Pipeline (Status Flow) */}
      <div className="vrq-card p-4 space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-extrabold uppercase tracking-wider text-white flex items-center gap-2">
            <Truck className="w-4 h-4 text-[#10B981]" />
            <span>Resolution Progression Pipeline</span>
          </h3>
          <button
            onClick={() => onNavigate("resolution_tracking")}
            className="text-[11px] text-[#10B981] hover:text-emerald-300 font-bold flex items-center gap-1 cursor-pointer"
          >
            <span>Live Timeline</span>
            <ChevronRight className="w-3 h-3" />
          </button>
        </div>

        {/* 5-Stage Status Step Counters */}
        <div className="grid grid-cols-5 gap-2 text-center text-xs">
          <div className="p-2.5 rounded-2xl bg-[#050816]/85 border border-white/[0.08]">
            <span className="font-bold text-white block text-sm">{reportedCount}</span>
            <span className="text-[9px] text-slate-400 font-medium mt-0.5 block">Reported</span>
          </div>
          <div className="p-2.5 rounded-2xl bg-[#050816]/85 border border-white/[0.08]">
            <span className="font-bold text-[#F59E0B] block text-sm">{verifiedCount}</span>
            <span className="text-[9px] text-slate-400 font-medium mt-0.5 block">Verified</span>
          </div>
          <div className="p-2.5 rounded-2xl bg-[#050816]/85 border border-white/[0.08]">
            <span className="font-bold text-[#06B6D4] block text-sm">{dispatchedCount}</span>
            <span className="text-[9px] text-slate-400 font-medium mt-0.5 block">Dispatched</span>
          </div>
          <div className="p-2.5 rounded-2xl bg-[#050816]/85 border border-white/[0.08]">
            <span className="font-bold text-[#2563EB] block text-sm">{wipCount}</span>
            <span className="text-[9px] text-slate-400 font-medium mt-0.5 block">In Progress</span>
          </div>
          <div className="p-2.5 rounded-2xl bg-[#050816]/85 border border-white/[0.08]">
            <span className="font-bold text-[#10B981] block text-sm">{resolvedCount}</span>
            <span className="text-[9px] text-slate-400 font-medium mt-0.5 block">Resolved</span>
          </div>
        </div>
      </div>

      {/* Disaster Logistics Fleet & Corridor Control */}
      <div className="vrq-card p-4 space-y-3.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Truck className="w-4 h-4 text-[#06B6D4]" />
            <h3 className="text-xs font-extrabold uppercase tracking-wider text-white">
              Relief Freight Fleet & Corridor Control
            </h3>
          </div>
          <button
            onClick={() => setShowPricingModal(!showPricingModal)}
            className="text-[10px] font-bold px-2.5 py-1 rounded-xl bg-[#06B6D4]/15 text-[#06B6D4] border border-[#06B6D4]/30 hover:bg-[#06B6D4]/25 flex items-center gap-1 transition cursor-pointer"
          >
            <Sliders className="w-3 h-3" />
            <span>{showPricingModal ? "Close Rates" : "Configure Fares"}</span>
          </button>
        </div>

        <p className="text-[11px] text-slate-400 font-medium">
          Authority oversight on emergency convoys, civilian hauliers, and green corridor approvals.
        </p>

        {/* Logistics KPI Mini Grid */}
        <div className="grid grid-cols-4 gap-2 text-center text-xs">
          <div className="p-2.5 rounded-2xl bg-[#050816]/85 border border-white/[0.08]">
            <span className="font-mono font-bold text-white block text-sm">{bookings.length}</span>
            <span className="text-[9px] text-slate-400 font-medium">Total</span>
          </div>
          <div className="p-2.5 rounded-2xl bg-[#EF4444]/15 border border-[#EF4444]/30">
            <span className="font-mono font-bold text-[#EF4444] block text-sm">{emergencyBookings.length}</span>
            <span className="text-[9px] text-red-300 font-medium">SOS Priority</span>
          </div>
          <div className="p-2.5 rounded-2xl bg-[#2563EB]/15 border border-[#06B6D4]/30">
            <span className="font-mono font-bold text-[#06B6D4] block text-sm">{inTransitBookings.length}</span>
            <span className="text-[9px] text-cyan-200 font-medium">In Transit</span>
          </div>
          <div className="p-2.5 rounded-2xl bg-[#10B981]/15 border border-[#10B981]/30">
            <span className="font-mono font-bold text-[#10B981] block text-sm">
              {bookings.filter((b) => b.status === "Completed").length}
            </span>
            <span className="text-[9px] text-emerald-300 font-medium">Delivered</span>
          </div>
        </div>

        {/* Pricing Configuration Panel */}
        {showPricingModal && (
          <div className="bg-[#050816]/90 border border-white/[0.08] rounded-2xl p-3.5 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold text-[#06B6D4] uppercase tracking-wider flex items-center gap-1.5">
                <DollarSign className="w-3.5 h-3.5" />
                Configure Vehicle Pricing & Rate per KM
              </span>
              <button
                onClick={handleSavePricing}
                className="px-3 py-1 rounded-xl bg-[#10B981] hover:bg-emerald-500 text-white text-[10px] font-bold flex items-center gap-1 transition cursor-pointer"
              >
                <Save className="w-3 h-3" />
                <span>Save Rates</span>
              </button>
            </div>

            {pricingSavedMessage && (
              <div className="p-2 rounded-xl bg-[#10B981]/20 border border-[#10B981] text-emerald-300 text-[10px] font-bold text-center">
                ✓ {pricingSavedMessage}
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              {editingPricing.map((veh) => (
                <div
                  key={veh.type}
                  className="p-2.5 rounded-xl bg-[#0b132b]/80 border border-white/[0.08] flex items-center justify-between"
                >
                  <div>
                    <span className="font-bold text-white block text-[11px]">{veh.type}</span>
                    <span className="text-[9px] text-slate-400">{veh.capacity.slice(0, 24)}...</span>
                  </div>
                  <div className="flex items-center gap-2 text-[10px]">
                    <div>
                      <span className="text-[8px] text-slate-400 block">Base (₹)</span>
                      <input
                        type="number"
                        value={veh.baseFare}
                        onChange={(e) =>
                          handlePriceChange(veh.type, "baseFare", parseInt(e.target.value) || 0)
                        }
                        className="w-16 bg-[#050816] border border-white/10 rounded-lg px-2 py-1 text-white font-mono"
                      />
                    </div>
                    <div>
                      <span className="text-[8px] text-slate-400 block">/km (₹)</span>
                      <input
                        type="number"
                        value={veh.ratePerKm}
                        onChange={(e) =>
                          handlePriceChange(veh.type, "ratePerKm", parseInt(e.target.value) || 0)
                        }
                        className="w-16 bg-[#050816] border border-white/10 rounded-lg px-2 py-1 text-white font-mono"
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Live Booking Monitor with filter */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="text-[10px] font-bold text-slate-400 uppercase">Live Transits:</span>
            <div className="flex items-center gap-1.5">
              {(["ALL", "EMERGENCY", "IN_TRANSIT"] as const).map((tab) => (
                <button
                  key={tab}
                  onClick={() => setBookingFilter(tab)}
                  className={`px-2.5 py-1 rounded-lg text-[9px] font-bold transition cursor-pointer ${
                    bookingFilter === tab
                      ? "bg-[#2563EB] text-white"
                      : "bg-[#050816] text-slate-400 hover:text-white border border-white/[0.06]"
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
            {filteredBookings.map((b) => (
              <div
                key={b.bookingId}
                className="p-3 rounded-2xl bg-[#050816]/85 border border-white/[0.08] text-xs flex items-center justify-between"
              >
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="font-mono font-bold text-slate-300 text-[10px]">{b.bookingId}</span>
                    {b.isEmergency && (
                      <span className="px-1.5 py-0.2 rounded-full bg-[#EF4444] text-white text-[8px] font-black uppercase">
                        SOS
                      </span>
                    )}
                    <span className="text-[10px] text-[#06B6D4] font-semibold">{b.vehicleType}</span>
                  </div>
                  <div className="text-[11px] text-slate-300 mt-0.5">
                    {b.pickupLocation.name.split(" ")[0]} → {b.destinationLocation.name.split(" ")[0]} ({b.selectedRoute})
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <div className="text-right">
                    <span className="font-mono font-bold text-[#10B981] text-xs block">
                      ₹{b.fareBreakdown.totalEstimatedFare.toLocaleString("en-IN")}
                    </span>
                    <span className="text-[8px] text-slate-400">{b.status}</span>
                  </div>

                  {b.isEmergency && !b.greenCorridorApproved && onApproveGreenCorridor && (
                    <button
                      onClick={() => onApproveGreenCorridor(b.bookingId)}
                      className="px-2.5 py-1 rounded-xl bg-[#10B981] hover:bg-emerald-500 text-white text-[9px] font-bold transition cursor-pointer"
                    >
                      Approve
                    </button>
                  )}

                  <button
                    onClick={() => onNavigate("booking_tracking")}
                    className="p-1.5 px-2.5 rounded-xl bg-white/[0.06] hover:bg-white/[0.12] border border-white/[0.08] text-[#06B6D4] text-[10px] font-bold cursor-pointer"
                    title="Track on map"
                  >
                    Track
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Quick Dispatch Actions */}
      <div className="grid grid-cols-2 gap-2.5 text-xs">
        <button
          onClick={() => onNavigate("incident_mgmt")}
          className="py-3 px-3 rounded-2xl bg-gradient-to-r from-[#2563EB] to-[#06B6D4] hover:brightness-110 text-white font-bold flex items-center justify-center gap-1.5 shadow-[0_6px_20px_rgba(37,99,235,0.35)] transition vrq-btn-press cursor-pointer"
        >
          <FileText className="w-3.5 h-3.5" />
          <span>Incident Triage Deck</span>
        </button>

        <button
          onClick={() => onNavigate("alerts")}
          className="py-3 px-3 rounded-2xl bg-gradient-to-r from-[#EF4444] to-[#DC2626] hover:brightness-110 text-white font-bold flex items-center justify-center gap-1.5 shadow-[0_6px_20px_rgba(239,68,68,0.35)] transition vrq-btn-press cursor-pointer"
        >
          <AlertTriangle className="w-3.5 h-3.5" />
          <span>Broadcast Emergency Alert</span>
        </button>
      </div>
    </div>
  );
};
