import React, { useState, useRef, useEffect } from "react";
import { IncidentType, ScreenId, Incident } from "../../types";
import { DEMO_PRESET_IMAGES } from "../../mockData";
import { useDeviceGPS } from "../../hooks/useDeviceGPS";
import { useRealWeather } from "../../hooks/useRealWeather";
import { RealWeatherWidget } from "../weather/RealWeatherWidget";
import { analyzeIncidentWithGemini, postServerIncident, saveToOfflineQueue } from "../../services/api";
import { calculateSmartRiskScore } from "../../utils/riskCalculator";
import {
  Camera,
  Upload,
  MapPin,
  Sparkles,
  AlertTriangle,
  Loader2,
  CheckCircle,
  FileImage,
  RefreshCw,
  Navigation,
  ShieldCheck,
  Info,
  CheckCircle2,
  XCircle,
  Eye,
} from "lucide-react";

interface IncidentReportingScreenProps {
  onNavigate: (screen: ScreenId) => void;
  onSubmitReport: (reportData: {
    type: IncidentType;
    description: string;
    locationName: string;
    lat: number;
    lng: number;
    imageBase64?: string;
    imageUrl?: string;
    weatherAtReport?: any;
    aiAnalysis?: any;
  }) => Promise<void>;
  isOnline: boolean;
  isAnalyzing: boolean;
  isDemoMode?: boolean;
}

export const IncidentReportingScreen: React.FC<IncidentReportingScreenProps> = ({
  onNavigate,
  onSubmitReport,
  isOnline,
  isAnalyzing: parentAnalyzing,
  isDemoMode = false,
}) => {
  // 1. Real Device GPS Hook
  const {
    location: gpsLoc,
    permissionStatus: gpsPermission,
    isLoading: gpsLoading,
    error: gpsError,
    refreshGPS,
    setManualLocation,
  } = useDeviceGPS(isDemoMode);

  // Form State
  const [selectedType, setSelectedType] = useState<IncidentType>("Landslide");
  const [description, setDescription] = useState("Severe slope failure and rockfall obstructing transit lanes.");
  const [locationName, setLocationName] = useState("");
  const [lat, setLat] = useState(gpsLoc.lat);
  const [lng, setLng] = useState(gpsLoc.lng);
  const [imagePreview, setImagePreview] = useState<string>(DEMO_PRESET_IMAGES[0].url);
  const [imageBase64, setImageBase64] = useState<string | undefined>(undefined);

  // AI Analysis local state
  const [localAnalyzing, setLocalAnalyzing] = useState(false);
  const [aiResult, setAiResult] = useState<any | null>(null);
  const [aiError, setAiError] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  // Synchronize GPS coordinates into form fields when GPS finishes locking
  useEffect(() => {
    if (gpsLoc) {
      setLat(gpsLoc.lat);
      setLng(gpsLoc.lng);
      setLocationName(gpsLoc.formattedAddress || gpsLoc.locality || `Coordinates [${gpsLoc.lat.toFixed(4)}, ${gpsLoc.lng.toFixed(4)}]`);
    }
  }, [gpsLoc]);

  // 2. Real Weather API Hook (at current incident coordinates)
  const {
    weather,
    isLoading: weatherLoading,
    error: weatherError,
    refetch: refetchWeather,
  } = useRealWeather(lat, lng, locationName || "Reported Location", isDemoMode);

  // Handle image upload & base64 encoding
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        setImagePreview(result);
        setImageBase64(result);
        setAiResult(null); // Reset previous analysis on new photo
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSelectPreset = (preset: typeof DEMO_PRESET_IMAGES[0]) => {
    setSelectedType(preset.type);
    setDescription(preset.desc);
    setLocationName(preset.location);
    setLat(preset.lat);
    setLng(preset.lng);
    setImagePreview(preset.url);
    setImageBase64(undefined);
    setAiResult(null);
    setManualLocation(preset.lat, preset.lng, preset.location);
  };

  // Run Real Gemini AI Analysis
  const handleRunAIAnalysis = async () => {
    setLocalAnalyzing(true);
    setAiError(null);

    try {
      const weatherContext = weather
        ? {
            temperature: weather.temperature,
            rainfall: weather.rainfall,
            condition: weather.weatherCondition,
            windSpeed: weather.windSpeed,
            weatherRisk: weather.weatherRisk,
          }
        : undefined;

      const analysis = await analyzeIncidentWithGemini({
        imageBase64,
        userDescription: description,
        locationName: locationName || `Coordinates [${lat.toFixed(4)}, ${lng.toFixed(4)}]`,
        lat,
        lng,
        weatherContext,
      });

      setAiResult(analysis);
      if (analysis.incidentType) {
        setSelectedType(analysis.incidentType as IncidentType);
      }
    } catch (err: any) {
      setAiError(err.message || "AI analysis failed. Please verify network connectivity.");
    } finally {
      setLocalAnalyzing(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const reportWeather = weather
      ? {
          temperature: weather.temperature,
          condition: weather.weatherCondition,
          windSpeed: weather.windSpeed,
          rainfall: weather.rainfall,
          weatherRisk: weather.weatherRisk,
          dataSource: weather.dataSource,
        }
      : undefined;

    const finalAiAnalysis = aiResult || {
      incidentType: selectedType,
      summary: description,
      aiExplanation: description,
      severity: "Medium",
      riskScore: 50,
      recommendedAction: "Authority field validation requested.",
      aiDisclaimer: "AI-generated assessment — requires human/authority verification.",
      modelUsed: "gemini-3.8-flash",
    };

    if (!isOnline) {
      // Save to offline queue
      saveToOfflineQueue({
        id: `OFFLINE-${Date.now()}`,
        type: selectedType,
        description,
        locationName,
        lat,
        lng,
        imageBase64,
        timestamp: new Date().toISOString(),
      });
      alert("Device is offline. Report safely stored in offline queue and will automatically synchronize when network is restored.");
      onNavigate("live_map");
      return;
    }

    await onSubmitReport({
      type: selectedType,
      description,
      locationName,
      lat,
      lng,
      imageBase64,
      imageUrl: imagePreview,
      weatherAtReport: reportWeather,
      aiAnalysis: finalAiAnalysis,
    });
  };

  const isAnalyzing = parentAnalyzing || localAnalyzing;

  return (
    <div className="p-4 space-y-4 pb-12 max-w-2xl mx-auto">
      {/* 1. Header with Mode Pill */}
      <div className="vrq-card p-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#F59E0B]/15 border border-[#F59E0B]/30 text-[#F59E0B] flex items-center justify-center shadow-inner">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white tracking-tight">Report Hazard</h2>
            <span className="text-[11px] text-slate-400 font-mono">Multi-Sensor AI Triage</span>
          </div>
        </div>
        <div className="flex items-center gap-1.5">
          <span className={`text-[10px] font-bold font-mono px-2.5 py-1 rounded-full border ${isOnline ? "bg-[#10B981]/15 text-[#10B981] border-[#10B981]/30" : "bg-[#F59E0B]/15 text-[#F59E0B] border-[#F59E0B]/30"}`}>
            {isOnline ? "ONLINE" : "OFFLINE"}
          </span>
        </div>
      </div>

      {/* 2. Photo Capture Area (Visual Tile) */}
      <div className="relative rounded-2xl overflow-hidden border border-white/[0.1] bg-[#050816] aspect-[16/9] flex items-center justify-center shadow-xl group">
        {imagePreview ? (
          <img
            src={imagePreview}
            alt="Hazard"
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="flex flex-col items-center gap-2 text-slate-500">
            <Camera className="w-10 h-10 text-slate-600" />
            <span className="text-xs font-bold text-slate-400">Capture / Upload Photo</span>
          </div>
        )}

        <div className="absolute inset-0 bg-gradient-to-t from-[#050816]/85 via-transparent to-transparent pointer-events-none" />

        {/* Floating Quick Camera / Upload Buttons */}
        <div className="absolute bottom-3 inset-x-3 flex items-center justify-between z-10">
          <button
            type="button"
            onClick={() => cameraInputRef.current?.click()}
            className="px-4 py-2 rounded-xl bg-[#0B1126]/90 hover:bg-[#131C3A] text-white border border-white/[0.12] font-bold text-xs flex items-center gap-2 shadow-xl backdrop-blur-xl cursor-pointer transition-all duration-200 active:scale-95"
          >
            <Camera className="w-4 h-4 text-[#06B6D4]" />
            <span>Camera</span>
          </button>

          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="px-4 py-2 rounded-xl bg-[#0B1126]/90 hover:bg-[#131C3A] text-white border border-white/[0.12] font-bold text-xs flex items-center gap-2 shadow-xl backdrop-blur-xl cursor-pointer transition-all duration-200 active:scale-95"
          >
            <Upload className="w-4 h-4 text-[#F59E0B]" />
            <span>Upload</span>
          </button>
        </div>

        {/* Hidden File Inputs */}
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileUpload}
          accept="image/*"
          className="hidden"
        />
        <input
          type="file"
          ref={cameraInputRef}
          onChange={handleFileUpload}
          accept="image/*"
          capture="environment"
          className="hidden"
        />
      </div>

      {/* 3. Category Selector (Visual Icon Grid) */}
      <div className="vrq-card p-4 space-y-2.5">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-slate-300">
            Select Hazard Category
          </span>
          <button
            type="button"
            onClick={() => onNavigate("voice_report")}
            className="text-xs text-[#06B6D4] font-semibold flex items-center gap-1 hover:text-white transition-colors cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" /> Voice Input
          </button>
        </div>

        <div className="grid grid-cols-5 gap-2">
          {[
            { type: "Landslide" as IncidentType, icon: "🏔️", label: "Landslide" },
            { type: "Flood" as IncidentType, icon: "🌊", label: "Flood" },
            { type: "Road Damage" as IncidentType, icon: "🚧", label: "Road" },
            { type: "Bridge Damage" as IncidentType, icon: "🌉", label: "Bridge" },
            { type: "Traffic Blockage" as IncidentType, icon: "🚗", label: "Block" },
          ].map((cat) => {
            const isSelected = selectedType === cat.type;
            return (
              <button
                key={cat.type}
                type="button"
                onClick={() => setSelectedType(cat.type)}
                className={`py-2.5 px-1.5 rounded-xl flex flex-col items-center justify-center gap-1.5 transition-all duration-200 border cursor-pointer active:scale-95 ${
                  isSelected
                    ? "bg-gradient-to-b from-[#2563EB]/30 to-[#06B6D4]/15 border-[#06B6D4] text-white font-bold shadow-[0_0_16px_rgba(6,182,212,0.25)]"
                    : "bg-[#050816]/70 border-white/[0.08] text-slate-400 hover:text-white hover:bg-white/[0.06]"
                }`}
              >
                <span className="text-lg leading-none">{cat.icon}</span>
                <span className="text-[10px] font-semibold truncate max-w-full">{cat.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 4. GPS & Telemetry Strip */}
      <div className="vrq-card p-4 space-y-3">
        <div className="flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 text-slate-300 min-w-0 pr-2">
            <MapPin className="w-4 h-4 text-[#06B6D4] shrink-0" />
            <span className="text-white truncate font-semibold text-xs">
              {locationName || `${lat.toFixed(4)}, ${lng.toFixed(4)}`}
            </span>
          </div>
          <button
            type="button"
            onClick={refreshGPS}
            disabled={gpsLoading}
            className="p-1.5 text-[#06B6D4] hover:text-white rounded-xl bg-white/[0.06] border border-white/[0.08] shrink-0 transition-all active:scale-95 cursor-pointer"
            title="Refresh GPS"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${gpsLoading ? "animate-spin" : ""}`} />
          </button>
        </div>

        <div className="grid grid-cols-3 gap-2 text-[11px] font-mono text-center">
          <div className="p-2 rounded-xl bg-[#050816]/80 border border-white/[0.08]">
            <span className="text-slate-400 block text-[9px] font-sans font-medium">Latitude</span>
            <span className="text-white font-bold">{lat.toFixed(4)}</span>
          </div>
          <div className="p-2 rounded-xl bg-[#050816]/80 border border-white/[0.08]">
            <span className="text-slate-400 block text-[9px] font-sans font-medium">Longitude</span>
            <span className="text-white font-bold">{lng.toFixed(4)}</span>
          </div>
          <div className="p-2 rounded-xl bg-[#050816]/80 border border-white/[0.08]">
            <span className="text-slate-400 block text-[9px] font-sans font-medium">Accuracy</span>
            <span className="text-[#10B981] font-bold">±{gpsLoc.accuracyMeters || 8}m</span>
          </div>
        </div>
      </div>

      {/* Form Submission */}
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Notes (Compact Field) */}
        <div className="vrq-card p-4 space-y-2">
          <label className="text-xs font-bold text-slate-300 block">
            Ground Observation Notes
          </label>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={2}
            placeholder="Brief observation notes..."
            className="w-full bg-[#050816]/85 border border-white/[0.1] rounded-xl p-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#06B6D4] resize-none transition-colors"
            required
          />
        </div>

        {/* AI Pre-Analysis Preview (Visual Gauge) */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleRunAIAnalysis}
            disabled={isAnalyzing}
            className="w-full py-2.5 px-4 rounded-xl bg-[#0B1126] hover:bg-[#131C3A] text-[#06B6D4] font-bold text-xs border border-[#06B6D4]/35 flex items-center justify-center gap-2 transition-all duration-200 active:scale-95 disabled:opacity-50 cursor-pointer shadow-md"
          >
            {localAnalyzing ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Scanning with Gemini Vision...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 text-[#06B6D4]" />
                <span>Run AI Risk Assessment</span>
              </>
            )}
          </button>
        </div>

        {/* AI Result Card */}
        {aiResult && (
          <div className="vrq-card border-[#06B6D4]/40 p-4 space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-bold text-white">
                <Sparkles className="w-4 h-4 text-[#06B6D4]" />
                <span>Gemini Vision Analysis</span>
              </div>
              <span className="text-[10px] font-mono font-bold px-2.5 py-0.5 rounded-full bg-[#F59E0B]/20 text-[#F59E0B] border border-[#F59E0B]/35">
                Risk {aiResult.riskScore}% ({aiResult.severity})
              </span>
            </div>

            <p className="text-xs text-slate-200 font-medium leading-relaxed">
              {aiResult.summary || aiResult.aiExplanation}
            </p>

            <div className="text-[11px] text-[#10B981] font-semibold flex items-center gap-1.5 pt-2 border-t border-white/[0.08]">
              <ShieldCheck className="w-3.5 h-3.5 text-[#10B981] shrink-0" />
              <span>Ready for submission & crowd validation</span>
            </div>
          </div>
        )}

        {/* Submit Button */}
        <button
          type="submit"
          disabled={isAnalyzing}
          className="w-full py-3.5 bg-gradient-to-r from-[#2563EB] to-[#06B6D4] hover:opacity-95 text-white font-extrabold text-xs rounded-2xl shadow-[0_8px_24px_rgba(37,99,235,0.4)] flex items-center justify-center gap-2 transition-all duration-200 active:scale-95 disabled:opacity-50 cursor-pointer"
        >
          {isAnalyzing ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin text-white" />
              <span>Submitting...</span>
            </>
          ) : (
            <>
              <CheckCircle className="w-4 h-4 text-white" />
              <span>Submit Hazard Report</span>
            </>
          )}
        </button>
      </form>
    </div>
  );
};
