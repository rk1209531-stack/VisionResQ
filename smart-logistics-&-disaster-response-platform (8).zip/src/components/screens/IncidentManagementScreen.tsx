import React, { useState } from "react";
import { Incident, IncidentStatus, ScreenId, UserRole } from "../../types";
import {
  FileText,
  Filter,
  CheckCircle,
  Truck,
  Phone,
  Shield,
  Clock,
  AlertTriangle,
  ChevronRight,
  UserCheck,
} from "lucide-react";

interface IncidentManagementScreenProps {
  incidents: Incident[];
  onSelectIncident: (incident: Incident) => void;
  onUpdateStatus: (incidentId: string, status: IncidentStatus, note?: string) => void;
  onNavigate: (screen: ScreenId) => void;
}

export const IncidentManagementScreen: React.FC<IncidentManagementScreenProps> = ({
  incidents,
  onSelectIncident,
  onUpdateStatus,
  onNavigate,
}) => {
  const [filter, setFilter] = useState<string>("All");

  const filteredIncidents =
    filter === "All" ? incidents : incidents.filter((i) => i.status === filter);

  return (
    <div className="p-4 space-y-4 pb-12">
      {/* Header */}
      <div className="vrq-card p-4">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-extrabold text-white flex items-center gap-2">
            <FileText className="w-4 h-4 text-[#06B6D4]" />
            <span>Incident Management Cell</span>
          </h2>
          <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-white/[0.06] text-slate-300 border border-white/[0.08]">
            {filteredIncidents.length} Active Records
          </span>
        </div>
        <p className="text-[11px] text-slate-400 mt-1">
          Triage incoming hazards, assign Border Roads Organisation (BRO) / SDRF units, and advance resolution stages.
        </p>
      </div>

      {/* Filter Tabs */}
      <div className="flex gap-1.5 overflow-x-auto pb-1 text-[10px] scrollbar-none">
        {["All", "Reported", "Verified", "Team Dispatched", "Work In Progress", "Resolved"].map((st) => (
          <button
            key={st}
            onClick={() => setFilter(st)}
            className={`px-3 py-1.5 rounded-xl flex-shrink-0 font-bold transition vrq-btn-press cursor-pointer border ${
              filter === st
                ? "bg-gradient-to-r from-[#2563EB] to-[#1D4ED8] text-white border-[#06B6D4]/50 shadow-[0_4px_14px_rgba(37,99,235,0.35)]"
                : "bg-[#0b132b]/80 text-slate-300 border-white/[0.08] hover:border-white/20"
            }`}
          >
            {st}
          </button>
        ))}
      </div>

      {/* Incident List */}
      <div className="space-y-3">
        {filteredIncidents.map((incident) => {
          return (
            <div
              key={incident.id}
              className="vrq-card p-4 space-y-3"
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="px-2.5 py-0.5 rounded-md bg-[#2563EB]/20 text-[#06B6D4] border border-[#06B6D4]/30 text-[10px] font-black">
                      {incident.type}
                    </span>
                    <span className="text-[10px] text-slate-400">
                      {incident.reportedAt}
                    </span>
                  </div>
                  <h3
                    onClick={() => {
                      onSelectIncident(incident);
                      onNavigate("incident_details");
                    }}
                    className="text-xs font-extrabold text-white hover:text-[#06B6D4] cursor-pointer transition"
                  >
                    {incident.title}
                  </h3>
                  <span className="text-[11px] text-slate-400 block mt-0.5">
                    {incident.locationName}
                  </span>
                </div>

                <div className="text-right flex-shrink-0">
                  <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-[#EF4444]/15 text-[#EF4444] border border-[#EF4444]/35">
                    Risk {incident.aiAnalysis.riskScore}%
                  </span>
                  <span className="text-[9px] text-slate-400 block mt-1">
                    {incident.crowdVerification.confirmations} confirms
                  </span>
                </div>
              </div>

              {/* Assigned Team badge if present */}
              {incident.assignedTeam ? (
                <div className="p-3 rounded-xl bg-[#050816]/85 border border-white/[0.08] text-xs flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <Truck className="w-4 h-4 text-[#06B6D4]" />
                    <div>
                      <span className="font-bold text-white block text-[11px]">
                        {incident.assignedTeam.teamName} ({incident.assignedTeam.agency})
                      </span>
                      <span className="text-[9px] text-slate-400">
                        {incident.assignedTeam.personnelCount ? `${incident.assignedTeam.personnelCount} personnel • ` : ""}
                        {incident.assignedTeam.equipment && incident.assignedTeam.equipment.length > 0
                          ? incident.assignedTeam.equipment.slice(0, 2).join(", ")
                          : "Heavy Earthmover, Rescue Gear"}
                      </span>
                    </div>
                  </div>
                  <a
                    href={`tel:${incident.assignedTeam.contactNumber}`}
                    className="p-2 rounded-xl bg-[#10B981]/15 border border-[#10B981]/30 text-[#10B981] hover:bg-[#10B981]/25 transition"
                  >
                    <Phone className="w-3.5 h-3.5" />
                  </a>
                </div>
              ) : (
                <div className="p-3 rounded-xl bg-[#F59E0B]/15 border border-[#F59E0B]/30 text-[11px] text-amber-200 flex items-center justify-between">
                  <span>No response unit assigned yet.</span>
                  <button
                    onClick={() => {
                      onUpdateStatus(incident.id, "Team Dispatched", "Dispatched BRO Quick Reaction Team 4.");
                    }}
                    className="px-2.5 py-1 rounded-xl bg-[#F59E0B] text-slate-950 font-bold text-[10px] cursor-pointer"
                  >
                    Dispatch BRO Team
                  </button>
                </div>
              )}

              {/* Status Update Quick Selector */}
              <div className="pt-2.5 border-t border-white/[0.08] flex items-center justify-between gap-2">
                <div className="flex items-center gap-2 text-xs flex-1">
                  <span className="text-[10px] text-slate-400 font-semibold">Stage:</span>
                  <select
                    value={incident.status}
                    onChange={(e) => onUpdateStatus(incident.id, e.target.value as IncidentStatus)}
                    className="bg-[#050816]/90 border border-white/10 rounded-xl px-2.5 py-1.5 text-xs text-white font-medium focus:outline-none focus:border-[#06B6D4]"
                  >
                    <option value="Reported">1. Reported</option>
                    <option value="Verified">2. Verified</option>
                    <option value="Team Dispatched">3. Team Dispatched</option>
                    <option value="Work In Progress">4. Work In Progress</option>
                    <option value="Resolved">5. Resolved</option>
                  </select>
                </div>

                <button
                  onClick={() => {
                    onSelectIncident(incident);
                    onNavigate("resolution_tracking");
                  }}
                  className="px-3 py-1.5 rounded-xl bg-white/[0.06] hover:bg-white/[0.12] border border-white/[0.08] text-slate-200 text-[10px] font-semibold flex items-center gap-1 transition vrq-btn-press cursor-pointer"
                >
                  <span>Track Flow</span>
                  <ChevronRight className="w-3 h-3" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
