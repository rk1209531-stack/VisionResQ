import React, { useState, useEffect } from "react";
import { ScreenId } from "../../types";
import { useLanguage } from "../../context/LanguageContext";
import { Mic, MicOff, Volume2, Sparkles, ArrowRight, Languages, Check, RefreshCw, Radio } from "lucide-react";

interface VoiceReportingScreenProps {
  onNavigate: (screen: ScreenId) => void;
  onVoiceSubmitted: (transcribedText: string, language: string) => void;
}

export const VoiceReportingScreen: React.FC<VoiceReportingScreenProps> = ({
  onNavigate,
  onVoiceSubmitted,
}) => {
  const { t, currentLanguage, setLanguage, languages } = useLanguage();
  const [isRecording, setIsRecording] = useState(false);
  const [transcript, setTranscript] = useState(t.sampleVoiceNote);
  const [selectedLang, setSelectedLang] = useState<string>("as-IN");
  const [audioLevel, setAudioLevel] = useState<number[]>([40, 65, 30, 80, 95, 60, 45, 75, 88, 55, 30]);

  // Sync default language code
  useEffect(() => {
    const langObj = languages.find((l) => l.code === currentLanguage);
    if (langObj) {
      setSelectedLang(langObj.speechLocale);
    }
  }, [currentLanguage, languages]);

  // Web Speech API recognition support
  useEffect(() => {
    let recognition: any = null;
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (SpeechRecognition && isRecording) {
      try {
        recognition = new SpeechRecognition();
        recognition.continuous = true;
        recognition.interimResults = true;
        recognition.lang = selectedLang;

        recognition.onresult = (event: any) => {
          let currentText = "";
          for (let i = 0; i < event.results.length; i++) {
            currentText += event.results[i][0].transcript;
          }
          if (currentText.trim()) {
            setTranscript(currentText);
          }
        };

        recognition.onerror = (e: any) => {
          console.warn("Speech recognition error:", e);
        };

        recognition.start();
      } catch (err) {
        console.warn("Recognition start failed:", err);
      }
    }

    return () => {
      if (recognition) {
        try {
          recognition.stop();
        } catch {}
      }
    };
  }, [isRecording, selectedLang]);

  // Simulated audio levels pulsing when recording
  useEffect(() => {
    if (!isRecording) return;
    const interval = setInterval(() => {
      setAudioLevel(Array.from({ length: 11 }, () => Math.floor(Math.random() * 80) + 20));
    }, 150);
    return () => clearInterval(interval);
  }, [isRecording]);

  const toggleRecording = () => {
    setIsRecording(!isRecording);
  };

  const handleApplyVoice = () => {
    onVoiceSubmitted(transcript, selectedLang);
  };

  const presetSamples = [
    {
      label: "অসমীয়া (বানপানী / ভূমিস্খলন)",
      text: "অসম ৰাষ্ট্ৰীয় ঘাইপথ ৩৭ কাজিৰঙাৰ ওচৰত ব্ৰহ্মপুত্ৰৰ পানী উঠি আহিছে। পথ সম্পূৰ্ণ বন্ধ, সাহায্য বাহনৰ প্ৰয়োজন।",
      lang: "as-IN",
      langCode: "as" as const,
    },
    {
      label: "बड़ो (हास्रुनाय / दैबाना)",
      text: "असम बड़ोलेण्ड लामायाव गोजौ दैबाना जानानै लामाया बन्द जाबाय। गोख्रों हेफाजाब नांगौ।",
      lang: "hi-IN",
      langCode: "bodo" as const,
    },
    {
      label: "বাংলা (বরাক উপত্যকা)",
      text: "শিলচর ও করিমগঞ্জের সংযোগস্থলে ধস নেমে রাস্তা বন্ধ। মেডিকেল টিম ও ত্রাণ ট্রাক প্রয়োজন।",
      lang: "bn-IN",
      langCode: "bn" as const,
    },
    {
      label: "English (Landslide)",
      text: "Massive rockfall and mud debris completely blocking both lanes on NH-58 near KM-34. Heavy boulders falling.",
      lang: "en-IN",
      langCode: "en" as const,
    },
    {
      label: "हिंदी (भूस्खलन / बाढ़)",
      text: "पानी सड़क पर तीन फीट ऊपर बह रहा है, गाड़ियाँ फंसी हुई हैं। असम हाइवे पर भारी जलभराव है।",
      lang: "hi-IN",
      langCode: "hi" as const,
    },
  ];

  return (
    <div className="p-4 flex flex-col justify-between min-h-[580px] pb-12">
      <div className="space-y-4">
        <div className="vrq-card p-4">
          <div className="flex items-center justify-between mb-1">
            <h2 className="text-sm font-extrabold text-white flex items-center gap-2">
              <Mic className="w-4 h-4 text-[#06B6D4]" />
              <span>{t.voiceReporting}</span>
            </h2>
            <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-[#2563EB]/20 text-[#06B6D4] border border-[#06B6D4]/30">
              অসম Multilingual AI
            </span>
          </div>

          <p className="text-[11px] text-slate-400">
            {t.voiceReportingDesc}
          </p>
        </div>

        {/* Assam Multi-Language Voice Selector */}
        <div className="vrq-card p-4">
          <div className="flex items-center justify-between mb-2.5">
            <div className="flex items-center gap-1.5 text-xs font-bold text-slate-300">
              <Languages className="w-4 h-4 text-[#06B6D4]" />
              <span>অসমৰ ভাষাসমূহ (Assam Languages Voice Input):</span>
            </div>
            <span className="text-[9px] font-bold px-2 py-0.5 rounded-full bg-[#10B981]/15 text-[#10B981] border border-[#10B981]/30">
              Speech Recognition
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {languages.map((l) => (
              <button
                key={l.code}
                type="button"
                onClick={() => {
                  setSelectedLang(l.speechLocale);
                  setLanguage(l.code);
                }}
                className={`py-2 px-2.5 rounded-xl text-left text-xs transition border flex flex-col justify-between vrq-btn-press cursor-pointer ${
                  selectedLang === l.speechLocale && currentLanguage === l.code
                    ? "bg-[#2563EB]/25 border-[#06B6D4] text-white font-bold shadow-[0_4px_14px_rgba(37,99,235,0.25)]"
                    : "bg-[#050816]/80 border-white/[0.08] text-slate-400 hover:text-slate-200 hover:border-white/20"
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-extrabold text-[11px] text-white">{l.nativeName}</span>
                  {selectedLang === l.speechLocale && currentLanguage === l.code && (
                    <Check className="w-3 h-3 text-[#06B6D4]" />
                  )}
                </div>
                <span className="text-[9px] text-slate-400 truncate">
                  {l.name}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Microphone Big Recording Visualizer */}
        <div className="vrq-card p-6 flex flex-col items-center justify-center text-center relative overflow-hidden">
          {isRecording && (
            <div className="absolute inset-0 bg-[#EF4444]/10 animate-pulse" />
          )}

          {/* Pulsing Mic Button */}
          <button
            type="button"
            onClick={toggleRecording}
            className={`relative w-20 h-20 rounded-full flex items-center justify-center shadow-2xl transition-all duration-300 cursor-pointer ${
              isRecording
                ? "bg-[#EF4444] text-white shadow-[0_0_32px_rgba(239,68,68,0.6)] scale-110 animate-pulse ring-4 ring-[#EF4444]/30"
                : "bg-gradient-to-br from-[#2563EB] to-[#06B6D4] text-white shadow-[0_8px_24px_rgba(37,99,235,0.4)] hover:scale-105"
            }`}
          >
            {isRecording ? <MicOff className="w-8 h-8" /> : <Mic className="w-8 h-8" />}
          </button>

          <span className="text-xs font-extrabold text-white mt-3">
            {isRecording ? t.listening : t.readyToRecord}
          </span>
          <span className="text-[10px] text-slate-400 mt-1">
            {isRecording ? t.stopSpeaking : t.startSpeaking} ({selectedLang})
          </span>

          {/* Waveform Visualizer */}
          <div className="flex items-center justify-center gap-1.5 mt-4 h-8 w-full max-w-[200px]">
            {audioLevel.map((lvl, idx) => (
              <div
                key={idx}
                style={{ height: `${isRecording ? lvl : 15}%` }}
                className={`w-1.5 rounded-full transition-all duration-100 ${
                  isRecording ? "bg-[#06B6D4]" : "bg-white/15"
                }`}
              />
            ))}
          </div>
        </div>

        {/* Transcribed Output Card */}
        <div className="vrq-card p-4">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[11px] font-bold text-slate-300">
              Live Speech-to-Text Transcript ({languages.find((l) => l.speechLocale === selectedLang)?.nativeName || selectedLang}):
            </span>
            <button
              onClick={() => setTranscript("")}
              className="text-[10px] text-slate-400 hover:text-white flex items-center gap-1 cursor-pointer"
            >
              <RefreshCw className="w-2.5 h-2.5" /> Clear
            </button>
          </div>
          <textarea
            value={transcript}
            onChange={(e) => setTranscript(e.target.value)}
            rows={3}
            className="w-full bg-[#050816]/90 border border-white/[0.1] rounded-xl p-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#06B6D4] resize-none font-medium"
            placeholder="Your spoken words will appear here..."
          />
        </div>

        {/* Sample Voice Scenarios including Assam Dialects */}
        <div className="vrq-card p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[10px] font-bold text-slate-300 flex items-center gap-1.5">
              <Radio className="w-3.5 h-3.5 text-[#06B6D4]" />
              অসমৰ স্থানীয় প্ৰস্তুত ভইচ নোট (Assam Quick Voice Scenarios):
            </span>
          </div>
          <div className="flex flex-wrap gap-2 text-[10px]">
            {presetSamples.map((sample) => (
              <button
                key={sample.label}
                type="button"
                onClick={() => {
                  setTranscript(sample.text);
                  setSelectedLang(sample.lang);
                  setLanguage(sample.langCode);
                }}
                className="px-3 py-1.5 bg-[#050816]/85 hover:bg-white/[0.08] text-slate-200 rounded-xl border border-white/[0.08] transition text-left vrq-btn-press cursor-pointer"
              >
                <span className="font-bold block text-white">{sample.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Action Footer */}
      <div className="pt-4">
        <button
          type="button"
          onClick={handleApplyVoice}
          disabled={!transcript.trim()}
          className="w-full py-3.5 bg-gradient-to-r from-[#2563EB] to-[#06B6D4] hover:brightness-110 text-white font-extrabold text-xs rounded-2xl shadow-[0_8px_24px_rgba(37,99,235,0.4)] flex items-center justify-center gap-2 transition disabled:opacity-40 vrq-btn-press cursor-pointer"
        >
          <Sparkles className="w-4 h-4 text-cyan-200" />
          <span>Use Voice Transcript in AI Analysis</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
