import React from "react";
import {
  Incident,
  BroadcastAlert,
  ScreenId,
  UserRole,
  EmergencyRequest,
  TransportBooking,
} from "../../types";
import { useDeviceGPS } from "../../hooks/useDeviceGPS";
import { useRealWeather } from "../../hooks/useRealWeather";
import {
  AlertTriangle,
  Route,
  Zap,
  Activity,
  CheckCircle2,
  Clock,
  MapPin,
  RefreshCw,
  Sparkles,
  ChevronRight,
  ShieldAlert,
  AlertOctagon,
  Radio,
  CloudRain,
  Timer,
  Bell,
  Mic,
  ShieldCheck,
  Compass,
  ThumbsUp,
  Truck,
} from "lucide-react";

interface HomeDashboardProps {
  incidents: Incident[];
  alerts: BroadcastAlert[];
  emergencyRequests?: EmergencyRequest[];
  bookings?: TransportBooking[];
  currentRole: UserRole;
  onNavigate: (screen: ScreenId) => void;
  onSelectIncident: (incident: Incident) => void;
  isOnline: boolean;
  isDemoMode?: boolean;
}

export const HomeDashboardScreen: React.FC<HomeDashboardProps> = ({
  incidents,
  alerts,
  emergencyRequests = [],
  bookings = [],
  currentRole,
  onNavigate,
  onSelectIncident,
  isOnline,
  isDemoMode = false,
}) => {
  const { location: userGps, refreshGPS, isLoading: gpsLoading } = useDeviceGPS(isDemoMode);
  const { weather, isLoading: weatherLoading, refetch: refetchWeather } = useRealWeather(
    userGps.lat,
    userGps.lng,
    userGps.formattedAddress,
    isDemoMode
  );

  const activeAlerts = alerts.filter((a) => a.active);
  const activeIncidents = incidents.filter((i) => i.status !== "Resolved");
  const activeIncidentsCount = activeIncidents.length;
  const criticalIncidentsCount = incidents.filter((i) => i.aiAnalysis.riskScore >= 70).length;
  const emergencyRequestsCount = emergencyRequests.filter((r) => r.status !== "Delivered").length;
  const verifiedIncidentsCount = incidents.filter(
    (i) => i.crowdVerification.confidenceScore >= 75 || i.status === "Verified"
  ).length;

  const isHazard = criticalIncidentsCount > 2 || activeAlerts.some((a) => a.severity === "Red");
  const isCaution = criticalIncidentsCount > 0 || activeAlerts.some((a) => a.severity === "Amber");

  const statusTheme = isHazard
    ? {
        label: "CRITICAL",
        color: "text-[#EF4444]",
        bg: "bg-[#EF4444]/15",
        border: "border-[#EF4444]/35",
        dot: "bg-[#EF4444] animate-ping",
      }
    : isCaution
    ? {
        label: "CAUTION",
        color: "text-[#F59E0B]",
        bg: "bg-[#F59E0B]/15",
        border: "border-[#F59E0B]/35",
        dot: "bg-[#F59E0B]",
      }
    : {
        label: "CLEAR",
        color: "text-[#10B981]",
        bg: "bg-[#10B981]/15",
        border: "border-[#10B981]/35",
        dot: "bg-[#10B981]",
      };

  return (
    <div id="home-dashboard-screen" className="p-4 space-y-4 pb-16 max-w-4xl mx-auto">
      {/* 1. TOP SITUATION HUD */}
      <section
        id="hero-status-banner"
        className="vrq-card p-4 relative overflow-hidden"
      >
        <div className="pointer-events-none absolute -top-12 -right-12 w-32 h-32 rounded-full bg-[#2563EB]/15 blur-2xl" />

        <div className="flex items-center justify-between gap-2 relative z-10">
          {/* Status Indicator Pill */}
          <div className="flex items-center gap-2">
            <div className={`flex items-center gap-2 px-3 py-1 rounded-xl border text-xs font-extrabold tracking-wider ${statusTheme.bg} ${statusTheme.border} ${statusTheme.color}`}>
              <span className="relative flex h-2 w-2">
                <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${statusTheme.dot}`} />
                <span className={`relative inline-flex rounded-full h-2 w-2 ${statusTheme.dot.replace("animate-ping", "")}`} />
              </span>
              <span>{statusTheme.label}</span>
            </div>
            <span className="text-[11px] text-slate-400 font-mono hidden sm:inline">
              GPS ±{userGps.accuracyMeters || 8}m
            </span>
          </div>

          {/* Compact Weather & Notification Display */}
          <div className="flex items-center gap-2">
            <div className="px-3 py-1.5 rounded-xl bg-[#050816]/80 border border-white/[0.08] flex items-center gap-2 text-xs shadow-inner">
              <span className="text-sm leading-none">{weather?.rainfall && weather.rainfall > 0 ? "🌧️" : "⛅"}</span>
              <span className="font-mono font-bold text-white">
                {weather?.temperature !== undefined ? `${Math.round(weather.temperature)}°C` : "26°C"}
              </span>
              <span className="text-[11px] text-[#06B6D4] font-mono font-semibold border-l border-white/[0.08] pl-2">
                {weather?.rainProbability ?? 60}%
              </span>
            </div>

            <button
              onClick={() => onNavigate("alerts")}
              className="relative p-2 rounded-xl bg-[#050816]/80 border border-white/[0.08] text-[#F59E0B] hover:bg-white/[0.08] transition-all duration-200 active:scale-95 cursor-pointer"
              title="Alerts"
            >
              <Bell className="w-4 h-4" />
              {activeAlerts.length > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-[#EF4444] text-[9px] font-black font-mono text-white flex items-center justify-center ring-2 ring-[#050816] animate-pulse">
                  {activeAlerts.length}
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Location Sub-Bar with 1-click GPS Refresh */}
        <div className="mt-3 pt-3 border-t border-white/[0.08] flex items-center justify-between gap-2 text-xs relative z-10">
          <div className="flex items-center gap-2 text-slate-300 min-w-0">
            <div className="w-6 h-6 rounded-lg bg-[#2563EB]/15 border border-[#2563EB]/30 flex items-center justify-center shrink-0">
              <MapPin className="w-3.5 h-3.5 text-[#06B6D4]" />
            </div>
            <span className="text-white truncate font-semibold text-xs">
              {userGps.formattedAddress || "Guwahati - Silchar Corridor (NH-44)"}
            </span>
          </div>
          <button
            onClick={() => refreshGPS()}
            disabled={gpsLoading}
            className="p-1.5 rounded-xl bg-white/[0.06] hover:bg-white/[0.12] border border-white/[0.08] text-[#06B6D4] shrink-0 transition-all duration-200 active:scale-95 cursor-pointer"
            title="Refresh GPS"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${gpsLoading ? "animate-spin" : ""}`} />
          </button>
        </div>
      </section>

      {/* 2. QUICK ACTION BUTTONS (Equal Size, Larger Icons, Premium Gradients) */}
      <section className="space-y-2">
        <div className="grid grid-cols-4 gap-2">
          {/* Action 1: Report Hazard */}
          <button
            onClick={() => onNavigate("report")}
            className="group min-h-[96px] p-3 rounded-2xl bg-gradient-to-b from-[#F59E0B]/18 to-[#0B1126]/90 hover:from-[#F59E0B]/28 border border-[#F59E0B]/30 hover:border-[#F59E0B]/50 flex flex-col items-center justify-center text-center gap-1.5 transition-all duration-200 active:scale-95 shadow-lg cursor-pointer"
          >
            <div className="w-10 h-10 rounded-xl bg-[#F59E0B]/20 border border-[#F59E0B]/35 text-[#F59E0B] flex items-center justify-center group-hover:scale-105 transition-transform shadow-inner">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <span className="text-xs font-bold text-white tracking-tight leading-none mt-0.5">
              Report
            </span>
            <span className="text-[9px] font-semibold text-[#F59E0B] tracking-wide leading-none">
              AI Vision
            </span>
          </button>

          {/* Action 2: Safe Route / Bypass */}
          <button
            onClick={() => onNavigate("smart_route")}
            className="group min-h-[96px] p-3 rounded-2xl bg-gradient-to-b from-[#10B981]/18 to-[#0B1126]/90 hover:from-[#10B981]/28 border border-[#10B981]/30 hover:border-[#10B981]/50 flex flex-col items-center justify-center text-center gap-1.5 transition-all duration-200 active:scale-95 shadow-lg cursor-pointer"
          >
            <div className="w-10 h-10 rounded-xl bg-[#10B981]/20 border border-[#10B981]/35 text-[#10B981] flex items-center justify-center group-hover:scale-105 transition-transform shadow-inner">
              <Route className="w-5 h-5" />
            </div>
            <span className="text-xs font-bold text-white tracking-tight leading-none mt-0.5">
              Bypass
            </span>
            <span className="text-[9px] font-semibold text-[#10B981] tracking-wide leading-none">
              Safe Path
            </span>
          </button>

          {/* Action 3: Booking & Relief Dispatch */}
          <button
            onClick={() => onNavigate(currentRole === "driver" ? "driver_dashboard" : "book_transport")}
            className="group min-h-[96px] p-3 rounded-2xl bg-gradient-to-b from-[#06B6D4]/18 to-[#0B1126]/90 hover:from-[#06B6D4]/28 border border-[#06B6D4]/30 hover:border-[#06B6D4]/50 flex flex-col items-center justify-center text-center gap-1.5 transition-all duration-200 active:scale-95 shadow-lg cursor-pointer"
          >
            <div className="w-10 h-10 rounded-xl bg-[#06B6D4]/20 border border-[#06B6D4]/35 text-[#06B6D4] flex items-center justify-center group-hover:scale-105 transition-transform shadow-inner">
              <Truck className="w-5 h-5" />
            </div>
            <span className="text-xs font-bold text-white tracking-tight leading-none mt-0.5">
              Booking
            </span>
            <span className="text-[9px] font-semibold text-[#06B6D4] tracking-wide leading-none">
              Transport
            </span>
          </button>

          {/* Action 4: Emergency SOS */}
          <button
            onClick={() => onNavigate("emergency")}
            className="group min-h-[96px] p-3 rounded-2xl bg-gradient-to-b from-[#EF4444]/25 to-[#1E0912]/95 hover:from-[#EF4444]/35 border border-[#EF4444]/45 hover:border-[#EF4444]/70 flex flex-col items-center justify-center text-center gap-1.5 transition-all duration-200 active:scale-95 shadow-lg cursor-pointer"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#EF4444] to-rose-600 text-white flex items-center justify-center group-hover:scale-105 transition-transform shadow-[0_0_16px_rgba(239,68,68,0.45)] animate-pulse">
              <AlertOctagon className="w-5 h-5" />
            </div>
            <span className="text-xs font-bold text-white tracking-tight leading-none mt-0.5">
              SOS
            </span>
            <span className="text-[9px] font-semibold text-red-300 tracking-wide leading-none">
              Emergency
            </span>
          </button>
        </div>

        {/* Secondary Quick Action Mini-Bar */}
        <div className="grid grid-cols-3 gap-2 text-xs font-semibold">
          <button
            onClick={() => onNavigate("live_map")}
            className="py-2.5 px-3 rounded-xl vrq-card-interactive flex items-center justify-center gap-2 text-slate-200 hover:text-white cursor-pointer"
          >
            <Compass className="w-4 h-4 text-[#2563EB]" />
            <span>GIS Map</span>
          </button>

          <button
            onClick={() => onNavigate("voice_report")}
            className="py-2.5 px-3 rounded-xl vrq-card-interactive flex items-center justify-center gap-2 text-slate-200 hover:text-white cursor-pointer"
          >
            <Mic className="w-4 h-4 text-[#06B6D4]" />
            <span>Voice Log</span>
          </button>

          <button
            onClick={() => onNavigate("crowd_verify")}
            className="py-2.5 px-3 rounded-xl vrq-card-interactive flex items-center justify-center gap-2 text-slate-200 hover:text-white cursor-pointer"
          >
            <ShieldCheck className="w-4 h-4 text-[#10B981]" />
            <span>Verify</span>
          </button>
        </div>
      </section>

      {/* 3. VISUAL TELEMETRY GAUGES */}
      <section className="grid grid-cols-4 gap-2">
        {/* Hazards */}
        <div
          onClick={() => onNavigate("live_map")}
          className="p-3 vrq-card-interactive cursor-pointer flex flex-col items-center justify-center text-center"
        >
          <AlertTriangle className="w-4 h-4 text-[#F59E0B]" />
          <span className="text-lg font-extrabold font-mono text-white mt-1 leading-tight">
            {activeIncidentsCount}
          </span>
          <span className="text-[10px] text-slate-400 font-semibold mt-0.5">Hazards</span>
        </div>

        {/* SOS */}
        <div
          onClick={() => onNavigate("emergency")}
          className="p-3 vrq-card-interactive cursor-pointer flex flex-col items-center justify-center text-center"
        >
          <AlertOctagon className="w-4 h-4 text-[#EF4444] animate-pulse" />
          <span className="text-lg font-extrabold font-mono text-[#EF4444] mt-1 leading-tight">
            {emergencyRequestsCount || 3}
          </span>
          <span className="text-[10px] text-slate-400 font-semibold mt-0.5">SOS</span>
        </div>

        {/* Alerts */}
        <div
          onClick={() => onNavigate("alerts")}
          className="p-3 vrq-card-interactive cursor-pointer flex flex-col items-center justify-center text-center"
        >
          <Bell className="w-4 h-4 text-[#F59E0B]" />
          <span className="text-lg font-extrabold font-mono text-[#F59E0B] mt-1 leading-tight">
            {activeAlerts.length}
          </span>
          <span className="text-[10px] text-slate-400 font-semibold mt-0.5">Alerts</span>
        </div>

        {/* Verified */}
        <div
          onClick={() => onNavigate("crowd_verify")}
          className="p-3 vrq-card-interactive cursor-pointer flex flex-col items-center justify-center text-center"
        >
          <CheckCircle2 className="w-4 h-4 text-[#10B981]" />
          <span className="text-lg font-extrabold font-mono text-[#10B981] mt-1 leading-tight">
            {verifiedIncidentsCount}
          </span>
          <span className="text-[10px] text-slate-400 font-semibold mt-0.5">Verified</span>
        </div>
      </section>

      {/* 4. HAZARD CARDS (Better Image Sizing, Floating Risk Badge, Clean Metadata) */}
      <section className="space-y-3 pt-1">
        <div className="flex items-center justify-between px-0.5">
          <div className="flex items-center gap-2">
            <div className="w-2 h-4 rounded-full bg-gradient-to-b from-[#2563EB] to-[#06B6D4]" />
            <h3 className="text-sm font-bold text-white tracking-tight">
              Active Corridor Hazards
            </h3>
          </div>
          <button
            onClick={() => onNavigate("live_map")}
            className="text-xs text-[#06B6D4] hover:text-white font-semibold flex items-center gap-1 transition-colors cursor-pointer"
          >
            <span>All ({incidents.length})</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="space-y-3">
          {incidents.slice(0, 3).map((incident) => {
            const isCriticalRisk = incident.aiAnalysis.riskScore >= 75;
            const isMediumRisk = incident.aiAnalysis.riskScore >= 40 && incident.aiAnalysis.riskScore < 75;

            const riskBadgeStyle = isCriticalRisk
              ? "bg-[#EF4444]/90 text-white border-white/20 shadow-[0_4px_12px_rgba(239,68,68,0.45)]"
              : isMediumRisk
              ? "bg-[#F59E0B]/90 text-slate-950 border-white/20 shadow-[0_4px_12px_rgba(245,158,11,0.35)]"
              : "bg-[#10B981]/90 text-slate-950 border-white/20 shadow-[0_4px_12px_rgba(16,185,129,0.35)]";

            const riskPillInline = isCriticalRisk
              ? "text-[#EF4444] bg-[#EF4444]/15 border-[#EF4444]/30"
              : isMediumRisk
              ? "text-[#F59E0B] bg-[#F59E0B]/15 border-[#F59E0B]/30"
              : "text-[#10B981] bg-[#10B981]/15 border-[#10B981]/30";

            return (
              <div
                key={incident.id}
                id={`incident-card-${incident.id}`}
                onClick={() => {
                  onSelectIncident(incident);
                  onNavigate("incident_details");
                }}
                className="cursor-pointer vrq-card-interactive p-3.5 flex items-center gap-3.5 group"
              >
                {/* Hazard Thumbnail with Floating Risk Badge */}
                <div className="w-20 h-20 rounded-xl overflow-hidden bg-[#050816] border border-white/[0.08] flex-shrink-0 relative shadow-md">
                  <img
                    src={incident.imageUrl}
                    alt={incident.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    loading="lazy"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#050816]/90 via-transparent to-black/30" />

                  {/* Floating Risk Percentage Badge */}
                  <span className={`absolute top-1.5 right-1.5 text-[10px] font-mono font-extrabold px-1.5 py-0.5 rounded-lg border backdrop-blur-md leading-none ${riskBadgeStyle}`}>
                    {incident.aiAnalysis.riskScore}%
                  </span>

                  {/* Category Label at Bottom */}
                  <span className="absolute bottom-1 inset-x-1 text-[9px] text-center font-bold text-slate-100 truncate px-1">
                    {incident.type}
                  </span>
                </div>

                {/* Card Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <h4 className="text-sm font-bold text-white truncate group-hover:text-[#06B6D4] transition-colors leading-snug">
                      {incident.title}
                    </h4>
                    <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-lg border shrink-0 ${riskPillInline}`}>
                      Risk {incident.aiAnalysis.riskScore}%
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5 text-xs text-slate-300 mt-1.5 truncate">
                    <MapPin className="w-3.5 h-3.5 text-[#06B6D4] shrink-0" />
                    <span className="truncate font-medium">{incident.locationName}</span>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-slate-400 pt-2 mt-2 border-t border-white/[0.06] font-mono">
                    <span className="text-[#10B981] font-semibold flex items-center gap-1.5">
                      <ThumbsUp className="w-3 h-3" />
                      <span>{incident.crowdVerification.confirmations} verified</span>
                    </span>
                    <span className="flex items-center gap-1 text-slate-400">
                      <Clock className="w-3 h-3 text-slate-500" />
                      <span>{incident.reportedAt}</span>
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
};
