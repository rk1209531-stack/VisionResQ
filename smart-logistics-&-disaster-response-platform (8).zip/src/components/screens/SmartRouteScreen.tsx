import React, { useState, useEffect } from "react";
import { SmartRoute, ScreenId, Incident } from "../../types";
import { INITIAL_SMART_ROUTE } from "../../mockData";
import { PRESET_LOCATIONS, LocationPreset, getCorridorRoutes } from "../../transportData";
import { LocationKeywordInput } from "../common/LocationKeywordInput";
import { DisasterInteractiveMap } from "../map/DisasterInteractiveMap";
import { computeRealGoogleRoute } from "../../services/googleMapsService";
import {
  Route,
  ShieldCheck,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Compass,
  ArrowRight,
  Shield,
  Sparkles,
  RefreshCw,
  Navigation,
  MapPin,
  ChevronRight,
  Loader2,
  Globe2,
} from "lucide-react";

interface SmartRouteScreenProps {
  onNavigate: (screen: ScreenId) => void;
  incidents?: Incident[];
}

export const SmartRouteScreen: React.FC<SmartRouteScreenProps> = ({
  onNavigate,
  incidents = [],
}) => {
  // Origin & Destination state with real Indian coordinates
  const [originLocation, setOriginLocation] = useState<LocationPreset>({
    name: "Rishikesh Logistics Staging Hub",
    region: "Uttarakhand",
    lat: 30.0869,
    lng: 78.2676,
  });

  const [destinationLocation, setDestinationLocation] = useState<LocationPreset>({
    name: "Devprayag Disaster Relief Depot",
    region: "Uttarakhand",
    lat: 30.1459,
    lng: 78.5989,
  });

  const [isCalculating, setIsCalculating] = useState(false);
  const [routeSource, setRouteSource] = useState("Google Routes API v2");
  const [greenCorridorActive, setGreenCorridorActive] = useState(true);

  // Corridor routes state
  const [corridorData, setCorridorData] = useState(() =>
    getCorridorRoutes(originLocation, destinationLocation)
  );

  // Auto recalculate routes using real Google Routes API v2 whenever origin, destination,
  // or reported disaster incidents change!
  useEffect(() => {
    let isMounted = true;
    setIsCalculating(true);

    computeRealGoogleRoute(originLocation, destinationLocation, incidents)
      .then((res) => {
        if (!isMounted) return;
        if (res) {
          setCorridorData({
            routeA: res.routeA,
            routeB: res.routeB,
          });
          setRouteSource(res.source);
        } else {
          setCorridorData(getCorridorRoutes(originLocation, destinationLocation));
        }
      })
      .catch((err) => {
        console.warn("SmartRoute real route compute fallback:", err);
        if (isMounted) {
          setCorridorData(getCorridorRoutes(originLocation, destinationLocation));
        }
      })
      .finally(() => {
        if (isMounted) {
          setIsCalculating(false);
        }
      });

    return () => {
      isMounted = false;
    };
  }, [
    originLocation.lat,
    originLocation.lng,
    destinationLocation.lat,
    destinationLocation.lng,
    incidents,
  ]);

  const handleQuickHub = (orig: LocationPreset, dest: LocationPreset) => {
    setOriginLocation(orig);
    setDestinationLocation(dest);
  };

  const handleSwap = () => {
    const temp = originLocation;
    setOriginLocation(destinationLocation);
    setDestinationLocation(temp);
  };

  return (
    <div className="p-4 space-y-4 pb-12 max-w-4xl mx-auto">
      {/* Header Banner */}
      <div className="vrq-card p-4">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#2563EB]/20 border border-[#2563EB]/35 text-[#06B6D4] flex items-center justify-center font-black shrink-0">
              <Route className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-sm font-bold text-white tracking-tight">
                  Smart Safe Route Optimization
                </h2>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#2563EB]/15 text-[#06B6D4] border border-[#06B6D4]/25 flex items-center gap-1">
                  <Sparkles className="w-3 h-3" /> Risk AI
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5 font-medium">
                Live Google Maps Platform routing with real-time disaster hazard intersection and dynamic bypass calculation.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 text-[10px] text-[#10B981] bg-[#10B981]/15 border border-[#10B981]/30 px-2.5 py-1 rounded-full font-mono shrink-0">
            <Globe2 className="w-3 h-3 text-[#10B981]" />
            <span className="hidden sm:inline">{routeSource}</span>
            <span className="sm:hidden">Google</span>
          </div>
        </div>
      </div>

      {/* Origin & Destination Inputs with Real Google Places Autocomplete */}
      <div className="vrq-card p-4 space-y-3">
        <LocationKeywordInput
          label="Origin / Logistics Staging Base"
          dotColor="emerald"
          value={originLocation.name}
          selectedPreset={originLocation}
          presets={PRESET_LOCATIONS}
          placeholder="Search any place in India e.g. Rishikesh, Guwahati, Depot..."
          onSelectLocation={(preset: LocationPreset) => setOriginLocation(preset)}
          helperText="Google Places autocomplete enabled — search any real place in India"
        />

        {/* Swap button & Quick routes */}
        <div className="flex items-center justify-between gap-2 py-0.5">
          <div className="flex gap-2 overflow-x-auto text-[11px] py-1">
            <button
              onClick={() =>
                handleQuickHub(
                  { name: "Rishikesh Logistics Base", region: "Uttarakhand", lat: 30.0869, lng: 78.2676 },
                  { name: "Devprayag Relief Camp", region: "Uttarakhand", lat: 30.1459, lng: 78.5989 }
                )
              }
              className="px-3 py-1.5 rounded-xl bg-[#050816]/80 border border-white/[0.08] text-slate-300 hover:text-white hover:border-[#06B6D4]/40 transition-all active:scale-95 flex-shrink-0 text-[10px] font-semibold cursor-pointer"
            >
              Uttarakhand NH-58 Corridor
            </button>
            <button
              onClick={() =>
                handleQuickHub(
                  { name: "Guwahati Depot", region: "Assam", lat: 26.1445, lng: 91.7362 },
                  { name: "Tezpur Hospital", region: "Assam", lat: 26.6528, lng: 92.7926 }
                )
              }
              className="px-3 py-1.5 rounded-xl bg-[#050816]/80 border border-white/[0.08] text-slate-300 hover:text-white hover:border-[#06B6D4]/40 transition-all active:scale-95 flex-shrink-0 text-[10px] font-semibold cursor-pointer"
            >
              Assam NH-715 Corridor
            </button>
            <button
              onClick={() =>
                handleQuickHub(
                  { name: "New Delhi Warehouse", region: "Delhi", lat: 28.6139, lng: 77.209 },
                  { name: "Dehradun Helipad", region: "Uttarakhand", lat: 30.3165, lng: 78.0322 }
                )
              }
              className="px-3 py-1.5 rounded-xl bg-[#050816]/80 border border-white/[0.08] text-slate-300 hover:text-white hover:border-[#06B6D4]/40 transition-all active:scale-95 flex-shrink-0 text-[10px] font-semibold cursor-pointer"
            >
              Delhi ⇄ Dehradun
            </button>
          </div>

          <button
            type="button"
            onClick={handleSwap}
            className="px-3 py-1.5 rounded-xl bg-white/[0.06] hover:bg-white/[0.12] text-slate-200 transition-all active:scale-95 text-[10px] font-bold flex items-center gap-1 border border-white/[0.1] shrink-0 cursor-pointer"
            title="Swap Origin and Destination"
          >
            <span className="font-bold text-xs text-[#06B6D4]">⇅</span>
            <span className="text-[10px]">Swap</span>
          </button>
        </div>

        <LocationKeywordInput
          label="Destination / Relief Drop Point"
          dotColor="rose"
          value={destinationLocation.name}
          selectedPreset={destinationLocation}
          presets={PRESET_LOCATIONS}
          placeholder="Search any destination e.g. Joshimath, Silchar, Hospital..."
          onSelectLocation={(preset: LocationPreset) => setDestinationLocation(preset)}
          helperText="Coordinates update dynamically on selection"
        />
      </div>

      {/* Embedded Live Google Maps with Real Routes & Hazards */}
      <div className="vrq-card p-4 space-y-2.5">
        <div className="flex items-center justify-between px-0.5">
          <div className="flex items-center gap-2">
            <MapPin className="w-4 h-4 text-[#06B6D4]" />
            <span className="text-xs font-bold text-white">
              Live Google Maps Vector Corridor
            </span>
          </div>
          <div className="flex items-center gap-2">
            {isCalculating && (
              <span className="text-[10px] text-[#06B6D4] flex items-center gap-1 font-semibold">
                <Loader2 className="w-3 h-3 animate-spin" />
                <span>Computing routes...</span>
              </span>
            )}
            <span className="text-[10px] text-slate-400 font-mono">
              {incidents.length} Active Hazards
            </span>
          </div>
        </div>

        <div className="rounded-xl overflow-hidden border border-white/[0.08]">
          <DisasterInteractiveMap
            incidents={incidents}
            pickupLocation={{
              lat: originLocation.lat,
              lng: originLocation.lng,
              name: originLocation.name,
            }}
            destinationLocation={{
              lat: destinationLocation.lat,
              lng: destinationLocation.lng,
              name: destinationLocation.name,
            }}
            routeAPath={corridorData.routeA.pathCoordinates}
            routeBPath={corridorData.routeB.pathCoordinates}
            userLocation={{
              lat: originLocation.lat,
              lng: originLocation.lng,
              formattedAddress: originLocation.name,
            }}
            heightClass="h-64 sm:h-80"
          />
        </div>

        <div className="flex items-center justify-between text-[10px] text-slate-400 px-1 pt-0.5">
          <span className="flex items-center gap-3">
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-1.5 bg-[#10B981] rounded-full" />
              <span className="text-[#10B981] font-semibold">Route B (Safe Bypass)</span>
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-1.5 bg-[#EF4444] rounded-full" />
              <span className="text-[#EF4444] font-semibold">Route A (High Risk)</span>
            </span>
          </span>
          <span className="font-mono text-slate-400">
            {originLocation.lat.toFixed(3)}, {originLocation.lng.toFixed(3)} → {destinationLocation.lat.toFixed(3)}, {destinationLocation.lng.toFixed(3)}
          </span>
        </div>
      </div>

      {/* AI Recommendation Highlight Box */}
      <div className="vrq-card border-[#10B981]/35 p-4 space-y-2 bg-gradient-to-br from-[#10B981]/10 to-[#0B1126]/90">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-[#10B981]" />
            <span className="text-xs font-bold text-[#10B981]">
              Autonomous Safe Route Recommendation
            </span>
          </div>
          <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-[#10B981]/20 text-emerald-300 border border-[#10B981]/35">
            Route B Recommended
          </span>
        </div>
        <p className="text-xs text-slate-200 leading-relaxed font-medium">
          {corridorData.routeB.recommendationReason ||
            "Route B avoids known hazard zones, verified mudslides, and high-risk mountain choke points. Recommended for all relief consignments."}
        </p>
      </div>

      {/* Side-by-Side Comparison: Route A vs Route B */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Route A (High Risk - Blocked) */}
        <div className="vrq-card border-[#EF4444]/30 p-4 space-y-3 relative overflow-hidden">
          <div className="flex items-start justify-between gap-2">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-white">
                  {corridorData.routeA.name}
                </span>
                <span className="px-2 py-0.5 rounded-full bg-[#EF4444]/15 text-[#EF4444] border border-[#EF4444]/30 text-[9px] font-bold">
                  {corridorData.routeA.riskLevel}
                </span>
              </div>
              <span className="text-[11px] text-[#EF4444] font-medium block mt-1">
                Via: {corridorData.routeA.via}
              </span>
            </div>

            <div className="text-right shrink-0">
              <span className="text-base font-extrabold font-mono text-[#EF4444] block leading-tight">
                {corridorData.routeA.riskScore}% Risk
              </span>
              <span className="text-[10px] text-slate-400 font-mono">
                {corridorData.routeA.distanceKm} km · ~{corridorData.routeA.estimatedMinutes} min
              </span>
            </div>
          </div>

          {/* Risk bar */}
          <div className="w-full h-2 bg-[#050816] rounded-full overflow-hidden border border-white/[0.08]">
            <div
              style={{ width: `${corridorData.routeA.riskScore}%` }}
              className="h-full bg-[#EF4444] rounded-full"
            />
          </div>

          <div className="text-xs text-red-200 flex items-start gap-2 bg-[#EF4444]/10 p-3 rounded-xl border border-[#EF4444]/25">
            <AlertTriangle className="w-4 h-4 text-[#EF4444] flex-shrink-0 mt-0.5" />
            <span className="text-[11px] leading-relaxed">
              {corridorData.routeA.incidentSummary}
            </span>
          </div>
        </div>

        {/* Route B (Safe Bypass Corridor) */}
        <div className="vrq-card border-[#10B981]/35 p-4 space-y-3 relative overflow-hidden">
          <div className="flex items-start justify-between gap-2">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-white">
                  {corridorData.routeB.name}
                </span>
                <span className="px-2 py-0.5 rounded-full bg-[#10B981]/20 text-[#10B981] border border-[#10B981]/35 text-[9px] font-bold">
                  Clear Bypass
                </span>
              </div>
              <span className="text-[11px] text-[#10B981] font-medium block mt-1">
                Via: {corridorData.routeB.via}
              </span>
            </div>

            <div className="text-right shrink-0">
              <span className="text-base font-extrabold font-mono text-[#10B981] block leading-tight">
                {corridorData.routeB.riskScore}% Risk
              </span>
              <span className="text-[10px] text-slate-400 font-mono">
                {corridorData.routeB.distanceKm} km · ~{corridorData.routeB.estimatedMinutes} min
              </span>
            </div>
          </div>

          {/* Risk bar */}
          <div className="w-full h-2 bg-[#050816] rounded-full overflow-hidden border border-white/[0.08]">
            <div
              style={{ width: `${corridorData.routeB.riskScore}%` }}
              className="h-full bg-[#10B981] rounded-full"
            />
          </div>

          <div className="text-xs text-emerald-200 flex items-start gap-2 bg-[#10B981]/10 p-3 rounded-xl border border-[#10B981]/25">
            <CheckCircle2 className="w-4 h-4 text-[#10B981] flex-shrink-0 mt-0.5" />
            <span className="text-[11px] leading-relaxed">
              {corridorData.routeB.incidentSummary}
            </span>
          </div>
        </div>
      </div>

      {/* Green Corridor Mode Switch */}
      <div className="p-4 vrq-card flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-[#10B981]/15 border border-[#10B981]/30 text-[#10B981] flex items-center justify-center shrink-0">
            <ShieldCheck className="w-4 h-4" />
          </div>
          <div>
            <span className="text-xs font-bold text-white block">Emergency Green Corridor Protocol</span>
            <span className="text-[11px] text-slate-400 font-medium">
              SDRF / Police priority escort cleared along Route B bypass
            </span>
          </div>
        </div>

        <button
          onClick={() => setGreenCorridorActive(!greenCorridorActive)}
          className={`px-3.5 py-1.5 rounded-xl text-[10px] font-bold transition-all duration-200 active:scale-95 cursor-pointer ${
            greenCorridorActive
              ? "bg-[#10B981] text-slate-950 font-extrabold shadow-[0_0_16px_rgba(16,185,129,0.35)]"
              : "bg-white/[0.06] border border-white/[0.1] text-slate-400 hover:text-white"
          }`}
        >
          {greenCorridorActive ? "ACTIVE" : "INACTIVE"}
        </button>
      </div>

      {/* Navigation CTA: Connect directly to Book Transport or Live Map */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <button
          onClick={() => onNavigate("book_transport")}
          className="w-full py-3.5 bg-gradient-to-r from-[#2563EB] to-[#06B6D4] hover:opacity-95 text-white font-bold text-xs rounded-2xl shadow-[0_8px_24px_rgba(37,99,235,0.35)] flex items-center justify-center gap-2 transition-all duration-200 active:scale-95 cursor-pointer"
        >
          <Navigation className="w-4 h-4" />
          <span>Book Transport on this Corridor</span>
          <ChevronRight className="w-4 h-4" />
        </button>

        <button
          onClick={() => onNavigate("live_map")}
          className="w-full py-3.5 vrq-card-interactive text-white font-bold text-xs flex items-center justify-center gap-2 cursor-pointer"
        >
          <Compass className="w-4 h-4 text-[#06B6D4]" />
          <span>Open Full-Screen Live GIS Map</span>
          <ChevronRight className="w-4 h-4 text-slate-400" />
        </button>
      </div>
    </div>
  );
};
