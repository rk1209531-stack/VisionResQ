import React, { useState, useMemo } from "react";
import { BroadcastAlert, ScreenId, UserRole } from "../../types";
import {
  Bell,
  AlertTriangle,
  Send,
  Plus,
  CheckCircle2,
  Clock,
  Shield,
  Trash2,
  Volume2,
  CloudRain,
  Navigation,
  Filter,
  Radio,
  Check,
} from "lucide-react";

interface AlertsScreenProps {
  alerts: BroadcastAlert[];
  currentRole: UserRole;
  onNavigate: (screen: ScreenId) => void;
  onCreateAlert: (alert: Omit<BroadcastAlert, "id" | "timestamp" | "active">) => void;
  onResolveAlert: (id: string) => void;
}

type AlertFilter = "All" | "High Risk" | "Weather" | "Road Block" | "Resolved";

export const AlertsScreen: React.FC<AlertsScreenProps> = ({
  alerts,
  currentRole,
  onNavigate,
  onCreateAlert,
  onResolveAlert,
}) => {
  const [activeFilter, setActiveFilter] = useState<AlertFilter>("All");
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newTitle, setNewTitle] = useState("HIGH RISK ALERT: NH-58 Blocked by Landslide");
  const [newRegion, setNewRegion] = useState("Guwahati - Silchar Highway (NH-27 / NH-58)");
  const [newSeverity, setNewSeverity] = useState<"Red" | "Amber" | "Yellow">("Red");
  const [newMessage, setNewMessage] = useState("Severe debris landslide blocked both highway lanes. Heavy commercial freight halted; emergency green corridor active via Tehri bypass.");
  const [newAction, setNewAction] = useState("Divert all ambulances and freight to Route B Bypass immediately.");

  const filteredAlerts = useMemo(() => {
    return alerts.filter((alert) => {
      if (activeFilter === "All") return true;
      if (activeFilter === "Resolved") return !alert.active;
      if (activeFilter === "High Risk") return alert.severity === "Red" && alert.active;
      if (activeFilter === "Weather")
        return (
          alert.active &&
          (alert.type.includes("WEATHER") ||
            alert.title.toLowerCase().includes("rain") ||
            alert.title.toLowerCase().includes("weather") ||
            alert.title.toLowerCase().includes("flood"))
        );
      if (activeFilter === "Road Block")
        return (
          alert.active &&
          (alert.title.toLowerCase().includes("block") ||
            alert.title.toLowerCase().includes("landslide") ||
            alert.message.toLowerCase().includes("blocked"))
        );
      return true;
    });
  }, [alerts, activeFilter]);

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    onCreateAlert({
      title: newTitle,
      type: "HIGH RISK ALERT",
      severity: newSeverity,
      region: newRegion,
      message: newMessage,
      recommendedAction: newAction,
      issuedBy: currentRole === "authority" ? "State Disaster Management Authority (SDMA)" : "Emergency Logistics Command",
    });
    setShowCreateModal(false);
  };

  const playAudioPing = () => {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(880, audioCtx.currentTime); // A5
      osc.frequency.exponentialRampToValueAtTime(440, audioCtx.currentTime + 0.3);
      gain.gain.setValueAtTime(0.3, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.3);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.3);
    } catch {}
  };

  const activeAlertCount = alerts.filter((a) => a.active).length;

  return (
    <div id="alerts-screen-container" className="p-4 space-y-4 pb-12 max-w-4xl mx-auto">
      {/* Header Banner with Command Center Styling */}
      <div className="vrq-card p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#EF4444] to-[#F59E0B] text-white flex items-center justify-center font-black shadow-[0_6px_20px_rgba(239,68,68,0.35)] flex-shrink-0">
            <Bell className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-sm font-extrabold text-white tracking-tight">
                Disaster Emergency Broadcasts
              </h1>
              {activeAlertCount > 0 && (
                <span className="px-2.5 py-0.5 rounded-full text-[9px] font-black bg-[#EF4444] text-white vrq-pulse-badge">
                  {activeAlertCount} Live
                </span>
              )}
            </div>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Cell-broadcast hazard directives, road blocks, and meteorological warnings.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-center">
          <button
            id="test-emergency-tone-btn"
            onClick={playAudioPing}
            className="p-2 px-3 rounded-xl bg-[#050816]/90 border border-white/[0.08] text-slate-300 hover:text-white hover:border-white/20 transition flex items-center gap-1.5 text-xs font-semibold vrq-btn-press cursor-pointer"
            title="Test Geofence Audio Siren"
          >
            <Volume2 className="w-4 h-4 text-[#F59E0B]" />
            <span className="text-[11px] hidden xs:inline">Test Tone</span>
          </button>

          {(currentRole === "authority" || currentRole === "emergency") && (
            <button
              id="broadcast-alert-btn"
              onClick={() => setShowCreateModal(!showCreateModal)}
              className="px-3.5 py-2 bg-gradient-to-r from-[#EF4444] to-[#DC2626] hover:brightness-110 text-white rounded-xl text-xs font-black transition flex items-center gap-1.5 shadow-[0_6px_18px_rgba(239,68,68,0.35)] vrq-btn-press cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Broadcast Alert</span>
            </button>
          )}
        </div>
      </div>

      {/* Filter Tabs (All, High Risk, Weather, Road Block, Resolved) */}
      <div
        id="alert-filters-bar"
        className="flex items-center gap-2 overflow-x-auto pb-1 text-xs scrollbar-none"
      >
        {(["All", "High Risk", "Weather", "Road Block", "Resolved"] as AlertFilter[]).map((f) => {
          const isSelected = activeFilter === f;
          return (
            <button
              key={f}
              onClick={() => setActiveFilter(f)}
              className={`px-3.5 py-2 rounded-xl font-bold transition-all duration-150 border shrink-0 text-xs flex items-center gap-1.5 vrq-btn-press cursor-pointer ${
                isSelected
                  ? "bg-gradient-to-r from-[#2563EB] to-[#1D4ED8] text-white border-[#06B6D4]/50 shadow-[0_4px_14px_rgba(37,99,235,0.35)]"
                  : "bg-[#0b132b]/80 text-slate-300 border-white/[0.08] hover:border-white/20 hover:text-white"
              }`}
            >
              {f === "High Risk" && <AlertTriangle className="w-3.5 h-3.5 text-[#EF4444]" />}
              {f === "Weather" && <CloudRain className="w-3.5 h-3.5 text-[#06B6D4]" />}
              {f === "Resolved" && <CheckCircle2 className="w-3.5 h-3.5 text-[#10B981]" />}
              <span>{f}</span>
              <span className="text-[9px] opacity-80 px-1.5 py-0.5 rounded-md bg-black/30 ml-0.5 font-mono">
                {f === "All"
                  ? alerts.length
                  : f === "Resolved"
                  ? alerts.filter((a) => !a.active).length
                  : f === "High Risk"
                  ? alerts.filter((a) => a.active && a.severity === "Red").length
                  : f === "Weather"
                  ? alerts.filter((a) => a.active && (a.type.includes("WEATHER") || a.title.toLowerCase().includes("rain"))).length
                  : alerts.filter((a) => a.active && (a.title.toLowerCase().includes("block") || a.title.toLowerCase().includes("landslide"))).length}
              </span>
            </button>
          );
        })}
      </div>

      {/* Broadcast Create Form Modal for Authority/Emergency */}
      {showCreateModal && (
        <form
          id="create-alert-modal"
          onSubmit={handleCreate}
          className="vrq-card border-2 border-[#EF4444]/80 p-4 space-y-3 animate-in fade-in"
        >
          <div className="flex items-center justify-between pb-2.5 border-b border-white/[0.08]">
            <span className="text-xs font-black text-white flex items-center gap-2">
              <Send className="w-4 h-4 text-[#EF4444]" />
              <span>Broadcast New Emergency Geofence Directive</span>
            </span>
            <button
              type="button"
              onClick={() => setShowCreateModal(false)}
              className="text-slate-400 hover:text-white text-xs font-bold cursor-pointer"
            >
              ✕ Close
            </button>
          </div>

          <div>
            <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Alert Headline</label>
            <input
              type="text"
              value={newTitle}
              onChange={(e) => setNewTitle(e.target.value)}
              className="w-full bg-[#050816]/90 border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#06B6D4]"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Geofence Region</label>
              <input
                type="text"
                value={newRegion}
                onChange={(e) => setNewRegion(e.target.value)}
                className="w-full bg-[#050816]/90 border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#06B6D4]"
                required
              />
            </div>
            <div>
              <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Severity Level</label>
              <select
                value={newSeverity}
                onChange={(e) => setNewSeverity(e.target.value as any)}
                className="w-full bg-[#050816]/90 border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#06B6D4]"
              >
                <option value="Red">Red (High Risk Immediate)</option>
                <option value="Amber">Amber (Moderate Caution)</option>
                <option value="Yellow">Yellow (Advisory)</option>
              </select>
            </div>
          </div>

          <div>
            <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Broadcast Telemetry</label>
            <textarea
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              rows={2}
              className="w-full bg-[#050816]/90 border border-white/10 rounded-xl p-2.5 text-xs text-white resize-none focus:outline-none focus:border-[#06B6D4]"
              required
            />
          </div>

          <div>
            <label className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Mandatory Driver Directive</label>
            <input
              type="text"
              value={newAction}
              onChange={(e) => setNewAction(e.target.value)}
              className="w-full bg-[#050816]/90 border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#06B6D4]"
              required
            />
          </div>

          <button
            type="submit"
            className="w-full py-2.5 bg-gradient-to-r from-[#EF4444] to-[#DC2626] hover:brightness-110 text-white font-black text-xs rounded-xl shadow-[0_6px_20px_rgba(239,68,68,0.35)] transition vrq-btn-press cursor-pointer"
          >
            Push Real-Time Alert to Connected Devices
          </button>
        </form>
      )}

      {/* Real Emergency Alerts Feed */}
      <div id="alerts-feed-list" className="space-y-3">
        {filteredAlerts.length === 0 ? (
          <div className="vrq-card p-6 text-center text-slate-400 text-xs">
            No alerts matching the selected filter &quot;{activeFilter}&quot;.
          </div>
        ) : (
          filteredAlerts.map((alert) => {
            const isRed = alert.severity === "Red";
            const isAmber = alert.severity === "Amber";

            const severityBadge = !alert.active
              ? "bg-[#10B981]/15 text-[#10B981] border-[#10B981]/35"
              : isRed
              ? "bg-[#EF4444]/20 text-[#EF4444] border-[#EF4444]/40"
              : isAmber
              ? "bg-[#F59E0B]/20 text-[#F59E0B] border-[#F59E0B]/40"
              : "bg-yellow-500/20 text-yellow-300 border-yellow-500/40";

            return (
              <div
                key={alert.id}
                id={`alert-card-${alert.id}`}
                className={`vrq-card p-4 space-y-3 transition-all duration-200 ${
                  alert.active
                    ? isRed
                      ? "border-[#EF4444]/45 shadow-[0_10px_28px_rgba(239,68,68,0.15)]"
                      : "border-white/[0.08]"
                    : "border-white/[0.05] opacity-65"
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span
                      className={`text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full border ${severityBadge}`}
                    >
                      {alert.type}
                    </span>
                    <span className="text-[10px] text-slate-400 flex items-center gap-1">
                      <Clock className="w-3 h-3 text-slate-500" />
                      {alert.timestamp}
                    </span>
                  </div>

                  {alert.active && (currentRole === "authority" || currentRole === "emergency") && (
                    <button
                      onClick={() => onResolveAlert(alert.id)}
                      className="text-[10px] font-bold text-slate-300 hover:text-[#10B981] flex items-center gap-1 transition px-2.5 py-1 rounded-xl bg-[#050816]/90 border border-white/[0.08] hover:border-[#10B981]/40 vrq-btn-press cursor-pointer"
                    >
                      <CheckCircle2 className="w-3 h-3" />
                      <span>Mark Resolved</span>
                    </button>
                  )}
                </div>

                <div>
                  <h3 className="text-sm font-extrabold text-white leading-snug">
                    {alert.title}
                  </h3>
                  <span className="text-[11px] text-slate-400 font-medium block mt-0.5">
                    Affected Corridor: {alert.region}
                  </span>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed font-medium">
                  {alert.message}
                </p>

                <div className="p-3 rounded-xl bg-[#050816]/85 border border-white/[0.08] text-xs text-slate-300 flex items-start gap-2.5">
                  <Shield className="w-4 h-4 text-[#06B6D4] shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-[#06B6D4] font-bold">Mandatory Directive:</strong>{" "}
                    <span>{alert.recommendedAction}</span>
                  </div>
                </div>

                <div className="flex items-center justify-between text-[10px] text-slate-400 pt-2 border-t border-white/[0.06]">
                  <span className="truncate">Issued by: {alert.issuedBy}</span>
                  <span
                    className={`font-black flex items-center gap-1.5 ${
                      alert.active ? "text-[#EF4444] animate-pulse" : "text-[#10B981]"
                    }`}
                  >
                    <span
                      className={`w-1.5 h-1.5 rounded-full ${
                        alert.active ? "bg-[#EF4444]" : "bg-[#10B981]"
                      }`}
                    />
                    {alert.active ? "Active Warning" : "Corridor Cleared"}
                  </span>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
