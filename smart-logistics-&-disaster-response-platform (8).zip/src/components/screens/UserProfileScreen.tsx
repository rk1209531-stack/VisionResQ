import React, { useState } from "react";
import { UserRole, ScreenId } from "../../types";
import { useLanguage } from "../../context/LanguageContext";
import {
  User,
  Shield,
  Wifi,
  WifiOff,
  RefreshCw,
  Award,
  Database,
  MapPin,
  CheckCircle2,
  Phone,
  Building,
  HeartHandshake,
  Zap,
  Compass,
  Star,
  Clock,
  History,
  Check,
  ChevronRight,
  Languages,
  Globe,
} from "lucide-react";

interface UserProfileScreenProps {
  currentRole: UserRole;
  onRoleChange: (role: UserRole) => void;
  isOnline: boolean;
  onToggleOnline: () => void;
  offlineQueueCount: number;
  onSyncOffline: () => Promise<void>;
  onNavigate: (screen: ScreenId) => void;
}

export const UserProfileScreen: React.FC<UserProfileScreenProps> = ({
  currentRole,
  onRoleChange,
  isOnline,
  onToggleOnline,
  offlineQueueCount,
  onSyncOffline,
  onNavigate,
}) => {
  const { currentLanguage, setLanguage, languages, t } = useLanguage();
  const [isSyncing, setIsSyncing] = useState(false);

  const handleSync = async () => {
    setIsSyncing(true);
    await onSyncOffline();
    setIsSyncing(false);
  };

  const roleDetails = {
    citizen: {
      name: "Aarav Sharma",
      phone: "+91 98765 43210",
      org: "Civilian First Responder Corps",
      region: "Guwahati / Silchar Highway Sector",
      badgeTitle: "Verified Reporter • Level 3",
      trustScore: 98,
      verifiedReports: 28,
      dispatchesAssisted: 14,
    },
    driver: {
      name: "Gurpreet Singh",
      phone: "+91 98112 33445",
      org: "All-India Emergency Relief Transport Association",
      region: "Northern & Eastern Logistics Corridors (NH-27 / NH-58)",
      badgeTitle: "Disaster Logistics Convoy Lead",
      trustScore: 99,
      verifiedReports: 42,
      dispatchesAssisted: 31,
    },
    authority: {
      name: "Commander Vikram Malhotra",
      phone: "+91 94190 12345",
      org: "State Disaster Management Authority (SDMA)",
      region: "State Emergency Operations Center",
      badgeTitle: "Verified Chief Command Official",
      trustScore: 100,
      verifiedReports: 89,
      dispatchesAssisted: 120,
    },
    emergency: {
      name: "Dr. Rohit Deshmukh",
      phone: "+91 99887 66554",
      org: "National Green Corridor Medical Response",
      region: "Emergency Trauma & ICU Fleet Unit",
      badgeTitle: "Verified Emergency Chief",
      trustScore: 99,
      verifiedReports: 67,
      dispatchesAssisted: 95,
    },
  }[currentRole];

  // User Achievements List (Prompt Requirement)
  const achievements = [
    {
      id: "life-saver",
      title: "Life Saver",
      description: "Coordinated emergency rescue and medical rations for 4 stranded mountain convoys",
      icon: HeartHandshake,
      color: "text-red-400 bg-red-500/20 border-red-500/40",
      dateEarned: "August 2026",
    },
    {
      id: "quick-reporter",
      title: "Quick Reporter",
      description: "First on scene to flag high-risk landslide on NH-58 within 90 seconds of occurrence",
      icon: Zap,
      color: "text-amber-400 bg-amber-500/20 border-amber-500/40",
      dateEarned: "July 2026",
    },
    {
      id: "route-explorer",
      title: "Route Explorer",
      description: "Mapped and crowd-validated 120km of flood bypass corridors during Monsoon red alerts",
      icon: Compass,
      color: "text-emerald-400 bg-emerald-500/20 border-emerald-500/40",
      dateEarned: "June 2026",
    },
    {
      id: "top-contributor",
      title: "Top Contributor",
      description: "Contributed 34 verified hazard updates with >95% peer community accuracy",
      icon: Star,
      color: "text-blue-400 bg-blue-500/20 border-blue-500/40",
      dateEarned: "May 2026",
    },
  ];

  // Emergency History Log (Prompt Requirement)
  const emergencyHistory = [
    {
      id: "HIST-01",
      event: "Medical Oxygen Escort",
      route: "Guwahati Depot → Silchar Civil Hospital",
      status: "Delivered",
      date: "Yesterday, 18:30",
      priority: "EMERGENCY",
    },
    {
      id: "HIST-02",
      event: "Sonapur Landslide Hazard Report",
      route: "NH-27 Mile 42",
      status: "Verified & Cleared",
      date: "3 days ago",
      priority: "HIGH RISK",
    },
    {
      id: "HIST-03",
      event: "Relief Food Rations Dispatch",
      route: "Rishikesh HQ → Devprayag Forward Post",
      status: "Delivered",
      date: "1 week ago",
      priority: "URGENT",
    },
  ];

  return (
    <div id="user-profile-screen" className="p-4 space-y-4 pb-12 max-w-4xl mx-auto">
      {/* 1. USER PROFILE HEADER WITH VERIFIED REPORTER BADGE */}
      <div className="vrq-card p-4 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-36 h-36 bg-[#2563EB]/15 rounded-full blur-2xl pointer-events-none" />

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#2563EB] to-[#06B6D4] text-white font-black flex items-center justify-center text-2xl shadow-[0_8px_24px_rgba(37,99,235,0.4)] flex-shrink-0 ring-2 ring-[#06B6D4]/30">
              {roleDetails.name[0]}
            </div>

            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2">
                <h1 className="text-base font-extrabold text-white truncate">
                  {roleDetails.name}
                </h1>
                {/* Verified Reporter Badge (Prompt Requirement) */}
                <span className="inline-flex items-center gap-1 text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full bg-[#10B981]/15 text-[#10B981] border border-[#10B981]/35">
                  <CheckCircle2 className="w-3 h-3 text-[#10B981]" />
                  <span>{roleDetails.badgeTitle}</span>
                </span>
              </div>

              <p className="text-xs text-slate-300 font-medium truncate mt-0.5">
                {roleDetails.org}
              </p>

              <div className="flex items-center gap-3 mt-1 text-[11px] text-slate-400">
                <span className="flex items-center gap-1">
                  <MapPin className="w-3 h-3 text-[#06B6D4]" />
                  <span className="truncate max-w-[200px]">{roleDetails.region}</span>
                </span>
                <span>•</span>
                <span className="flex items-center gap-1">
                  <Phone className="w-3 h-3 text-[#06B6D4]" />
                  <span>{roleDetails.phone}</span>
                </span>
              </div>
            </div>
          </div>

          {/* Quick Online Status Chip */}
          <div className="flex items-center gap-2 self-start sm:self-center">
            <button
              onClick={onToggleOnline}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-black flex items-center gap-1.5 border transition vrq-btn-press cursor-pointer ${
                isOnline
                  ? "bg-[#10B981]/15 text-[#10B981] border-[#10B981]/35 hover:bg-[#10B981]/25"
                  : "bg-[#F59E0B]/15 text-[#F59E0B] border-[#F59E0B]/35 hover:bg-[#F59E0B]/25"
              }`}
            >
              {isOnline ? <Wifi className="w-3.5 h-3.5" /> : <WifiOff className="w-3.5 h-3.5" />}
              <span>{isOnline ? "Online Node" : "Offline Storage"}</span>
            </button>
          </div>
        </div>

        {/* Role Switching Selector */}
        <div className="mt-4 pt-3.5 border-t border-white/[0.08]">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[10px] uppercase font-bold text-slate-400">
              Active Operational Role (VisionResQ RBAC):
            </span>
            <span className="text-[10px] text-[#06B6D4] font-bold capitalize">{currentRole} Mode</span>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 bg-[#050816]/90 p-1.5 rounded-xl border border-white/[0.08]">
            {(["citizen", "driver", "authority", "emergency"] as UserRole[]).map((r) => (
              <button
                key={r}
                onClick={() => onRoleChange(r)}
                className={`py-1.5 px-2 rounded-lg text-xs font-bold transition text-center capitalize vrq-btn-press cursor-pointer ${
                  currentRole === r
                    ? "bg-gradient-to-r from-[#2563EB] to-[#1D4ED8] text-white shadow-[0_4px_14px_rgba(37,99,235,0.4)]"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                {r}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* 2. PREFERRED LANGUAGE SELECTOR */}
      <div id="preferred-language-section" className="vrq-card p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#2563EB]/20 text-[#06B6D4] flex items-center justify-center border border-[#06B6D4]/30">
              <Languages className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-xs font-extrabold uppercase tracking-wider text-white flex items-center gap-1.5">
                Preferred Language
              </h2>
              <p className="text-[11px] text-slate-400 font-medium">
                Interface navigation, voice speech-to-text & disaster broadcast audio
              </p>
            </div>
          </div>
          <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-[#06B6D4]/15 text-[#06B6D4] border border-[#06B6D4]/30 font-mono">
            {languages.find((l) => l.code === currentLanguage)?.name || "English"}
          </span>
        </div>

        {/* 7 Languages Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
          {languages.map((lang) => {
            const isSelected = currentLanguage === lang.code;
            return (
              <button
                key={lang.code}
                id={`pref-lang-${lang.code}`}
                onClick={() => setLanguage(lang.code)}
                className={`p-3 rounded-2xl border text-left transition-all relative flex items-center justify-between gap-2.5 group vrq-btn-press cursor-pointer ${
                  isSelected
                    ? "bg-[#2563EB]/20 border-[#06B6D4]/70 shadow-[0_6px_18px_rgba(37,99,235,0.2)] ring-1 ring-[#06B6D4]/40"
                    : "bg-[#050816]/80 border-white/[0.08] hover:border-white/20 hover:bg-white/[0.04] text-slate-400"
                }`}
              >
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className={`text-xs font-black tracking-tight ${isSelected ? "text-white" : "text-slate-200"}`}>
                      {lang.name}
                    </span>
                    <span className="text-[11px] font-semibold text-slate-400">
                      ({lang.nativeName})
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-400 block truncate mt-0.5">
                    {lang.region}
                  </span>
                </div>

                <div
                  className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 transition ${
                    isSelected
                      ? "bg-[#2563EB] text-white shadow-[0_2px_10px_rgba(37,99,235,0.5)]"
                      : "border border-white/10 bg-[#0b132b]/60 text-transparent group-hover:border-white/25"
                  }`}
                >
                  <Check className="w-3.5 h-3.5" />
                </div>
              </button>
            );
          })}
        </div>

        {/* Selected Language Info Footer */}
        <div className="mt-3 pt-2.5 border-t border-white/[0.08] flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-400">
          <span className="flex items-center gap-1.5">
            <Globe className="w-3.5 h-3.5 text-[#06B6D4]" />
            <span>Active Speech Locale: <strong className="text-slate-200 font-mono">{languages.find((l) => l.code === currentLanguage)?.speechLocale}</strong></span>
          </span>
          <span className="text-[#10B981] font-bold flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-[#10B981] animate-pulse" />
            <span>Live Sync Active</span>
          </span>
        </div>
      </div>

      {/* 3. TRUST SCORE & STATS (98% Accuracy Score) */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {/* Trust Score Hero Card */}
        <div className="vrq-card p-4 flex items-center justify-between">
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 block">
              Community Trust Score
            </span>
            <div className="flex items-baseline gap-1 mt-1">
              <span className="text-3xl font-black font-mono text-[#10B981]">
                {roleDetails.trustScore}%
              </span>
              <span className="text-xs text-slate-400 font-bold">Accuracy</span>
            </div>
            <span className="text-[10px] text-[#10B981] font-medium block mt-0.5">
              Top 1% Reliable First Responder
            </span>
          </div>
          <div className="w-14 h-14 rounded-full border-4 border-[#10B981]/25 border-t-[#10B981] flex items-center justify-center font-mono font-black text-sm text-[#10B981] shadow-inner">
            A+
          </div>
        </div>

        {/* Verified Reports Metric */}
        <div className="vrq-card p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span className="font-bold">Verified Reports</span>
            <CheckCircle2 className="w-4 h-4 text-[#06B6D4]" />
          </div>
          <div className="mt-2">
            <span className="text-2xl font-black font-mono text-white block">
              {roleDetails.verifiedReports}
            </span>
            <span className="text-[10px] text-slate-400">Confirmed by NDRF / SDMA</span>
          </div>
        </div>

        {/* Relief Dispatches Assisted */}
        <div className="vrq-card p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span className="font-bold">Dispatches Coordinated</span>
            <Shield className="w-4 h-4 text-[#F59E0B]" />
          </div>
          <div className="mt-2">
            <span className="text-2xl font-black font-mono text-white block">
              {roleDetails.dispatchesAssisted}
            </span>
            <span className="text-[10px] text-slate-400">Safe convoys guided</span>
          </div>
        </div>
      </div>

      {/* 3. USER ACHIEVEMENTS (Life Saver, Quick Reporter, Route Explorer, Top Contributor) */}
      <div className="vrq-card p-4 space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-xs font-extrabold uppercase tracking-wider text-white flex items-center gap-2">
            <Award className="w-4 h-4 text-[#F59E0B]" />
            <span>User Achievements</span>
          </h2>
          <span className="text-[10px] text-[#F59E0B] font-bold bg-[#F59E0B]/15 px-2.5 py-0.5 rounded-full border border-[#F59E0B]/30">
            4 Unlocked
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {achievements.map((ach) => {
            const Icon = ach.icon;
            return (
              <div
                key={ach.id}
                className="p-3.5 rounded-2xl bg-[#050816]/85 border border-white/[0.08] flex items-start gap-3 transition hover:border-white/20"
              >
                <div
                  className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 border ${ach.color}`}
                >
                  <Icon className="w-5 h-5" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-1">
                    <span className="text-xs font-extrabold text-white truncate">
                      {ach.title}
                    </span>
                    <span className="text-[9px] text-slate-400 font-medium">
                      {ach.dateEarned}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-300 font-medium leading-relaxed mt-0.5">
                    {ach.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 4. EMERGENCY HISTORY */}
      <div className="vrq-card p-4 space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-xs font-extrabold uppercase tracking-wider text-white flex items-center gap-2">
            <History className="w-4 h-4 text-[#06B6D4]" />
            <span>Emergency Mission History</span>
          </h2>
          <span className="text-[10px] text-slate-400 font-mono">Recent Operations</span>
        </div>

        <div className="space-y-2.5">
          {emergencyHistory.map((item) => (
            <div
              key={item.id}
              className="p-3.5 rounded-2xl bg-[#050816]/85 border border-white/[0.08] flex flex-col sm:flex-row sm:items-center justify-between gap-2"
            >
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-white">{item.event}</span>
                  <span
                    className={`text-[9px] font-black px-2 py-0.5 rounded-full uppercase ${
                      item.priority === "EMERGENCY"
                        ? "bg-[#EF4444]/20 text-red-300 border border-[#EF4444]/35"
                        : "bg-[#F59E0B]/20 text-amber-300 border border-[#F59E0B]/35"
                    }`}
                  >
                    {item.priority}
                  </span>
                </div>
                <span className="text-[11px] text-slate-400 block mt-0.5">
                  Route: {item.route}
                </span>
              </div>

              <div className="flex items-center justify-between sm:justify-end gap-3 text-[11px]">
                <span className="text-slate-400 font-medium">{item.date}</span>
                <span className="text-[#10B981] font-bold flex items-center gap-1">
                  <Check className="w-3.5 h-3.5" />
                  <span>{item.status}</span>
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 5. OFFLINE REPORTING STATUS & ENCRYPTED QUEUE */}
      <div className="vrq-card p-4 space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-xs font-extrabold uppercase tracking-wider text-white flex items-center gap-2">
            <Database className="w-4 h-4 text-[#06B6D4]" />
            <span>Offline Reporting Status</span>
          </h2>
          <span
            className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full flex items-center gap-1 ${
              isOnline
                ? "bg-[#10B981]/15 text-[#10B981] border border-[#10B981]/30"
                : "bg-[#F59E0B]/15 text-[#F59E0B] border border-[#F59E0B]/30"
            }`}
          >
            {isOnline ? <Wifi className="w-3 h-3" /> : <WifiOff className="w-3 h-3" />}
            <span>{isOnline ? "Online Node" : "Offline Encrypted Queue"}</span>
          </span>
        </div>

        <p className="text-[11px] text-slate-300 leading-relaxed font-medium">
          In zero-connectivity landslide zones, hazard reports, GPS coordinates, and voice memos are
          stored in secure local storage and automatically synchronized to the disaster command center
          once cellular connectivity is restored.
        </p>

        <div className="p-3.5 rounded-2xl bg-[#050816]/90 border border-white/[0.08] flex items-center justify-between text-xs">
          <div>
            <span className="text-slate-400 block text-[10px] uppercase font-bold">
              Local Encrypted Queue
            </span>
            <span className="text-sm font-mono font-black text-white">
              {offlineQueueCount} Pending Incident Reports
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onToggleOnline}
              className="px-3 py-1.5 rounded-xl bg-white/[0.06] hover:bg-white/[0.12] border border-white/10 text-slate-300 text-[10px] font-bold transition vrq-btn-press cursor-pointer"
            >
              Simulate {isOnline ? "Offline" : "Online"}
            </button>

            <button
              onClick={handleSync}
              disabled={isSyncing || offlineQueueCount === 0 || !isOnline}
              className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-[#2563EB] to-[#06B6D4] hover:brightness-110 disabled:opacity-40 text-white text-[10px] font-black flex items-center gap-1.5 transition shadow-[0_4px_14px_rgba(6,182,212,0.3)] vrq-btn-press cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? "animate-spin" : ""}`} />
              <span>{isSyncing ? "Syncing..." : "Sync to Cloud"}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
