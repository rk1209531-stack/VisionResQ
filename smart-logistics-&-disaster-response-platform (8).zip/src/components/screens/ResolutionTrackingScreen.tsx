import React, { useState } from "react";
import { Incident, IncidentStatus, ScreenId } from "../../types";
import {
  Clock,
  CheckCircle2,
  Circle,
  Truck,
  Shield,
  Send,
  ArrowRight,
  AlertTriangle,
  User,
  MapPin,
} from "lucide-react";

interface ResolutionTrackingScreenProps {
  incident: Incident | null;
  onNavigate: (screen: ScreenId) => void;
  onAdvanceStage: (incidentId: string, nextStatus: IncidentStatus, note: string) => void;
}

const ORDERED_STAGES: IncidentStatus[] = [
  "Reported",
  "Verified",
  "Team Dispatched",
  "Work In Progress",
  "Resolved",
];

export const ResolutionTrackingScreen: React.FC<ResolutionTrackingScreenProps> = ({
  incident,
  onNavigate,
  onAdvanceStage,
}) => {
  const [customNote, setCustomNote] = useState("");

  if (!incident) {
    return (
      <div className="p-6 text-center text-slate-400">
        <p>No active incident selected to track.</p>
        <button
          onClick={() => onNavigate("home")}
          className="mt-3 px-4 py-2 bg-orange-600 text-white text-xs font-bold rounded-xl"
        >
          Return to Dashboard
        </button>
      </div>
    );
  }

  const currentStageIndex = ORDERED_STAGES.indexOf(incident.status);

  const handleAdvance = (stage: IncidentStatus) => {
    const defaultNote =
      stage === "Verified"
        ? "Consensus reached with >85% crowd validation score."
        : stage === "Team Dispatched"
        ? "BRO / SDRF Heavy Excavator unit dispatched to site."
        : stage === "Work In Progress"
        ? "Heavy boulder clearance and road stabilizing in progress."
        : "Highway inspected, debris removed, traffic normal flow resumed.";

    onAdvanceStage(incident.id, stage, customNote.trim() || defaultNote);
    setCustomNote("");
  };

  return (
    <div className="p-4 space-y-4 pb-12">
      {/* Header */}
      <div className="vrq-card p-4">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-extrabold text-white flex items-center gap-2">
            <Clock className="w-4 h-4 text-[#06B6D4]" />
            <span>Incident Status Flow</span>
          </h2>
          <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-[#06B6D4]/15 text-[#06B6D4] border border-[#06B6D4]/30">
            {incident.status}
          </span>
        </div>
        <p className="text-[11px] text-slate-400 mt-1">
          Audited lifecycle from citizen upload to road clearance verification.
        </p>
      </div>

      {/* Target Incident Snapshot */}
      <div className="vrq-card p-3.5 flex gap-3 items-center">
        <div className="w-12 h-12 rounded-xl bg-[#050816] border border-white/[0.08] overflow-hidden flex-shrink-0">
          <img
            src={incident.imageUrl}
            alt={incident.title}
            className="w-full h-full object-cover"
          />
        </div>
        <div className="min-w-0 flex-1">
          <h3 className="text-xs font-extrabold text-white truncate">{incident.title}</h3>
          <span className="text-[11px] text-slate-400 flex items-center gap-1.5 mt-0.5 truncate">
            <MapPin className="w-3 h-3 text-[#06B6D4]" />
            {incident.locationName}
          </span>
        </div>
      </div>

      {/* 5-Stage Stepper Flow */}
      <div className="vrq-card p-4 space-y-4">
        <div className="space-y-4 relative">
          {ORDERED_STAGES.map((stage, idx) => {
            const isCompleted = idx <= currentStageIndex;
            const isCurrent = idx === currentStageIndex;

            return (
              <div key={stage} className="flex items-start gap-3 relative">
                {/* Connecting Line */}
                {idx < ORDERED_STAGES.length - 1 && (
                  <div
                    className={`absolute left-[13px] top-6 bottom-0 w-0.5 ${
                      idx < currentStageIndex ? "bg-[#06B6D4]" : "bg-white/10"
                    }`}
                  />
                )}

                {/* Step Circle */}
                <div
                  className={`w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 z-10 transition-all ${
                    isCurrent
                      ? "bg-[#2563EB] text-white ring-4 ring-[#06B6D4]/25 shadow-lg"
                      : isCompleted
                      ? "bg-[#10B981] text-white"
                      : "bg-[#050816] text-slate-500 border border-white/15"
                  }`}
                >
                  {isCompleted && !isCurrent ? (
                    <CheckCircle2 className="w-4 h-4" />
                  ) : (
                    <span className="text-xs font-bold font-mono">{idx + 1}</span>
                  )}
                </div>

                {/* Stage Info & Trigger */}
                <div className="flex-1 min-w-0 pt-0.5">
                  <div className="flex items-center justify-between">
                    <span
                      className={`text-xs font-bold ${
                        isCurrent
                          ? "text-[#06B6D4] font-extrabold"
                          : isCompleted
                          ? "text-white"
                          : "text-slate-500"
                      }`}
                    >
                      {idx + 1}. {stage}
                    </span>

                    {/* Step Advance Button */}
                    {!isCompleted && idx === currentStageIndex + 1 && (
                      <button
                        onClick={() => handleAdvance(stage)}
                        className="px-2.5 py-1 rounded-xl bg-gradient-to-r from-[#2563EB] to-[#06B6D4] hover:brightness-110 text-white text-[10px] font-bold shadow-sm transition vrq-btn-press cursor-pointer"
                      >
                        Advance to this stage →
                      </button>
                    )}
                  </div>

                  {/* Stage description notes */}
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    {stage === "Reported" && "Photo captured with GPS coordinates and analyzed by Gemini Vision."}
                    {stage === "Verified" && "Validated by verified local drivers and geofenced users."}
                    {stage === "Team Dispatched" && "Emergency response team and heavy machinery deployed."}
                    {stage === "Work In Progress" && "Debris removal, landslide stabilization, and detour management."}
                    {stage === "Resolved" && "Road safety certified, green corridor reopened for all logistics."}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Resolution Milestone Audit Trail */}
      <div className="vrq-card p-4 space-y-3">
        <h3 className="text-xs font-extrabold text-white uppercase tracking-wider flex items-center gap-2">
          <Shield className="w-4 h-4 text-[#10B981]" />
          <span>Audit Log Entries</span>
        </h3>

        <div className="space-y-2">
          {incident.resolutionTimeline.map((item, idx) => (
            <div
              key={idx}
              className="p-2.5 rounded-xl bg-[#050816]/85 border border-white/[0.08] text-xs"
            >
              <div className="flex items-center justify-between text-[10px]">
                <span className="font-bold text-[#06B6D4]">{item.step}</span>
                <span className="text-slate-400">{item.timestamp}</span>
              </div>
              <p className="text-[11px] text-slate-200 mt-0.5">{item.note}</p>
              <span className="text-[9px] text-slate-500 block mt-0.5">
                Officer: {item.updatedBy}
              </span>
            </div>
          ))}
        </div>

        {/* Custom Milestone Logger Input */}
        <div className="pt-2.5 border-t border-white/[0.08] space-y-1.5">
          <label className="text-[10px] text-slate-400 block font-semibold">
            Add Official Milestone Note
          </label>
          <div className="flex gap-2">
            <input
              type="text"
              value={customNote}
              onChange={(e) => setCustomNote(e.target.value)}
              placeholder="e.g. 80% debris cleared, single lane opened"
              className="flex-1 bg-[#050816]/90 border border-white/[0.1] rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#06B6D4]"
            />
            <button
              onClick={() => {
                if (customNote.trim()) {
                  onAdvanceStage(incident.id, incident.status, customNote);
                  setCustomNote("");
                }
              }}
              className="px-3.5 py-2 bg-gradient-to-r from-[#2563EB] to-[#06B6D4] hover:brightness-110 text-white rounded-xl text-xs font-bold transition flex items-center gap-1 vrq-btn-press cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Log</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
