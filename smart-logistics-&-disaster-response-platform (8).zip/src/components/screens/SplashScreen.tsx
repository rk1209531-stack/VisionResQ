import React from "react";
import { ShieldAlert, Sparkles, ArrowRight, CheckCircle2 } from "lucide-react";
import { ScreenId } from "../../types";

interface SplashScreenProps {
  onNavigate: (screen: ScreenId) => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onNavigate }) => {
  return (
    <div className="flex flex-col items-center justify-between min-h-[580px] p-6 text-center">
      {/* Top SIH Badge */}
      <div className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-bold bg-[#2563EB]/15 text-[#06B6D4] border border-[#06B6D4]/30 shadow-[0_0_20px_rgba(6,182,212,0.15)]">
        <Sparkles className="w-3.5 h-3.5 text-[#06B6D4]" />
        <span>Smart India Hackathon 2026 • SIH26002</span>
      </div>

      {/* Main Logo & Animated Shield */}
      <div className="my-auto flex flex-col items-center">
        <div className="relative mb-6">
          <div className="w-24 h-24 rounded-3xl bg-gradient-to-tr from-[#2563EB] via-[#1D4ED8] to-[#06B6D4] flex items-center justify-center shadow-[0_12px_36px_rgba(37,99,235,0.4)] border border-[#06B6D4]/30">
            <ShieldAlert className="w-12 h-12 text-white" />
          </div>
          <div className="absolute -bottom-2 -right-2 bg-[#10B981] text-[#050816] font-black text-[10px] px-2.5 py-0.5 rounded-full border-2 border-[#050816] shadow-md">
            AI READY
          </div>
        </div>

        <h1 className="text-xl font-extrabold text-white tracking-tight leading-snug">
          Smart Logistics &<br />Disaster Response Platform
        </h1>

        <p className="mt-2.5 text-xs text-slate-400 max-w-xs leading-relaxed">
          Empowering citizens, drivers, logistics fleets, and disaster response teams with multimodal Gemini AI and real-time hazard verification.
        </p>

        {/* Core Pillars */}
        <div className="mt-6 flex flex-wrap justify-center gap-2 text-[11px] text-slate-300">
          <span className="px-3 py-1.5 vrq-card-subtle rounded-full flex items-center gap-1.5 font-medium">
            <CheckCircle2 className="w-3.5 h-3.5 text-[#10B981]" /> Gemini Vision
          </span>
          <span className="px-3 py-1.5 vrq-card-subtle rounded-full flex items-center gap-1.5 font-medium">
            <CheckCircle2 className="w-3.5 h-3.5 text-[#06B6D4]" /> Crowd Verification
          </span>
          <span className="px-3 py-1.5 vrq-card-subtle rounded-full flex items-center gap-1.5 font-medium">
            <CheckCircle2 className="w-3.5 h-3.5 text-[#2563EB]" /> Offline Sync
          </span>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="w-full space-y-2.5">
        <button
          onClick={() => onNavigate("home")}
          className="w-full py-3.5 vrq-btn-primary text-white font-bold text-sm rounded-2xl flex items-center justify-center gap-2 transition"
        >
          <span>Launch Platform</span>
          <ArrowRight className="w-4 h-4" />
        </button>

        <div className="grid grid-cols-2 gap-2.5 text-xs">
          <button
            onClick={() => onNavigate("login")}
            className="py-2.5 vrq-card-subtle hover:border-[#06B6D4]/40 text-slate-200 font-semibold rounded-xl transition vrq-press"
          >
            Log In
          </button>
          <button
            onClick={() => onNavigate("register")}
            className="py-2.5 vrq-card-subtle hover:border-[#06B6D4]/40 text-slate-200 font-semibold rounded-xl transition vrq-press"
          >
            Register
          </button>
        </div>
      </div>
    </div>
  );
};
