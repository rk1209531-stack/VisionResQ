import React, { useState } from "react";
import { UserRole, ScreenId } from "../../types";
import { UserPlus, Shield, MapPin, Building, Truck, ArrowRight } from "lucide-react";

interface RegistrationScreenProps {
  currentRole: UserRole;
  onRoleChange: (role: UserRole) => void;
  onNavigate: (screen: ScreenId) => void;
}

export const RegistrationScreen: React.FC<RegistrationScreenProps> = ({
  currentRole,
  onRoleChange,
  onNavigate,
}) => {
  const [name, setName] = useState("Vikram Malhotra");
  const [phone, setPhone] = useState("+91 98765 11223");
  const [organization, setOrganization] = useState("National Logistics Corridor Org");
  const [location, setLocation] = useState("Dehradun / Rishikesh, Uttarakhand");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onNavigate("home");
  };

  return (
    <div className="p-4 flex flex-col justify-between min-h-[580px]">
      <div className="space-y-4">
        <div className="vrq-card p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#2563EB]/20 text-[#06B6D4] border border-[#06B6D4]/30 flex items-center justify-center">
            <UserPlus className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-extrabold text-white tracking-tight">Create Account</h2>
            <p className="text-[11px] text-slate-400">Join the SIH 2026 Disaster Response Network</p>
          </div>
        </div>

        {/* Role Select & Form */}
        <div className="vrq-card p-4 space-y-3">
          <div>
            <label className="text-[11px] font-bold uppercase tracking-wider text-slate-300 block mb-2">
              Register As:
            </label>
            <div className="grid grid-cols-2 gap-1.5 bg-[#050816]/80 p-1 rounded-xl border border-slate-800/80 text-[11px]">
              <button
                type="button"
                onClick={() => onRoleChange("citizen")}
                className={`py-2 px-2 rounded-lg font-medium transition vrq-press ${
                  currentRole === "citizen"
                    ? "bg-gradient-to-r from-[#2563EB] to-[#06B6D4] text-white font-bold shadow-md"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                Citizen / Commuter
              </button>
              <button
                type="button"
                onClick={() => onRoleChange("driver")}
                className={`py-2 px-2 rounded-lg font-medium transition vrq-press ${
                  currentRole === "driver"
                    ? "bg-gradient-to-r from-[#2563EB] to-[#06B6D4] text-white font-bold shadow-md"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                Commercial Driver
              </button>
              <button
                type="button"
                onClick={() => onRoleChange("emergency")}
                className={`py-2 px-2 rounded-lg font-medium transition vrq-press ${
                  currentRole === "emergency"
                    ? "bg-gradient-to-r from-[#2563EB] to-[#06B6D4] text-white font-bold shadow-md"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                Emergency Responder
              </button>
              <button
                type="button"
                onClick={() => onRoleChange("authority")}
                className={`py-2 px-2 rounded-lg font-medium transition vrq-press ${
                  currentRole === "authority"
                    ? "bg-gradient-to-r from-[#2563EB] to-[#06B6D4] text-white font-bold shadow-md"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                Govt Authority / NDRF
              </button>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-3 pt-1">
            <div>
              <label className="text-[11px] font-semibold text-slate-400 block mb-1">Full Name</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-[#050816]/80 border border-slate-800 rounded-xl py-2.5 px-3 text-xs text-white focus:outline-none focus:border-[#06B6D4]"
                required
              />
            </div>

            <div>
              <label className="text-[11px] font-semibold text-slate-400 block mb-1">Mobile Number</label>
              <input
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full bg-[#050816]/80 border border-slate-800 rounded-xl py-2.5 px-3 text-xs text-white focus:outline-none focus:border-[#06B6D4]"
                required
              />
            </div>

            {(currentRole === "authority" || currentRole === "emergency") && (
              <div>
                <label className="text-[11px] font-semibold text-slate-400 block mb-1">
                  Agency / Fleet Department
                </label>
                <div className="relative">
                  <Building className="w-3.5 h-3.5 text-[#06B6D4] absolute left-3 top-3" />
                  <input
                    type="text"
                    value={organization}
                    onChange={(e) => setOrganization(e.target.value)}
                    className="w-full bg-[#050816]/80 border border-slate-800 rounded-xl py-2.5 pl-9 pr-3 text-xs text-white focus:outline-none focus:border-[#06B6D4]"
                  />
                </div>
              </div>
            )}

            <div>
              <label className="text-[11px] font-semibold text-slate-400 block mb-1">Primary Transit Region</label>
              <div className="relative">
                <MapPin className="w-3.5 h-3.5 text-[#06B6D4] absolute left-3 top-3" />
                <input
                  type="text"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  className="w-full bg-[#050816]/80 border border-slate-800 rounded-xl py-2.5 pl-9 pr-3 text-xs text-white focus:outline-none focus:border-[#06B6D4]"
                />
              </div>
            </div>

            <div className="p-2.5 rounded-xl vrq-card-subtle text-[11px] text-slate-400">
              <span className="text-[#10B981] font-bold">✓ Geofence Permission</span>: Automatic GPS tag for emergency incident dispatch and verified safe routing.
            </div>

            <button
              type="submit"
              className="w-full py-3 vrq-btn-primary text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition mt-2"
            >
              <span>Register & Enable GPS</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </form>
        </div>
      </div>

      <div className="text-center pt-4 border-t border-slate-800/80 text-xs text-slate-400">
        Already registered?{" "}
        <button
          onClick={() => onNavigate("login")}
          className="text-[#06B6D4] font-bold hover:underline"
        >
          Sign In
        </button>
      </div>
    </div>
  );
};
