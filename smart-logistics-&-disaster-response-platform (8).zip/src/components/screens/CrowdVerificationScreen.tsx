import React from "react";
import { Incident, ScreenId } from "../../types";
import {
  Users,
  ShieldCheck,
  ThumbsUp,
  ThumbsDown,
  MapPin,
  Clock,
  Sparkles,
  CheckCircle2,
  ChevronRight,
  Filter,
} from "lucide-react";

interface CrowdVerificationScreenProps {
  incidents: Incident[];
  onVote: (incidentId: string, type: "confirm" | "reject") => void;
  onSelectIncident: (incident: Incident) => void;
  onNavigate: (screen: ScreenId) => void;
}

export const CrowdVerificationScreen: React.FC<CrowdVerificationScreenProps> = ({
  incidents,
  onVote,
  onSelectIncident,
  onNavigate,
}) => {
  return (
    <div className="p-4 space-y-4 pb-12">
      {/* Step 3 Header */}
      <div className="vrq-card p-4">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-extrabold text-white flex items-center gap-2">
            <Users className="w-4 h-4 text-[#10B981]" />
            <span>Step 3: Crowd Verification</span>
          </h2>
          <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-[#10B981]/15 text-[#10B981] border border-[#10B981]/30">
            Geofence Active
          </span>
        </div>
        <p className="text-[11px] text-slate-400 mt-1">
          Nearby commuters and drivers vote to validate or reject AI hazard reports to prevent false alarms.
        </p>
      </div>

      {/* How it Works / Trust Score Card */}
      <div className="vrq-card p-4 text-xs space-y-1.5">
        <div className="flex items-center justify-between">
          <span className="font-bold text-slate-200 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-[#06B6D4]" />
            <span>Crowd Consensus Algorithm</span>
          </span>
          <span className="text-[10px] text-[#10B981] font-mono font-bold bg-[#10B981]/10 px-2 py-0.5 rounded-md border border-[#10B981]/25">
            Min. 80% for Authority Alert
          </span>
        </div>
        <p className="text-[11px] text-slate-400 leading-relaxed">
          Confidence Score = (Confirmations / (Confirmations + Rejections)) × 100 with GPS proximity weighting.
        </p>
      </div>

      {/* Nearby Incidents for Verification */}
      <div className="space-y-3">
        {incidents.map((incident) => {
          const { crowdVerification, aiAnalysis } = incident;

          return (
            <div
              key={incident.id}
              className="vrq-card p-4 space-y-3"
            >
              {/* Header Info */}
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="px-2.5 py-0.5 rounded-md bg-[#2563EB]/20 text-[#06B6D4] border border-[#06B6D4]/30 font-black text-[10px]">
                      {incident.type}
                    </span>
                    <span className="text-[10px] text-slate-400 flex items-center gap-1">
                      <Clock className="w-3 h-3 text-slate-500" />
                      {incident.reportedAt}
                    </span>
                  </div>
                  <h3
                    onClick={() => {
                      onSelectIncident(incident);
                      onNavigate("incident_details");
                    }}
                    className="text-xs font-extrabold text-white hover:text-[#06B6D4] cursor-pointer leading-snug transition"
                  >
                    {incident.title}
                  </h3>
                  <p className="text-[11px] text-slate-400 flex items-center gap-1.5 mt-1">
                    <MapPin className="w-3 h-3 text-[#06B6D4] flex-shrink-0" />
                    <span className="truncate">{incident.locationName}</span>
                  </p>
                </div>

                <div className="text-right flex-shrink-0 bg-[#10B981]/15 border border-[#10B981]/30 px-2.5 py-1 rounded-xl">
                  <span className="text-sm font-black font-mono text-[#10B981] block leading-none">
                    {crowdVerification.confidenceScore}%
                  </span>
                  <span className="text-[8px] text-slate-300 uppercase font-bold">Confidence</span>
                </div>
              </div>

              {/* Mini Photo Thumbnail */}
              <div className="rounded-xl overflow-hidden aspect-[21/9] bg-[#050816] relative border border-white/[0.08]">
                <img
                  src={incident.imageUrl}
                  alt={incident.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-2 right-2 px-2.5 py-0.5 rounded-full text-[10px] font-black font-mono bg-[#EF4444]/95 text-white shadow-lg border border-white/20 backdrop-blur-md">
                  Risk {aiAnalysis.riskScore}%
                </div>
              </div>

              {/* Verification Voting Actions */}
              <div className="pt-2.5 border-t border-white/[0.08] flex items-center justify-between gap-2">
                <div className="flex items-center gap-2 text-xs flex-1">
                  <button
                    onClick={() => onVote(incident.id, "confirm")}
                    className={`flex-1 py-2.5 px-3 rounded-xl border flex items-center justify-center gap-1.5 transition text-xs font-bold vrq-btn-press cursor-pointer ${
                      crowdVerification.userVoted === "confirm"
                        ? "bg-[#10B981] text-white border-emerald-400 shadow-[0_4px_14px_rgba(16,185,129,0.35)]"
                        : "bg-[#050816]/85 hover:bg-[#10B981]/15 text-slate-300 border-white/[0.08]"
                    }`}
                  >
                    <ThumbsUp className="w-3.5 h-3.5 text-[#10B981]" />
                    <span>Confirm ({crowdVerification.confirmations})</span>
                  </button>

                  <button
                    onClick={() => onVote(incident.id, "reject")}
                    className={`flex-1 py-2.5 px-3 rounded-xl border flex items-center justify-center gap-1.5 transition text-xs font-bold vrq-btn-press cursor-pointer ${
                      crowdVerification.userVoted === "reject"
                        ? "bg-[#EF4444] text-white border-red-400 shadow-[0_4px_14px_rgba(239,68,68,0.35)]"
                        : "bg-[#050816]/85 hover:bg-[#EF4444]/15 text-slate-300 border-white/[0.08]"
                    }`}
                  >
                    <ThumbsDown className="w-3.5 h-3.5 text-[#EF4444]" />
                    <span>Reject ({crowdVerification.rejections})</span>
                  </button>
                </div>

                <button
                  onClick={() => {
                    onSelectIncident(incident);
                    onNavigate("incident_details");
                  }}
                  className="p-2.5 rounded-xl bg-[#050816]/90 border border-white/[0.08] hover:border-[#06B6D4]/40 text-slate-300 hover:text-white transition vrq-btn-press cursor-pointer"
                  title="View Incident Details"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
