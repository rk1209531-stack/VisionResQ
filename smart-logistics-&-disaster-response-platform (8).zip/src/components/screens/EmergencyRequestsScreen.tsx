import React, { useState, useEffect, useRef } from "react";
import { EmergencyRequest, ScreenId, UserRole } from "../../types";
import {
  AlertTriangle,
  ArrowLeft,
  X,
  Phone,
  MapPin,
  Users,
  ShieldCheck,
  CheckCircle2,
  AlertOctagon,
  HeartPulse,
  Truck,
  Package,
  Clock,
  Radio,
  ChevronDown,
  ChevronUp,
} from "lucide-react";

interface EmergencyRequestsScreenProps {
  emergencyRequests: EmergencyRequest[];
  currentRole: UserRole;
  onNavigate: (screen: ScreenId) => void;
  onCreateRequest: (req: Omit<EmergencyRequest, "id" | "requestedAt" | "status">) => void;
  onUpdateStatus: (id: string, status: EmergencyRequest["status"]) => void;
  isOnline?: boolean;
}

export const EmergencyRequestsScreen: React.FC<EmergencyRequestsScreenProps> = ({
  emergencyRequests,
  currentRole,
  onNavigate,
  onCreateRequest,
  onUpdateStatus,
  isOnline = true,
}) => {
  // Hold-to-activate logic (3 seconds)
  const [isHolding, setIsHolding] = useState(false);
  const [holdProgress, setHoldProgress] = useState(0);
  const [isSosActive, setIsSosActive] = useState(false);
  const [activeBeaconId, setActiveBeaconId] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [showCallModal, setShowCallModal] = useState(false);
  const [showRequestsDrawer, setShowRequestsDrawer] = useState(false);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);

  const holdTimerRef = useRef<NodeJS.Timeout | null>(null);
  const progressIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const startTimeRef = useRef<number>(0);

  // Sound synthesis for siren feedback
  const playSirenSound = () => {
    try {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = "sawtooth";
      osc.frequency.setValueAtTime(800, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(1400, ctx.currentTime + 0.3);
      osc.frequency.exponentialRampToValueAtTime(800, ctx.currentTime + 0.6);

      gain.gain.setValueAtTime(0.3, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.9);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      osc.stop(ctx.currentTime + 0.9);
    } catch {
      // Ignore audio failure
    }
  };

  // Trigger SOS Beacon activation
  const triggerSosActivation = () => {
    setIsSosActive(true);
    playSirenSound();
    const beaconId = `SOS-${Math.floor(1000 + Math.random() * 9000)}`;
    setActiveBeaconId(beaconId);

    // Create real emergency request in state / Firestore
    onCreateRequest({
      requestType: "Ambulance",
      urgency: "Critical Priority",
      origin: "Live Device Location (NH-44 Corridor, Mile 18)",
      destination: "Nearest Trauma Hospital / Base Camp",
      passengersOrCargo: "Critical Citizen SOS Beacon - Immediate Extraction Required",
      contactPerson: "Citizen Reporter (Verified)",
      contactPhone: "+91 94190 99881",
    });

    setToastMessage("🚨 SOS Beacon Broadcasted! NDRF Rescue Units Alerted.");
    setTimeout(() => setToastMessage(null), 5000);
  };

  // Start holding
  const startHolding = () => {
    if (isSosActive) return;
    setIsHolding(true);
    startTimeRef.current = Date.now();
    setHoldProgress(0);

    // Progress interval (3000ms duration)
    progressIntervalRef.current = setInterval(() => {
      const elapsed = Date.now() - startTimeRef.current;
      const progress = Math.min(100, (elapsed / 3000) * 100);
      setHoldProgress(progress);

      if (progress >= 100) {
        if (progressIntervalRef.current) clearInterval(progressIntervalRef.current);
        if (holdTimerRef.current) clearTimeout(holdTimerRef.current);
        setIsHolding(false);
        setHoldProgress(0);
        triggerSosActivation();
      }
    }, 50);
  };

  // Stop holding
  const stopHolding = () => {
    if (progressIntervalRef.current) clearInterval(progressIntervalRef.current);
    if (holdTimerRef.current) clearTimeout(holdTimerRef.current);
    setIsHolding(false);
    setHoldProgress(0);
  };

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isSosActive) {
      timer = setInterval(() => {
        setElapsedSeconds((prev) => prev + 1);
      }, 1000);
    } else {
      setElapsedSeconds(0);
    }
    return () => clearInterval(timer);
  }, [isSosActive]);

  const handleShareLocation = () => {
    const coords = "34.0837° N, 74.7973° E";
    if (navigator.clipboard) {
      navigator.clipboard.writeText(`Emergency Location: ${coords} (VisionResQ Rescue Beacon)`);
    }
    setToastMessage("📍 GPS Location (34.0837° N, 74.7973° E) shared & copied to clipboard.");
    setTimeout(() => setToastMessage(null), 4000);
  };

  const handleNotifyContacts = () => {
    setToastMessage("📲 Emergency broadcast dispatched to 3 registered next-of-kin contacts.");
    setTimeout(() => setToastMessage(null), 4000);
  };

  const cancelSos = () => {
    setIsSosActive(false);
    setActiveBeaconId(null);
    setToastMessage("SOS Alert canceled by user.");
    setTimeout(() => setToastMessage(null), 3000);
  };

  // SVG circular progress calculation
  const circleRadius = 68;
  const circumference = 2 * Math.PI * circleRadius;
  const strokeDashoffset = circumference - (holdProgress / 100) * circumference;

  return (
    <div
      id="sos-interface-container"
      className="relative w-full max-w-[420px] mx-auto min-h-[580px] h-full flex flex-col justify-between bg-gradient-to-b from-[#1a050a] via-[#070818] to-[#050816] text-white p-4 select-none overflow-y-auto"
    >
      {/* Background Radial Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 sm:w-72 sm:h-72 rounded-full bg-[#EF4444]/15 blur-3xl pointer-events-none" />

      {/* 1. TOP HEADER NAVIGATION (Back & Close) */}
      <div className="relative z-20 flex items-center justify-between pt-0.5 px-0.5 mb-2">
        <button
          id="sos-back-btn"
          onClick={() => onNavigate("home")}
          aria-label="Go Back"
          className="w-9 h-9 rounded-xl flex items-center justify-center text-slate-300 hover:text-white bg-white/[0.06] border border-white/[0.08] hover:bg-white/[0.1] transition vrq-btn-press cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>

        <div className="flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-[#EF4444]/15 border border-[#EF4444]/40 shadow-[0_0_16px_rgba(239,68,68,0.2)]">
          <span className="w-2 h-2 rounded-full bg-[#EF4444] animate-pulse" />
          <span className="text-[10px] font-black tracking-widest text-[#EF4444] uppercase">
            VisionResQ SOS
          </span>
        </div>

        <button
          id="sos-close-btn"
          onClick={() => onNavigate("home")}
          aria-label="Close"
          className="w-9 h-9 rounded-xl flex items-center justify-center text-slate-300 hover:text-white bg-white/[0.06] border border-white/[0.08] hover:bg-white/[0.1] transition vrq-btn-press cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Floating Toast Notification */}
      {toastMessage && (
        <div className="relative z-30 mx-auto max-w-sm w-full transition-all animate-in fade-in slide-in-from-top-2 mb-2">
          <div className="bg-[#050816]/95 border border-[#EF4444]/70 text-white px-3.5 py-2.5 rounded-2xl text-[11px] font-semibold shadow-2xl flex items-center gap-2 backdrop-blur-xl">
            <Radio className="w-3.5 h-3.5 text-[#EF4444] animate-pulse flex-shrink-0" />
            <span className="flex-1">{toastMessage}</span>
          </div>
        </div>
      )}

      {/* Active SOS Response State Banner */}
      {isSosActive && (
        <div className="relative z-20 my-2 mx-auto max-w-sm w-full bg-[#EF4444]/20 border border-[#EF4444] rounded-2xl p-3 shadow-2xl backdrop-blur-xl animate-pulse">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#EF4444] animate-ping" />
              <div>
                <span className="text-xs font-black text-white block leading-tight">
                  🚨 BEACON ACTIVE • {activeBeaconId}
                </span>
                <span className="text-[9px] text-red-200">
                  Transmitting GPS • {elapsedSeconds}s elapsed
                </span>
              </div>
            </div>
            <button
              onClick={cancelSos}
              className="px-2.5 py-1 rounded-xl bg-[#050816] border border-[#EF4444]/50 text-red-300 text-[9px] font-bold hover:bg-slate-900 cursor-pointer"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* 2. CENTER CONCENTRIC RINGS & MASSIVE GLOWING SOS BUTTON (Mobile Proportioned) */}
      <div className="relative z-10 flex flex-col items-center justify-center my-auto py-2">
        {/* Outer Pulsing Concentric Rings */}
        <div className="relative flex items-center justify-center">
          {/* Ring 1 - Deep outer halo */}
          <div className="w-56 h-56 sm:w-64 sm:h-64 rounded-full border border-[#EF4444]/20 flex items-center justify-center transition-all duration-300">
            {/* Ring 2 - Mid halo */}
            <div
              className={`w-46 h-46 sm:w-52 sm:h-52 rounded-full border border-[#EF4444]/35 flex items-center justify-center transition-all duration-300 ${
                isHolding || isSosActive ? "scale-105 border-[#EF4444]/60" : ""
              }`}
            >
              {/* Ring 3 - Inner halo */}
              <div
                className={`w-38 h-38 sm:w-42 sm:h-42 rounded-full border border-[#EF4444]/50 flex items-center justify-center transition-all duration-300 ${
                  isHolding || isSosActive ? "scale-105 border-[#EF4444]/80" : ""
                }`}
              >
                {/* Glowing Red SOS Button */}
                <button
                  id="main-sos-button"
                  onMouseDown={startHolding}
                  onMouseUp={stopHolding}
                  onMouseLeave={stopHolding}
                  onTouchStart={startHolding}
                  onTouchEnd={stopHolding}
                  className={`w-32 h-32 sm:w-36 sm:h-36 rounded-full bg-gradient-to-b from-[#EF4444] via-[#DC2626] to-[#B91C1C] shadow-[0_0_45px_rgba(239,68,68,0.6)] flex flex-col items-center justify-center cursor-pointer relative overflow-hidden transition-all duration-200 ring-4 ring-[#EF4444]/30 active:scale-95 select-none ${
                    isHolding ? "scale-105 shadow-[0_0_65px_rgba(239,68,68,0.9)]" : ""
                  } ${isSosActive ? "animate-pulse ring-red-400" : ""}`}
                  aria-label="Emergency SOS button, hold for 3 seconds"
                >
                  {/* SVG Circular Progress Ring */}
                  <svg
                    className="absolute inset-0 w-full h-full -rotate-90 pointer-events-none"
                    viewBox="0 0 160 160"
                  >
                    <circle
                      cx="80"
                      cy="80"
                      r={circleRadius}
                      stroke="rgba(255, 255, 255, 0.15)"
                      strokeWidth="5"
                      fill="transparent"
                    />
                    <circle
                      cx="80"
                      cy="80"
                      r={circleRadius}
                      stroke="#ffffff"
                      strokeWidth="5"
                      fill="transparent"
                      strokeDasharray={circumference}
                      strokeDashoffset={strokeDashoffset}
                      strokeLinecap="round"
                      className="transition-all duration-75"
                    />
                  </svg>

                  {/* Warning Triangle Icon */}
                  <div className="relative z-10 flex items-center justify-center">
                    <AlertTriangle className="w-7 h-7 sm:w-8 sm:h-8 text-white fill-white/20 stroke-[2.5]" />
                  </div>

                  {/* Large SOS Text */}
                  <span className="relative z-10 text-2xl sm:text-3xl font-black text-white tracking-wider mt-0.5 drop-shadow-md leading-none">
                    SOS
                  </span>

                  {/* Hold for 3 seconds Subtitle */}
                  <span className="relative z-10 text-[10px] sm:text-[11px] font-semibold text-rose-100/90 mt-1">
                    {isHolding
                      ? `Release in ${Math.max(1, Math.ceil((100 - holdProgress) * 0.03))}s`
                      : isSosActive
                      ? "Transmitting..."
                      : "Hold for 3s"}
                  </span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* 3. INFORMATION COPY */}
        <p className="text-slate-300 text-center text-[11px] sm:text-xs font-medium max-w-[260px] mx-auto leading-relaxed mt-3">
          Your location will be broadcasted to disaster rescue teams & nearest convoys.
        </p>
      </div>

      {/* 4. THREE ACTION CARDS (Call Emergency, Share Location, Notify Contacts) */}
      <div className="relative z-10 w-full max-w-sm mx-auto mb-2">
        <div className="grid grid-cols-3 gap-2.5">
          {/* Card 1: Call Emergency */}
          <button
            id="action-call-emergency"
            onClick={() => setShowCallModal(true)}
            className="group vrq-card p-3 flex flex-col items-center justify-center text-center transition-all duration-150 vrq-btn-press cursor-pointer"
          >
            <div className="w-9 h-9 rounded-xl bg-[#EF4444]/15 text-[#EF4444] border border-[#EF4444]/30 flex items-center justify-center group-hover:scale-110 transition">
              <Phone className="w-4 h-4" />
            </div>
            <span className="text-[10px] font-bold text-slate-200 mt-1.5 leading-tight">
              Call<br />112 / 108
            </span>
          </button>

          {/* Card 2: Share Location */}
          <button
            id="action-share-location"
            onClick={handleShareLocation}
            className="group vrq-card p-3 flex flex-col items-center justify-center text-center transition-all duration-150 vrq-btn-press cursor-pointer"
          >
            <div className="w-9 h-9 rounded-xl bg-[#F59E0B]/15 text-[#F59E0B] border border-[#F59E0B]/30 flex items-center justify-center group-hover:scale-110 transition">
              <MapPin className="w-4 h-4" />
            </div>
            <span className="text-[10px] font-bold text-slate-200 mt-1.5 leading-tight">
              Share<br />Location
            </span>
          </button>

          {/* Card 3: Notify Contacts */}
          <button
            id="action-notify-contacts"
            onClick={handleNotifyContacts}
            className="group vrq-card p-3 flex flex-col items-center justify-center text-center transition-all duration-150 vrq-btn-press cursor-pointer"
          >
            <div className="w-9 h-9 rounded-xl bg-[#06B6D4]/15 text-[#06B6D4] border border-[#06B6D4]/30 flex items-center justify-center group-hover:scale-110 transition">
              <Users className="w-4 h-4" />
            </div>
            <span className="text-[10px] font-bold text-slate-200 mt-1.5 leading-tight">
              Notify<br />Contacts
            </span>
          </button>
        </div>
      </div>

      {/* 5. BOTTOM STATUS PILL & DRAWER */}
      <div className="relative z-10 flex flex-col items-center justify-center pb-1">
        <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-[#0b132b]/85 border border-white/[0.08] text-[10px] text-slate-200 shadow-sm">
          <span
            className={`w-1.5 h-1.5 rounded-full ${
              isOnline ? "bg-[#10B981] animate-pulse" : "bg-[#F59E0B]"
            }`}
          />
          <span className="font-semibold">
            {isOnline ? "Online • Live GPS Active" : "Offline • GPS Beacon Active"}
          </span>
        </div>

        {/* Collapsible Corridor Queue Button for Responders */}
        <button
          onClick={() => setShowRequestsDrawer(!showRequestsDrawer)}
          className="mt-2 text-[10px] text-slate-400 hover:text-slate-200 flex items-center gap-1 transition cursor-pointer"
        >
          <span>Active Green Wave Corridors ({emergencyRequests.length})</span>
          {showRequestsDrawer ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
        </button>
      </div>

      {/* Emergency Helpline Direct Call Modal */}
      {showCallModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="vrq-card border-[#EF4444]/70 p-4 max-w-xs w-full space-y-3 animate-in zoom-in-95">
            <div className="flex items-center justify-between pb-2 border-b border-white/[0.08]">
              <span className="text-xs font-black text-white flex items-center gap-1.5">
                <Phone className="w-4 h-4 text-[#EF4444]" />
                <span>Emergency Helplines</span>
              </span>
              <button
                onClick={() => setShowCallModal(false)}
                className="text-slate-400 hover:text-white text-xs font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="space-y-2 text-xs">
              <a
                href="tel:112"
                className="flex items-center justify-between p-2.5 rounded-xl bg-[#EF4444]/20 hover:bg-[#EF4444]/30 border border-[#EF4444]/50 text-white transition"
              >
                <div>
                  <span className="font-black block">112 National Emergency</span>
                  <span className="text-[10px] text-red-200">Police, Fire & Ambulance</span>
                </div>
                <span className="px-2.5 py-1 bg-[#EF4444] rounded-lg text-[10px] font-bold">Call →</span>
              </a>

              <a
                href="tel:108"
                className="flex items-center justify-between p-2.5 rounded-xl bg-[#050816]/90 hover:bg-white/[0.06] border border-white/[0.08] text-white transition"
              >
                <div>
                  <span className="font-black block">108 Disaster Ambulance</span>
                  <span className="text-[10px] text-slate-300">Critical Medical Extraction</span>
                </div>
                <span className="px-2.5 py-1 bg-[#2563EB] rounded-lg text-[10px] font-bold">Call →</span>
              </a>

              <a
                href="tel:1077"
                className="flex items-center justify-between p-2.5 rounded-xl bg-[#050816]/90 hover:bg-white/[0.06] border border-white/[0.08] text-white transition"
              >
                <div>
                  <span className="font-black block">1077 DDMA Helpline</span>
                  <span className="text-[10px] text-slate-300">District Disaster Authority</span>
                </div>
                <span className="px-2.5 py-1 bg-[#2563EB] rounded-lg text-[10px] font-bold">Call →</span>
              </a>
            </div>
          </div>
        </div>
      )}

      {/* Expandable Active Green Wave Corridors Drawer */}
      {showRequestsDrawer && (
        <div className="relative z-20 mt-4 pt-4 border-t border-white/[0.08] space-y-3 vrq-card p-3.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-black text-white flex items-center gap-1.5">
              <AlertOctagon className="w-3.5 h-3.5 text-[#EF4444]" />
              <span>Active Emergency Missions ({emergencyRequests.length})</span>
            </span>
          </div>

          <div className="space-y-2 max-h-48 overflow-y-auto">
            {emergencyRequests.map((req) => (
              <div
                key={req.id}
                className="p-2.5 rounded-xl bg-[#050816]/90 border border-white/[0.08] text-xs space-y-1"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white">{req.requestType}</span>
                  <span className="text-[9px] px-2 py-0.5 rounded-full bg-[#EF4444]/20 text-red-300 border border-[#EF4444]/40 font-bold">
                    {req.status}
                  </span>
                </div>
                <p className="text-[10px] text-slate-400 truncate">
                  {req.origin} → {req.destination}
                </p>
                {(currentRole === "authority" || currentRole === "emergency") && (
                  <select
                    value={req.status}
                    onChange={(e) => onUpdateStatus(req.id, e.target.value as any)}
                    className="w-full mt-1 bg-[#0b132b] border border-white/10 text-white text-[10px] rounded-lg p-1.5"
                  >
                    <option value="Pending Dispatch">Pending Dispatch</option>
                    <option value="Green Corridor Active">Green Corridor Active</option>
                    <option value="In Transit">In Transit</option>
                    <option value="Delivered">Delivered</option>
                  </select>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
