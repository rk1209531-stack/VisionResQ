import React, { useState } from "react";
import { ScreenId, UserRole } from "../../types";
import {
  ShieldAlert,
  Award,
  Layers,
  Cpu,
  Database,
  Radio,
  CheckCircle2,
  ExternalLink,
  Smartphone,
  Maximize2,
  FileCode2,
  Zap,
  ArrowRight,
  Route,
  Activity,
  AlertTriangle,
  Ambulance,
  WifiOff,
  Copy,
  Check,
} from "lucide-react";

interface SIHDeliverablesScreenProps {
  onNavigate: (screen: ScreenId) => void;
  onViewModeChange: (mode: "mobile" | "fullscreen" | "deliverables") => void;
}

export const SIHDeliverablesScreen: React.FC<SIHDeliverablesScreenProps> = ({
  onNavigate,
  onViewModeChange,
}) => {
  const [copiedSection, setCopiedSection] = useState<string | null>(null);

  const copyToClipboard = (text: string, sectionId: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSection(sectionId);
    setTimeout(() => setCopiedSection(null), 2000);
  };

  const SCREENS_INFO: {
    id: ScreenId;
    name: string;
    description: string;
    step: string;
    highlight: string;
  }[] = [
    {
      id: "splash",
      name: "1. Splash Screen",
      step: "Onboarding",
      description: "Official SIH 2026 branding, problem code SIH26002, and quick launch triggers.",
      highlight: "Auto-transition & hackathon metadata",
    },
    {
      id: "login",
      name: "2. Login Screen",
      step: "Auth & RBAC",
      description: "Role-based authentication supporting Citizen, Commercial Driver, Logistics Fleet, Authority, Emergency Response.",
      highlight: "1-Click test credentials for judges",
    },
    {
      id: "register",
      name: "3. Registration Screen",
      step: "Onboarding",
      description: "Driver vehicle registration, freight cargo declaration, and emergency transit passes.",
      highlight: "Corridor preference selection",
    },
    {
      id: "home",
      name: "4. Home Dashboard",
      step: "Core Hub",
      description: "Live hazard ticker, active alerts, road status KPIs, quick incident submission, and crowd verification.",
      highlight: "Personalized driver/citizen view",
    },
    {
      id: "book_transport",
      name: "4b. Book Transport & Logistics",
      step: "Smart Logistics",
      description: "Disaster-aware booking for relief vehicle types (Bike, Mini Truck, Truck) with hazard risk assessment & detours.",
      highlight: "Distance + Risk + Road Accessibility + detours",
    },
    {
      id: "booking_confirmation",
      name: "4c. Booking Confirmation",
      step: "Smart Logistics",
      description: "Pre-booking review with corridor safety check, route comparison, detour fee breakdown, and SOS Green Corridor toggle.",
      highlight: "AI safety verification & transparent pricing",
    },
    {
      id: "booking_tracking",
      name: "4d. Live Transport Tracking",
      step: "Smart Logistics",
      description: "Real-time Leaflet tracking showing driver telemetry, route hazard alerts, dynamically rerouting with live ETA.",
      highlight: "In-transit hazard alerts & speed warnings",
    },
    {
      id: "driver_dashboard",
      name: "4e. Driver Logistics Portal",
      step: "Smart Logistics",
      description: "Haulier and driver mission control: accept emergency jobs, view route risk rating, bypass flooded roads, and confirm delivery.",
      highlight: "Green Corridor priority & earnings breakdown",
    },
    {
      id: "report",
      name: "5. Incident Reporting",
      step: "Workflow Step 1",
      description: "Camera capture, automated GPS geotagging, manual landmark entry, and instant hazard categorization.",
      highlight: "1-Click disaster scenario presets",
    },
    {
      id: "voice_report",
      name: "6. Voice Reporting Screen",
      step: "Workflow Step 1",
      description: "Hands-free speech-to-text reporting for drivers on treacherous roads via Web Speech API.",
      highlight: "English, Hindi, Tamil, Bengali support",
    },
    {
      id: "ai_analysis",
      name: "7. AI Analysis (Gemini Vision)",
      step: "Workflow Step 2",
      description: "Server-side multimodal Gemini 3.8 Flash visual scanner calculating 0-100 risk score, severity, clearance ETA.",
      highlight: "Real-time AI diagnostic HUD",
    },
    {
      id: "incident_details",
      name: "8. Incident Details",
      step: "Investigation",
      description: "Geotagged map location, high-res damage imagery, crowd confidence meter, and dispatch timeline.",
      highlight: "Emergency priority escalation",
    },
    {
      id: "crowd_verify",
      name: "9. Crowd Verification",
      step: "Workflow Step 3",
      description: "Geofenced citizen and driver consensus voting (Confirm/Reject) preventing hoax and duplicate reports.",
      highlight: "Dynamic confidence percentage",
    },
    {
      id: "live_map",
      name: "10. Live Incident Map",
      step: "GIS Mapping",
      description: "Interactive Leaflet GIS map with color-coded hazard pins, active danger zones, and corridor overlays.",
      highlight: "Pulsing high-risk markers",
    },
    {
      id: "smart_route",
      name: "11. Smart Route Screen",
      step: "Workflow Step 4",
      description: "AI-driven route optimization comparing Route A (high risk 82%) vs. Route B (low risk 21% bypass).",
      highlight: "Green corridor clearance toggle",
    },
    {
      id: "alerts",
      name: "12. Alerts Screen",
      step: "Workflow Step 6",
      description: "Authority-broadcasted push advisories categorized by Red, Amber, and Yellow risk tiers with sound alarm.",
      highlight: "Direct driver action instructions",
    },
    {
      id: "emergency",
      name: "13. Emergency Requests",
      step: "Workflow Step 7",
      description: "Priority corridor management for ambulances, disaster relief cargo, and medical oxygen supply.",
      highlight: "Live status & ETA monitor",
    },
    {
      id: "authority_dashboard",
      name: "14. Authority Dashboard",
      step: "Workflow Step 5",
      description: "Comprehensive NDRF / SDMA command center with 8 analytical modules: total, high/med/low risks, and GIS feeds.",
      highlight: "Complete SIH mandated breakdown",
    },
    {
      id: "incident_mgmt",
      name: "15. Incident Management",
      step: "Authority Triage",
      description: "Triage board, field team deployment (BRO, SDRF, NHAI), and priority status updates.",
      highlight: "Actionable operational dispatch",
    },
    {
      id: "resolution_tracking",
      name: "16. Resolution Tracking",
      step: "Lifecycle Tracking",
      description: "5-stage progress tracker from Initial Report → Verification → Team Dispatched → Work In Progress → Resolved.",
      highlight: "Milestone timestamp updates",
    },
    {
      id: "profile",
      name: "17. User Profile & Offline Sync",
      step: "Workflow Step 8",
      description: "Offline encrypted storage queue, background sync worker, user trust karma badges, and technical specs.",
      highlight: "Zero-connectivity resilience",
    },
  ];

  return (
    <div className="w-full max-w-6xl mx-auto p-4 sm:p-8 space-y-8 vrq-card shadow-2xl">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-800/80">
        <div>
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#2563EB] via-[#1D4ED8] to-[#06B6D4] flex items-center justify-center text-white shadow-xl shadow-[#2563EB]/30 border border-[#06B6D4]/30">
              <Award className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                  SIH 2026 Deliverables Hub
                </h1>
                <span className="px-3 py-1 bg-[#2563EB]/20 text-[#06B6D4] border border-[#06B6D4]/30 rounded-full text-xs font-bold">
                  Problem Code: SIH26002
                </span>
              </div>
              <p className="text-sm text-slate-400 mt-1">
                Smart Logistics & Disaster Response Management Platform • Complete Solution Architecture
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              onViewModeChange("mobile");
              onNavigate("home");
            }}
            className="flex items-center gap-2 px-4 py-2.5 vrq-btn-primary text-white rounded-xl text-xs font-bold transition"
          >
            <Smartphone className="w-4 h-4" />
            <span>Open Mobile App View</span>
          </button>
          <button
            onClick={() => {
              onViewModeChange("fullscreen");
              onNavigate("authority_dashboard");
            }}
            className="flex items-center gap-2 px-4 py-2.5 vrq-card-subtle hover:border-[#06B6D4]/40 text-slate-200 rounded-xl text-xs font-semibold transition vrq-press"
          >
            <Maximize2 className="w-4 h-4 text-[#06B6D4]" />
            <span>Open Command Screen</span>
          </button>
        </div>
      </div>

      {/* 8-Step Core Workflow Architecture Cards */}
      <div className="space-y-4">
        <h2 className="text-lg font-bold text-white flex items-center gap-2">
          <Zap className="w-5 h-5 text-[#06B6D4]" />
          <span>Complete 8-Step Workflow Implementation</span>
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            {
              step: "Step 1",
              title: "Reporting & Voice Input",
              desc: "Photo capture + auto-locked GPS coordinates + Web Speech API in 4 Indian languages.",
              screenId: "report" as ScreenId,
              icon: AlertTriangle,
              color: "text-[#F59E0B]",
            },
            {
              step: "Step 2",
              title: "Gemini Vision AI",
              desc: "Server-side multimodal vision scanner assessing damage, risk score, & clearance ETA.",
              screenId: "ai_analysis" as ScreenId,
              icon: Cpu,
              color: "text-[#06B6D4]",
            },
            {
              step: "Step 3",
              title: "Crowd Verification",
              desc: "Consensus-based voting engine computing verification score before elevating to state.",
              screenId: "crowd_verify" as ScreenId,
              icon: Activity,
              color: "text-[#2563EB]",
            },
            {
              step: "Step 4",
              title: "Smart Route Optimization",
              desc: "Real-time risk rating (Route A 82% vs Route B 21% safe bypass) with turn-by-turn alerts.",
              screenId: "smart_route" as ScreenId,
              icon: Route,
              color: "text-[#10B981]",
            },
            {
              step: "Step 5",
              title: "Authority Command Center",
              desc: "NDRF / SDMA command hub with 8 KPI modules, risk distributions, & triage tables.",
              screenId: "authority_dashboard" as ScreenId,
              icon: ShieldAlert,
              color: "text-[#EF4444]",
            },
            {
              step: "Step 6",
              title: "Alerts & Audio Broadcast",
              desc: "Multi-tier emergency advisories (Red/Amber/Yellow) with audio sirens and driver directives.",
              screenId: "alerts" as ScreenId,
              icon: Radio,
              color: "text-[#F59E0B]",
            },
            {
              step: "Step 7",
              title: "Green Corridor Mode",
              desc: "Priority routing for ambulances, medical cargo, and disaster relief transit convoys.",
              screenId: "emergency" as ScreenId,
              icon: Ambulance,
              color: "text-[#EF4444]",
            },
            {
              step: "Step 8",
              title: "Offline Storage & Sync",
              desc: "Encrypted local queue for no-connectivity mountain zones with auto cloud sync.",
              screenId: "profile" as ScreenId,
              icon: WifiOff,
              color: "text-[#06B6D4]",
            },
          ].map((item, idx) => {
            const Icon = item.icon;
            return (
              <div
                key={idx}
                className="vrq-card-subtle p-4 hover:border-[#06B6D4]/40 transition flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] font-extrabold uppercase tracking-wider px-2 py-0.5 rounded bg-[#2563EB]/20 text-[#06B6D4] border border-[#2563EB]/30">
                      {item.step}
                    </span>
                    <Icon className={`w-4 h-4 ${item.color}`} />
                  </div>
                  <h3 className="font-bold text-sm text-white">{item.title}</h3>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed">{item.desc}</p>
                </div>
                <button
                  onClick={() => {
                    onViewModeChange("mobile");
                    onNavigate(item.screenId);
                  }}
                  className="mt-3 flex items-center justify-between text-xs font-semibold text-[#06B6D4] hover:text-cyan-300 pt-2 border-t border-slate-800/80 transition"
                >
                  <span>Test in App</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Screen Checklist & Interactive Tester */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <Layers className="w-5 h-5 text-[#06B6D4]" />
            <span>All 17 Required SIH Screens (Interactive Matrix)</span>
          </h2>
          <span className="text-xs font-bold text-[#10B981] bg-[#10B981]/15 border border-[#10B981]/30 px-3 py-1 rounded-full">
            100% Implemented & Verified
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {SCREENS_INFO.map((scr) => (
            <div
              key={scr.id}
              className="p-4 vrq-card-subtle hover:border-[#06B6D4]/40 transition flex flex-col justify-between group"
            >
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="font-bold text-xs text-white group-hover:text-[#06B6D4] transition">
                    {scr.name}
                  </span>
                  <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-slate-800/80 text-slate-400">
                    {scr.step}
                  </span>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">{scr.description}</p>
                <div className="mt-2 text-[11px] text-[#06B6D4] font-semibold">
                  ★ {scr.highlight}
                </div>
              </div>

              <div className="flex items-center gap-2 mt-3 pt-2.5 border-t border-slate-800/80">
                <button
                  onClick={() => {
                    onViewModeChange("mobile");
                    onNavigate(scr.id);
                  }}
                  className="flex-1 py-1.5 px-2 bg-slate-800/90 hover:bg-slate-700 text-slate-200 rounded-lg text-[11px] font-semibold transition text-center vrq-press"
                >
                  Mobile View
                </button>
                <button
                  onClick={() => {
                    onViewModeChange("fullscreen");
                    onNavigate(scr.id);
                  }}
                  className="flex-1 py-1.5 px-2 vrq-btn-primary text-white rounded-lg text-[11px] font-semibold transition text-center"
                >
                  Full Screen
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Backend API & Data Architecture Specification */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* API Specification */}
        <div className="vrq-card-subtle p-4 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <FileCode2 className="w-4 h-4 text-[#10B981]" />
              <span>Server-Side REST & AI Vision API</span>
            </h3>
            <button
              onClick={() =>
                copyToClipboard(
                  `POST /api/gemini/analyze-incident\nContent-Type: application/json\n\n{\n  "imageBase64": "data:image/jpeg;base64,...",\n  "userDescription": "Massive rockfall on NH-58",\n  "locationName": "Devprayag, Uttarakhand",\n  "lat": 30.1459,\n  "lng": 78.5989\n}`,
                  "api"
                )
              }
              className="text-xs text-slate-400 hover:text-white flex items-center gap-1"
            >
              {copiedSection === "api" ? (
                <>
                  <Check className="w-3.5 h-3.5 text-[#10B981]" />
                  <span className="text-[#10B981]">Copied</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy cURL</span>
                </>
              )}
            </button>
          </div>

          <div className="bg-[#050816]/80 rounded-xl p-3 text-xs font-mono text-slate-300 border border-slate-800 overflow-x-auto space-y-2">
            <div className="text-[#10B981] font-bold">POST /api/gemini/analyze-incident</div>
            <p className="text-slate-400 text-[11px] font-sans">
              Takes multimodal photo evidence + geotag coordinates. Proxies Gemini 3.8 Flash to return structured hazard assessments.
            </p>
            <div className="text-slate-500 pt-1 border-t border-slate-800">
              Response: {`{ incidentType, summary, severity, riskScore, recommendedAction, estimatedClearanceHours, greenCorridorViability }`}
            </div>
          </div>
        </div>

        {/* Database Schemas */}
        <div className="vrq-card-subtle p-4 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Database className="w-4 h-4 text-[#06B6D4]" />
              <span>Core Firestore & Local Storage Schemas</span>
            </h3>
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="p-3 rounded-xl bg-[#050816]/80 border border-slate-800">
              <span className="font-bold text-[#06B6D4] block mb-1">incidents Collection</span>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                Stores title, GPS lat/lng, AI diagnostic telemetry, crowd verification tallies, and full milestone resolution timeline.
              </p>
            </div>
            <div className="p-3 rounded-xl bg-[#050816]/80 border border-slate-800">
              <span className="font-bold text-[#2563EB] block mb-1">offlineQueue Cache</span>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                Stores local incident drafts with base64 images when offline. Auto-synced in batches once network returns.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
