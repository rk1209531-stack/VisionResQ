import React, { useState } from "react";
import { ScreenId, TransportBooking, BookingStatus } from "../../types";
import {
  Truck,
  Phone,
  Shield,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Clock,
  MapPin,
  Navigation,
  Sparkles,
  AlertOctagon,
  Play,
  RotateCcw,
  Power,
  ChevronRight,
  Package,
} from "lucide-react";

interface DriverDashboardScreenProps {
  bookings: TransportBooking[];
  onNavigate: (screen: ScreenId) => void;
  onUpdateBookingStatus: (bookingId: string, status: BookingStatus, progressPercent?: number) => void;
  onSelectBookingForTracking: (booking: TransportBooking) => void;
}

export const DriverDashboardScreen: React.FC<DriverDashboardScreenProps> = ({
  bookings,
  onNavigate,
  onUpdateBookingStatus,
  onSelectBookingForTracking,
}) => {
  const [isDriverOnline, setIsDriverOnline] = useState<boolean>(true);
  const [activeDriverTab, setActiveDriverTab] = useState<"pending" | "active" | "history">("active");

  const pendingBookings = bookings.filter((b) => b.status === "Searching");
  const activeBookings = bookings.filter(
    (b) =>
      b.status === "Accepted" ||
      b.status === "Driver Assigned" ||
      b.status === "On the Way" ||
      b.status === "Arrived" ||
      b.status === "Trip Started"
  );
  const completedBookings = bookings.filter((b) => b.status === "Completed");

  return (
    <div className="p-4 space-y-4 pb-12 text-slate-100">
      {/* Driver Profile & Status Header */}
      <div className="vrq-card p-4 bg-gradient-to-r from-[#2563EB]/20 via-[#050816]/90 to-[#06B6D4]/20 border-[#06B6D4]/30">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-[#2563EB]/25 border border-[#06B6D4]/40 text-[#06B6D4] flex items-center justify-center text-xl shadow-lg">
              🚚
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-extrabold text-white">Vikramjit Singh</span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#F59E0B]/20 text-[#F59E0B] border border-[#F59E0B]/30">
                  4.9★
                </span>
              </div>
              <span className="text-[11px] text-slate-300 block font-mono">
                Tata Ace Gold • JK-02-CD-4188
              </span>
              <span className="text-[9px] text-[#10B981] font-semibold flex items-center gap-1 mt-0.5">
                <Shield className="w-3 h-3 text-[#10B981]" />
                NDRF / SDRF Disaster Logistics Fleet
              </span>
            </div>
          </div>

          {/* Online Toggle */}
          <button
            onClick={() => setIsDriverOnline(!isDriverOnline)}
            className={`p-2.5 rounded-2xl flex flex-col items-center gap-1 transition border vrq-btn-press cursor-pointer ${
              isDriverOnline
                ? "bg-[#10B981]/15 text-[#10B981] border-[#10B981]/40 shadow-[0_6px_18px_rgba(16,185,129,0.2)]"
                : "bg-[#050816] text-slate-500 border-white/10"
            }`}
          >
            <Power className="w-4 h-4" />
            <span className="text-[9px] font-black uppercase">
              {isDriverOnline ? "Online" : "Offline"}
            </span>
          </button>
        </div>

        {/* Quick Driver Stats */}
        <div className="grid grid-cols-3 gap-2.5 mt-3.5 pt-3 border-t border-white/[0.08] text-center text-xs">
          <div className="bg-[#050816]/85 p-2.5 rounded-xl border border-white/[0.06]">
            <span className="text-[9px] text-slate-400 block">Today&apos;s Trips</span>
            <span className="text-sm font-black text-white">3 Trips</span>
          </div>
          <div className="bg-[#050816]/85 p-2.5 rounded-xl border border-white/[0.06]">
            <span className="text-[9px] text-slate-400 block">Relief Cargo</span>
            <span className="text-sm font-black text-[#06B6D4]">4.2 Tons</span>
          </div>
          <div className="bg-[#050816]/85 p-2.5 rounded-xl border border-white/[0.06]">
            <span className="text-[9px] text-slate-400 block">Earnings / Honorarium</span>
            <span className="text-sm font-black text-[#10B981]">₹9,450</span>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex rounded-2xl bg-[#050816]/90 p-1.5 border border-white/[0.08] text-xs">
        <button
          onClick={() => setActiveDriverTab("active")}
          className={`flex-1 py-2 rounded-xl font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
            activeDriverTab === "active"
              ? "bg-gradient-to-r from-[#2563EB] to-[#1D4ED8] text-white shadow-[0_4px_14px_rgba(37,99,235,0.4)]"
              : "text-slate-400 hover:text-white"
          }`}
        >
          <span>Active Mission</span>
          {activeBookings.length > 0 && (
            <span className="px-1.5 py-0.2 rounded-full text-[9px] bg-white/20">
              {activeBookings.length}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveDriverTab("pending")}
          className={`flex-1 py-2 rounded-xl font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
            activeDriverTab === "pending"
              ? "bg-gradient-to-r from-[#2563EB] to-[#1D4ED8] text-white shadow-[0_4px_14px_rgba(37,99,235,0.4)]"
              : "text-slate-400 hover:text-white"
          }`}
        >
          <span>New Requests</span>
          {pendingBookings.length > 0 && (
            <span className="px-1.5 py-0.2 rounded-full text-[9px] bg-[#EF4444] text-white font-black animate-pulse">
              {pendingBookings.length}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveDriverTab("history")}
          className={`flex-1 py-2 rounded-xl font-bold transition cursor-pointer ${
            activeDriverTab === "history"
              ? "bg-gradient-to-r from-[#2563EB] to-[#1D4ED8] text-white shadow-[0_4px_14px_rgba(37,99,235,0.4)]"
              : "text-slate-400 hover:text-white"
          }`}
        >
          Completed ({completedBookings.length})
        </button>
      </div>

      {/* PENDING REQUESTS TAB */}
      {activeDriverTab === "pending" && (
        <div className="space-y-3">
          {pendingBookings.length === 0 ? (
            <div className="vrq-card p-6 text-center text-xs text-slate-400 space-y-2.5">
              <Truck className="w-8 h-8 text-slate-500 mx-auto" />
              <p>No new incoming booking requests at this moment.</p>
              <button
                onClick={() => onNavigate("book_transport")}
                className="px-3.5 py-2 rounded-xl bg-[#2563EB]/20 hover:bg-[#2563EB]/30 text-[#06B6D4] border border-[#06B6D4]/30 text-xs font-bold cursor-pointer"
              >
                Create a Request from Citizen View
              </button>
            </div>
          ) : (
            pendingBookings.map((b) => (
              <div
                key={b.bookingId}
                className="vrq-card p-4 space-y-3"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono font-bold px-2.5 py-0.5 rounded-lg bg-[#050816] text-slate-300 border border-white/[0.08]">
                    {b.bookingId}
                  </span>
                  {b.isEmergency ? (
                    <span className="text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full bg-[#EF4444] text-white flex items-center gap-1">
                      <AlertOctagon className="w-3 h-3" /> EMERGENCY RELIEF
                    </span>
                  ) : (
                    <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-[#2563EB]/20 text-[#06B6D4] border border-[#06B6D4]/30">
                      {b.purpose}
                    </span>
                  )}
                </div>

                <div className="space-y-1.5 text-xs">
                  <div className="flex items-center gap-2">
                    <MapPin className="w-3.5 h-3.5 text-[#10B981] flex-shrink-0" />
                    <span><strong>Pickup:</strong> {b.pickupLocation.name}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="w-3.5 h-3.5 text-[#06B6D4] flex-shrink-0" />
                    <span><strong>Destination:</strong> {b.destinationLocation.name}</span>
                  </div>
                  <div className="flex items-center justify-between pt-2 text-[11px] text-slate-400">
                    <span>Distance: {b.distanceKm} km</span>
                    <span>Route: {b.selectedRoute} (Risk: {b.routeDetails.riskScore}/100)</span>
                  </div>
                </div>

                {/* Estimated Fare & Accept / Reject Actions */}
                <div className="pt-2.5 border-t border-white/[0.08] flex items-center justify-between">
                  <div>
                    <span className="text-[9px] text-slate-400 uppercase font-bold block">Fare</span>
                    <span className="text-lg font-black font-mono text-[#10B981]">
                      ₹{b.fareBreakdown.totalEstimatedFare.toLocaleString("en-IN")}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onUpdateBookingStatus(b.bookingId, "Cancelled")}
                      className="px-3 py-2 rounded-xl bg-[#050816] hover:bg-white/[0.08] border border-white/10 text-slate-300 text-xs font-bold transition flex items-center gap-1 cursor-pointer"
                    >
                      <XCircle className="w-3.5 h-3.5" />
                      <span>Decline</span>
                    </button>

                    <button
                      onClick={() => {
                        onUpdateBookingStatus(b.bookingId, "Accepted", 10);
                        onSelectBookingForTracking(b);
                        setActiveDriverTab("active");
                      }}
                      className="px-4 py-2 rounded-xl bg-[#10B981] hover:bg-emerald-500 text-white text-xs font-black transition flex items-center gap-1.5 shadow-[0_6px_18px_rgba(16,185,129,0.35)] vrq-btn-press cursor-pointer"
                    >
                      <CheckCircle className="w-3.5 h-3.5" />
                      <span>Accept Mission</span>
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* ACTIVE MISSIONS TAB */}
      {activeDriverTab === "active" && (
        <div className="space-y-3">
          {activeBookings.length === 0 ? (
            <div className="vrq-card p-6 text-center text-xs text-slate-400 space-y-2.5">
              <p>No active transport mission assigned.</p>
              <button
                onClick={() => setActiveDriverTab("pending")}
                className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-[#2563EB] to-[#06B6D4] text-white text-xs font-bold cursor-pointer"
              >
                Check Incoming Requests
              </button>
            </div>
          ) : (
            activeBookings.map((b) => (
              <div
                key={b.bookingId}
                className="vrq-card p-4 space-y-3.5"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-mono font-bold px-2.5 py-0.5 rounded-lg bg-[#050816] text-slate-300 border border-white/[0.08]">
                      {b.bookingId}
                    </span>
                    <span className="text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full bg-[#2563EB]/20 text-[#06B6D4] border border-[#06B6D4]/30">
                      Status: {b.status}
                    </span>
                  </div>

                  <button
                    onClick={() => {
                      onSelectBookingForTracking(b);
                      onNavigate("booking_tracking");
                    }}
                    className="text-[10px] font-bold text-[#06B6D4] hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    <span>Full Live Map ↗</span>
                  </button>
                </div>

                {/* Corridor & Details */}
                <div className="space-y-1.5 text-xs">
                  <div className="flex items-center gap-2">
                    <MapPin className="w-3.5 h-3.5 text-[#10B981] flex-shrink-0" />
                    <span><strong>From:</strong> {b.pickupLocation.name}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <MapPin className="w-3.5 h-3.5 text-[#06B6D4] flex-shrink-0" />
                    <span><strong>To:</strong> {b.destinationLocation.name}</span>
                  </div>
                  <div className="flex items-center justify-between text-slate-400 text-[11px] pt-1">
                    <span>{b.selectedRoute} ({b.distanceKm} km)</span>
                    <span className="text-[#10B981] font-bold">Risk: {b.routeDetails.riskScore}/100</span>
                  </div>
                </div>

                {/* Package Info */}
                {b.packageInfo?.description && (
                  <div className="bg-[#050816]/85 p-2.5 rounded-xl border border-white/[0.08] text-xs">
                    <span className="text-[10px] text-slate-400 font-bold block">Cargo Manifest:</span>
                    <span className="text-slate-200 text-[11px]">{b.packageInfo.description}</span>
                  </div>
                )}

                {/* Driver Fast-Action Stepper */}
                <div className="pt-2.5 border-t border-white/[0.08] space-y-2">
                  <span className="text-[10px] font-bold text-slate-400 uppercase block">
                    Emergency Mission Dispatch Controls:
                  </span>
                  <div className="grid grid-cols-3 gap-2 text-xs">
                    <button
                      onClick={() => onUpdateBookingStatus(b.bookingId, "Arrived", 25)}
                      className={`py-2 px-1.5 rounded-xl border text-[10px] font-bold transition text-center cursor-pointer ${
                        b.status === "Arrived"
                          ? "bg-[#F59E0B] text-white border-amber-400"
                          : "bg-[#050816]/85 hover:bg-white/[0.06] text-slate-300 border-white/[0.08]"
                      }`}
                    >
                      1. Arrived Pickup
                    </button>

                    <button
                      onClick={() => onUpdateBookingStatus(b.bookingId, "Trip Started", 55)}
                      className={`py-2 px-1.5 rounded-xl border text-[10px] font-bold transition text-center cursor-pointer ${
                        b.status === "Trip Started"
                          ? "bg-[#2563EB] text-white border-[#06B6D4]"
                          : "bg-[#050816]/85 hover:bg-white/[0.06] text-slate-300 border-white/[0.08]"
                      }`}
                    >
                      2. Start Trip
                    </button>

                    <button
                      onClick={() => onUpdateBookingStatus(b.bookingId, "Completed", 100)}
                      className={`py-2 px-1.5 rounded-xl border text-[10px] font-bold transition text-center cursor-pointer ${
                        b.status === "Completed"
                          ? "bg-[#10B981] text-white border-emerald-400"
                          : "bg-[#050816]/85 hover:bg-white/[0.06] text-[#10B981] border-white/[0.08]"
                      }`}
                    >
                      3. Complete ✓
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* COMPLETED TAB */}
      {activeDriverTab === "history" && (
        <div className="space-y-3">
          {completedBookings.length === 0 ? (
            <div className="vrq-card p-6 text-center text-xs text-slate-400">
              No completed trips in current session.
            </div>
          ) : (
            completedBookings.map((b) => (
              <div
                key={b.bookingId}
                className="vrq-card p-4 space-y-2 text-xs"
              >
                <div className="flex items-center justify-between">
                  <span className="font-mono font-bold text-slate-300">{b.bookingId}</span>
                  <span className="text-[10px] font-bold text-[#10B981] bg-[#10B981]/15 px-2.5 py-0.5 rounded-full border border-[#10B981]/30">
                    Delivered & Verified ✓
                  </span>
                </div>
                <div className="text-slate-200 font-semibold">
                  {b.pickupLocation.name} → {b.destinationLocation.name}
                </div>
                <div className="flex items-center justify-between text-slate-400 text-[11px] pt-2 border-t border-white/[0.08]">
                  <span>Fare: <strong className="text-[#10B981] font-mono">₹{b.fareBreakdown.totalEstimatedFare.toLocaleString("en-IN")}</strong></span>
                  <span>Vehicle: {b.vehicleType}</span>
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
};
