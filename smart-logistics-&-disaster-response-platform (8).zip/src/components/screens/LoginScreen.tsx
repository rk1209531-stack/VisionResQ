import React, { useState } from "react";
import { UserRole, ScreenId } from "../../types";
import { ShieldAlert, KeyRound, Phone, ArrowRight, CheckCircle, ShieldCheck } from "lucide-react";

interface LoginScreenProps {
  currentRole: UserRole;
  onRoleChange: (role: UserRole) => void;
  onNavigate: (screen: ScreenId) => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({
  currentRole,
  onRoleChange,
  onNavigate,
}) => {
  const [phoneNumber, setPhoneNumber] = useState("+91 98765 43210");
  const [otpSent, setOtpSent] = useState(false);
  const [otp, setOtp] = useState("");

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!otpSent) {
      setOtpSent(true);
      setOtp("26002"); // Easy SIH OTP
    } else {
      // Completed login
      onNavigate(currentRole === "authority" ? "authority_dashboard" : "home");
    }
  };

  const handleQuickDemoFill = (role: UserRole, phone: string) => {
    onRoleChange(role);
    setPhoneNumber(phone);
    setOtpSent(true);
    setOtp("26002");
  };

  return (
    <div className="p-4 flex flex-col justify-between min-h-[580px]">
      <div className="space-y-4">
        <div className="vrq-card p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#2563EB]/20 text-[#06B6D4] border border-[#06B6D4]/30 flex items-center justify-center">
            <ShieldAlert className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-extrabold text-white tracking-tight">Sign In to Platform</h2>
            <p className="text-[11px] text-slate-400">Firebase Auth & Role Access (SIH26002)</p>
          </div>
        </div>

        {/* Role Selector Tabs */}
        <div className="vrq-card p-4 space-y-3">
          <div>
            <label className="text-[11px] font-bold uppercase tracking-wider text-slate-300 block mb-2">
              Select Your Role
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 bg-[#050816]/80 p-1 rounded-xl border border-slate-800/80 text-[11px]">
              {(
                [
                  { id: "citizen", label: "Citizen" },
                  { id: "driver", label: "Driver" },
                  { id: "authority", label: "Authority" },
                  { id: "emergency", label: "Emergency" },
                ] as const
              ).map((r) => (
                <button
                  key={r.id}
                  type="button"
                  onClick={() => onRoleChange(r.id)}
                  className={`py-2 px-2 rounded-lg font-medium transition text-center capitalize vrq-press ${
                    currentRole === r.id
                      ? "bg-gradient-to-r from-[#2563EB] to-[#06B6D4] text-white font-bold shadow-md"
                      : "text-slate-400 hover:text-white"
                  }`}
                >
                  {r.label}
                </button>
              ))}
            </div>
          </div>

          {/* Form */}
          <form onSubmit={handleLogin} className="space-y-3 pt-1">
            <div>
              <label className="text-[11px] font-semibold text-slate-400 block mb-1.5">Mobile Number</label>
              <div className="relative">
                <Phone className="w-4 h-4 text-[#06B6D4] absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  placeholder="+91 98765 43210"
                  className="w-full bg-[#050816]/80 border border-slate-800 rounded-xl py-2.5 pl-9 pr-3 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-[#06B6D4]"
                  required
                />
              </div>
            </div>

            {otpSent && (
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-[11px] font-semibold text-slate-400">Enter OTP</label>
                  <span className="text-[10px] text-[#10B981] font-bold">Auto-filled: 26002</span>
                </div>
                <div className="relative">
                  <KeyRound className="w-4 h-4 text-[#06B6D4] absolute left-3 top-2.5" />
                  <input
                    type="text"
                    value={otp}
                    onChange={(e) => setOtp(e.target.value)}
                    placeholder="26002"
                    className="w-full bg-[#050816]/80 border border-slate-800 rounded-xl py-2.5 pl-9 pr-3 text-xs text-white placeholder-slate-600 tracking-widest font-mono focus:outline-none focus:border-[#06B6D4]"
                    required
                  />
                </div>
              </div>
            )}

            <button
              type="submit"
              className="w-full py-3 vrq-btn-primary text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition mt-2"
            >
              <span>{otpSent ? "Verify & Enter" : "Send OTP Verification"}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </form>
        </div>

        {/* Pre-configured Responder Accounts */}
        <div className="vrq-card p-4 text-[11px]">
          <div className="flex items-center gap-1.5 text-slate-200 font-bold mb-2.5">
            <ShieldCheck className="w-4 h-4 text-[#06B6D4]" />
            <span>Verified Responder Test Credentials</span>
          </div>
          <div className="space-y-2 text-slate-400">
            <button
              onClick={() => handleQuickDemoFill("authority", "+91 94190 12345")}
              className="w-full text-left p-2 rounded-xl vrq-card-subtle hover:border-[#06B6D4]/40 text-slate-300 flex items-center justify-between transition vrq-press"
            >
              <span>NDRF / Authority Official</span>
              <span className="text-[#06B6D4] font-mono text-[10px] font-bold">Fill →</span>
            </button>
            <button
              onClick={() => handleQuickDemoFill("driver", "+91 98112 33445")}
              className="w-full text-left p-2 rounded-xl vrq-card-subtle hover:border-[#06B6D4]/40 text-slate-300 flex items-center justify-between transition vrq-press"
            >
              <span>Relief Haulier / Driver</span>
              <span className="text-[#06B6D4] font-mono text-[10px] font-bold">Fill →</span>
            </button>
            <button
              onClick={() => handleQuickDemoFill("citizen", "+91 98765 43210")}
              className="w-full text-left p-2 rounded-xl vrq-card-subtle hover:border-[#06B6D4]/40 text-slate-300 flex items-center justify-between transition vrq-press"
            >
              <span>Citizen Reporter</span>
              <span className="text-[#06B6D4] font-mono text-[10px] font-bold">Fill →</span>
            </button>
          </div>
        </div>
      </div>

      <div className="text-center pt-4 border-t border-slate-800/80 text-xs text-slate-400">
        Don't have an account?{" "}
        <button
          onClick={() => onNavigate("register")}
          className="text-[#06B6D4] font-bold hover:underline"
        >
          Register here
        </button>
      </div>
    </div>
  );
};
