import React, { useEffect, useState } from "react";
import { ScreenId, TransportBooking, BookingStatus } from "../../types";
import { INITIAL_INCIDENTS } from "../../mockData";
import { DisasterInteractiveMap } from "../map/DisasterInteractiveMap";
import {
  Truck,
  Phone,
  Shield,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Navigation,
  Play,
  Pause,
  RotateCcw,
  Sparkles,
  AlertOctagon,
  MapPin,
  ExternalLink,
  ChevronRight,
  Radio,
} from "lucide-react";

interface BookingTrackingScreenProps {
  booking: TransportBooking | null;
  onNavigate: (screen: ScreenId) => void;
  onUpdateBookingStatus: (bookingId: string, status: BookingStatus, progressPercent?: number) => void;
}

const LIFECYCLE_STEPS: BookingStatus[] = [
  "Searching",
  "Accepted",
  "Driver Assigned",
  "On the Way",
  "Arrived",
  "Trip Started",
  "Completed",
];

export const BookingTrackingScreen: React.FC<BookingTrackingScreenProps> = ({
  booking,
  onNavigate,
  onUpdateBookingStatus,
}) => {
  const [isSimulating, setIsSimulating] = useState<boolean>(false);
  const [simulationSpeed, setSimulationSpeed] = useState<number>(1);
  const [currentProgress, setCurrentProgress] = useState<number>(booking?.driverProgressPercent ?? 20);
  const [activeHazardAlert, setActiveHazardAlert] = useState<string | null>(null);

  const currentStatus = booking?.status || "Trip Started";
  const rawCoords = booking?.routeDetails?.pathCoordinates || [
    [33.3765, 74.3103],
    [33.2800, 74.5800],
    [33.0800, 74.8300],
    [32.8500, 74.8900],
    [32.7266, 74.8570],
  ];
  const pathCoords: [number, number][] = rawCoords.map((pt: any) => {
    if (Array.isArray(pt) && pt.length >= 2) {
      return [Number(pt[0]), Number(pt[1])];
    }
    if (pt && typeof pt === "object" && "lat" in pt && "lng" in pt) {
      return [Number(pt.lat), Number(pt.lng)];
    }
    return [33.3765, 74.3103];
  });

  // Helper to interpolate along path coordinates
  const getInterpolatedPosition = (percent: number): [number, number] => {
    if (pathCoords.length === 0) return [33.3765, 74.3103];
    if (percent <= 0) return pathCoords[0];
    if (percent >= 100) return pathCoords[pathCoords.length - 1];

    const segmentCount = pathCoords.length - 1;
    const globalFraction = percent / 100;
    const scaledIndex = globalFraction * segmentCount;
    const segIndex = Math.min(Math.floor(scaledIndex), segmentCount - 1);
    const segFraction = scaledIndex - segIndex;

    const p1 = pathCoords[segIndex];
    const p2 = pathCoords[segIndex + 1];

    const lat = p1[0] + (p2[0] - p1[0]) * segFraction;
    const lng = p1[1] + (p2[1] - p1[1]) * segFraction;
    return [lat, lng];
  };

  const currentPos = getInterpolatedPosition(currentProgress);

  // Check hazard proximity
  useEffect(() => {
    if (currentProgress >= 35 && currentProgress <= 55) {
      setActiveHazardAlert("Entering safe bypass zone. NH-144A landslide gorge is 6 km to the east.");
    } else {
      setActiveHazardAlert(null);
    }
  }, [currentProgress]);

  // Simulation Loop
  useEffect(() => {
    let timer: NodeJS.Timeout | null = null;
    if (isSimulating) {
      timer = setInterval(() => {
        setCurrentProgress((prev) => {
          if (prev >= 100) {
            setIsSimulating(false);
            if (booking) {
              onUpdateBookingStatus(booking.bookingId, "Completed", 100);
            }
            return 100;
          }
          const next = Math.min(100, prev + 2 * simulationSpeed);
          if (next >= 100 && booking) {
            onUpdateBookingStatus(booking.bookingId, "Completed", 100);
          } else if (next > 10 && booking && booking.status === "Accepted") {
            onUpdateBookingStatus(booking.bookingId, "Trip Started", next);
          }
          return next;
        });
      }, 500);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [isSimulating, simulationSpeed, booking]);

  const currentStepIndex = LIFECYCLE_STEPS.indexOf(currentStatus);

  const handleNextStatus = () => {
    if (!booking) return;
    const nextIdx = Math.min(LIFECYCLE_STEPS.length - 1, currentStepIndex + 1);
    const newStatus = LIFECYCLE_STEPS[nextIdx];
    const newProg = Math.round((nextIdx / (LIFECYCLE_STEPS.length - 1)) * 100);
    setCurrentProgress(newProg);
    onUpdateBookingStatus(booking.bookingId, newStatus, newProg);
  };

  const remainingMinutes = booking
    ? Math.max(5, Math.round((booking.estimatedMinutes * (100 - currentProgress)) / 100))
    : 45;

  return (
    <div className="p-4 space-y-4 pb-12 text-slate-100">
      {/* Top Banner with Demo Simulation Label */}
      <div className="vrq-card p-4 flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2">
            <Radio className="w-4 h-4 text-[#10B981] animate-pulse" />
            <span className="text-xs font-extrabold text-white">Live Transport Telemetry</span>
          </div>
          <p className="text-[10px] text-slate-400 font-medium mt-0.5">
            Active Satellite GIS Corridor Tracking • Frequency 1 Hz
          </p>
        </div>
        <span className="text-[10px] font-mono font-bold px-2.5 py-0.5 rounded-full bg-[#10B981]/15 text-[#10B981] border border-[#10B981]/30">
          GPS Live
        </span>
      </div>

      {/* Emergency Corridor Banner */}
      {booking?.isEmergency && (
        <div className="vrq-card border-[#EF4444]/60 p-3 flex items-center justify-between text-xs shadow-[0_8px_24px_rgba(239,68,68,0.2)]">
          <div className="flex items-center gap-2.5">
            <AlertOctagon className="w-4 h-4 text-[#EF4444] animate-pulse" />
            <div>
              <span className="font-black text-red-300 block text-[11px]">
                Active Green Corridor: Priority Clearance
              </span>
              <span className="text-[9px] text-slate-300">
                Coordinated with Traffic Police & Emergency Response
              </span>
            </div>
          </div>
          <button
            onClick={() => onNavigate("emergency")}
            className="text-[10px] px-2.5 py-1 rounded-xl bg-[#EF4444] hover:bg-red-500 text-white font-bold vrq-btn-press cursor-pointer"
          >
            Escort Protocol
          </button>
        </div>
      )}

      {/* Interactive Map View */}
      <div className="relative rounded-2xl overflow-hidden border border-white/[0.1] shadow-[0_12px_32px_rgba(2,6,23,0.65)] bg-[#050816]">
        <DisasterInteractiveMap
          incidents={INITIAL_INCIDENTS}
          pickupLocation={booking?.pickupLocation ? { lat: booking.pickupLocation.lat, lng: booking.pickupLocation.lng, name: booking.pickupLocation.name } : undefined}
          destinationLocation={booking?.destinationLocation ? { lat: booking.destinationLocation.lat, lng: booking.destinationLocation.lng, name: booking.destinationLocation.name } : undefined}
          vehicleLocation={{
            lat: currentPos[0],
            lng: currentPos[1],
            label: `${booking?.vehicleType || "Relief Transport"} (GPS Live)`,
          }}
          routeAPath={pathCoords}
          userLocation={{ lat: currentPos[0], lng: currentPos[1] }}
          heightClass="h-72 sm:h-80"
        />

        {/* Live Floating Stats Overlay */}
        <div className="absolute top-3 left-3 z-[100] bg-[#050816]/90 backdrop-blur-md border border-white/[0.1] rounded-xl p-2.5 text-xs space-y-1 shadow-lg pointer-events-none">
          <div className="flex items-center gap-1.5 text-slate-300">
            <Clock className="w-3.5 h-3.5 text-[#F59E0B]" />
            <span>ETA: <strong className="text-white">{remainingMinutes} mins</strong></span>
          </div>
          <div className="flex items-center gap-1.5 text-slate-300">
            <Navigation className="w-3.5 h-3.5 text-[#06B6D4]" />
            <span>Distance Left: <strong className="text-white">{Math.round((booking?.distanceKm || 128) * (1 - currentProgress / 100))} km</strong></span>
          </div>
        </div>

        {/* Proximity Warning Pill if near landslide */}
        {activeHazardAlert && (
          <div className="absolute top-3 right-3 left-3 sm:left-auto z-[100] bg-[#050816]/95 backdrop-blur-md border border-[#F59E0B] rounded-xl p-2.5 text-[10px] text-amber-200 flex items-center gap-2 shadow-xl animate-pulse pointer-events-none">
            <AlertTriangle className="w-4 h-4 text-[#F59E0B] flex-shrink-0" />
            <span>{activeHazardAlert}</span>
          </div>
        )}

        {/* Simulation Playback Controls Overlay (bottom of map) */}
        <div className="absolute bottom-3 left-3 right-3 z-[100] bg-[#050816]/90 backdrop-blur-md border border-white/[0.1] rounded-2xl p-2.5 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsSimulating(!isSimulating)}
              className={`px-3.5 py-1.5 rounded-xl font-bold flex items-center gap-1.5 transition vrq-btn-press cursor-pointer ${
                isSimulating
                  ? "bg-[#F59E0B] text-white"
                  : "bg-[#10B981] hover:bg-emerald-500 text-white shadow-[0_4px_14px_rgba(16,185,129,0.35)]"
              }`}
            >
              {isSimulating ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
              <span>{isSimulating ? "Pause" : "Play Transit Sim"}</span>
            </button>

            <button
              onClick={() => {
                setCurrentProgress(0);
                setIsSimulating(false);
                if (booking) onUpdateBookingStatus(booking.bookingId, "Accepted", 0);
              }}
              className="p-2 rounded-xl bg-white/[0.06] hover:bg-white/[0.12] border border-white/[0.08] text-slate-300 cursor-pointer"
              title="Reset Simulation"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[10px] text-slate-300 font-mono font-bold">{currentProgress}%</span>
            <button
              onClick={handleNextStatus}
              className="px-2.5 py-1.5 rounded-xl bg-[#2563EB]/20 hover:bg-[#2563EB]/30 text-[#06B6D4] text-[10px] font-bold border border-[#06B6D4]/30 cursor-pointer"
            >
              Next Step ⏭
            </button>
          </div>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="space-y-1.5">
        <div className="flex justify-between text-[10px] text-slate-400 font-semibold">
          <span>Transit Progress:</span>
          <span className="text-white font-mono">{currentProgress}% Completed</span>
        </div>
        <div className="w-full h-2.5 bg-[#050816] border border-white/[0.08] rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-[#2563EB] via-[#06B6D4] to-[#10B981] transition-all duration-300"
            style={{ width: `${currentProgress}%` }}
          />
        </div>
      </div>

      {/* Lifecycle Status Stepper */}
      <div className="vrq-card p-4 space-y-2.5">
        <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
          Live Dispatch Lifecycle:
        </span>
        <div className="flex items-center justify-between text-[9px] overflow-x-auto pb-1">
          {LIFECYCLE_STEPS.map((step, idx) => {
            const isDone = idx <= currentStepIndex;
            const isCurrent = idx === currentStepIndex;
            return (
              <div key={step} className="flex flex-col items-center flex-1 min-w-[50px] text-center">
                <div
                  className={`w-6 h-6 rounded-full flex items-center justify-center text-[9px] font-bold mb-1 transition ${
                    isCurrent
                      ? "bg-[#2563EB] text-white ring-4 ring-[#06B6D4]/25"
                      : isDone
                      ? "bg-[#10B981] text-white"
                      : "bg-[#050816] border border-white/10 text-slate-500"
                  }`}
                >
                  {isDone ? "✓" : idx + 1}
                </div>
                <span
                  className={`text-[8px] leading-tight ${
                    isCurrent ? "font-black text-[#06B6D4]" : isDone ? "text-slate-300" : "text-slate-500"
                  }`}
                >
                  {step}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Driver / Logistics Provider Details Card */}
      <div className="vrq-card p-4 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-[#2563EB] to-[#06B6D4] text-white flex items-center justify-center text-lg shadow-[0_6px_18px_rgba(37,99,235,0.35)]">
              🚚
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-extrabold text-white">
                  {booking?.driverName || "Vikramjit Singh"}
                </span>
                <span className="text-[9px] px-2 py-0.5 rounded-full bg-[#F59E0B]/20 text-[#F59E0B] border border-[#F59E0B]/30 font-bold">
                  ★ {booking?.driverRating || 4.9}
                </span>
              </div>
              <span className="text-[10px] text-slate-400 block font-mono">
                {booking?.vehicleType || "Mini Truck"} • {booking?.vehicleNumber || "JK-02-CD-4188"}
              </span>
              <span className="text-[9px] text-[#10B981] font-semibold">
                Verified SDRF Civilian Fleet Partner
              </span>
            </div>
          </div>

          <a
            href={`tel:${booking?.driverPhone || "+919419177621"}`}
            className="w-10 h-10 rounded-xl bg-[#10B981] hover:bg-emerald-500 text-white flex items-center justify-center transition shadow-[0_4px_14px_rgba(16,185,129,0.35)]"
            title="Call Driver"
          >
            <Phone className="w-4 h-4" />
          </a>
        </div>

        {/* Route Details Breakdown */}
        <div className="pt-2.5 border-t border-white/[0.08] grid grid-cols-2 gap-2.5 text-xs">
          <div className="bg-[#050816]/85 p-2.5 rounded-xl border border-white/[0.08]">
            <span className="text-[9px] text-slate-400 uppercase font-bold block">Assigned Route</span>
            <span className="font-bold text-white text-[11px] block mt-0.5">
              {booking?.selectedRoute || "Route B"} (Safe Bypass)
            </span>
            <span className="text-[9px] text-[#10B981]">Risk: 22/100 (Low)</span>
          </div>

          <div className="bg-[#050816]/85 p-2.5 rounded-xl border border-white/[0.08]">
            <span className="text-[9px] text-slate-400 uppercase font-bold block">Estimated Fare</span>
            <span className="font-black font-mono text-[#10B981] text-[13px] block mt-0.5">
              ₹{booking?.fareBreakdown.totalEstimatedFare.toLocaleString("en-IN") || "4,750"}
            </span>
            <span className="text-[9px] text-slate-400">Fixed Rate Guarantee</span>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="grid grid-cols-2 gap-2.5 pt-1">
        <button
          onClick={() => onNavigate("driver_dashboard")}
          className="py-3 px-3 bg-[#0b132b]/80 hover:bg-white/[0.08] border border-white/[0.08] text-slate-200 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 vrq-btn-press cursor-pointer"
        >
          <span>Driver App View</span>
          <ChevronRight className="w-3.5 h-3.5" />
        </button>

        <button
          onClick={() => onNavigate("authority_dashboard")}
          className="py-3 px-3 bg-[#2563EB]/15 hover:bg-[#2563EB]/25 border border-[#06B6D4]/30 text-[#06B6D4] rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 vrq-btn-press cursor-pointer"
        >
          <Shield className="w-3.5 h-3.5" />
          <span>Authority Monitor</span>
        </button>
      </div>
    </div>
  );
};
