import { db } from "./index.ts";
import { users } from "./schema.ts";

export async function getOrCreateUser(uid: string, email?: string, name?: string, role?: string) {
  try {
    const result = await db
      .insert(users)
      .values({
        uid,
        email: email || null,
        name: name || null,
        role: role || "citizen",
      })
      .onConflictDoUpdate({
        target: users.uid,
        set: {
          email: email || undefined,
          name: name || undefined,
          updatedAt: new Date(),
        },
      })
      .returning();

    return result[0];
  } catch (error) {
    console.error("Database user upsert failed:", error);
    throw new Error("Failed to synchronize user account to Cloud SQL database.", { cause: error });
  }
}
