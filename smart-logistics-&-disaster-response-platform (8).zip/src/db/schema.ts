import { relations } from "drizzle-orm";
import { pgTable, serial, text, timestamp, integer, boolean, doublePrecision } from "drizzle-orm/pg-core";

// Users table (maps Firebase Auth UID)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  uid: text("uid").notNull().unique(), // Firebase Auth UID
  email: text("email"),
  name: text("name"),
  role: text("role").default("citizen"),
  phone: text("phone"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Disaster Incidents table
export const incidents = pgTable("incidents", {
  id: serial("id").primaryKey(),
  incidentId: text("incident_id").notNull().unique(),
  title: text("title").notNull(),
  type: text("type").notNull(),
  description: text("description"),
  locationName: text("location_name"),
  latitude: doublePrecision("latitude").notNull(),
  longitude: doublePrecision("longitude").notNull(),
  severity: text("severity").default("Medium"),
  status: text("status").default("REPORTED"),
  riskScore: integer("risk_score").default(50),
  reportedByUid: text("reported_by_uid"),
  reportedByName: text("reported_by_name"),
  reportedByRole: text("reported_by_role"),
  imageUrl: text("image_url"),
  estimatedClearanceHours: integer("estimated_clearance_hours").default(12),
  greenCorridorViability: boolean("green_corridor_viability").default(false),
  aiExplanation: text("ai_explanation"),
  recommendedAction: text("recommended_action"),
  confirmations: integer("confirmations").default(0),
  rejections: integer("rejections").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Transport Relief Bookings table
export const transportBookings = pgTable("transport_bookings", {
  id: serial("id").primaryKey(),
  bookingId: text("booking_id").notNull().unique(),
  userUid: text("user_uid"),
  pickupLocation: text("pickup_location").notNull(),
  destinationLocation: text("destination_location").notNull(),
  vehicleType: text("vehicle_type").notNull(),
  purpose: text("purpose").notNull(),
  priority: text("priority").default("NORMAL"),
  status: text("status").default("REQUESTED"),
  distanceKm: doublePrecision("distance_km"),
  estimatedFare: integer("estimated_fare"),
  driverName: text("driver_name"),
  driverPhone: text("driver_phone"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  incidents: many(incidents),
  bookings: many(transportBookings),
}));

export const incidentsRelations = relations(incidents, ({ one }) => ({
  reporter: one(users, {
    fields: [incidents.reportedByUid],
    references: [users.uid],
  }),
}));

export const transportBookingsRelations = relations(transportBookings, ({ one }) => ({
  user: one(users, {
    fields: [transportBookings.userUid],
    references: [users.uid],
  }),
}));
