import { GoogleGenAI, Type } from "@google/genai";
import { BroadcastAlert } from "../types";

export type DisruptionCategory =
  | "Road Closure"
  | "Landslide"
  | "Flood"
  | "Bridge Damage"
  | "Traffic Disruption"
  | "Emergency Update";

export interface SerpApiExtractedResult {
  title: string;
  source: string;
  url: string;
  publishedAt: string | null;
  snippet: string;
  locationMentioned: string;
  disruptionType: DisruptionCategory;
  queryUsed: string;
}

export interface GeminiProcessedDisruption {
  id: string;
  isRelevantDisruption: boolean;
  title: string;
  summary: string;
  reportedLocation: string;
  disruptionType: DisruptionCategory;
  source: string;
  url: string;
  publishedAt: string | null;
  verificationStatus: "Reported — Information requires verification";
  safetyNotice: string;
}

export interface SerpApiDisruptionResponse {
  status: "success" | "empty" | "unconfigured" | "rate_limited" | "error";
  message: string;
  locationQuery: string;
  coordinates: { lat: number; lng: number };
  queriesExecuted: string[];
  rawResultsCount: number;
  disruptions: GeminiProcessedDisruption[];
  alerts: BroadcastAlert[];
  cached: boolean;
  timestamp: string;
}

// In-memory cache to protect SerpApi rate limits and quota (10-minute TTL)
const CACHE_TTL_MS = 10 * 60 * 1000;
const disruptionCache = new Map<
  string,
  { expiresAt: number; payload: SerpApiDisruptionResponse }
>();

// Known North Eastern Region (NER) hubs for coordinate fallback
const NER_REFERENCE_HUBS = [
  { name: "Guwahati, Kamrup Metropolitan, Assam", lat: 26.1445, lng: 91.7362 },
  { name: "Sonapur, Kamrup, Assam", lat: 26.1188, lng: 91.9797 },
  { name: "Shillong, East Khasi Hills, Meghalaya", lat: 25.5788, lng: 91.8933 },
  { name: "Silchar, Cachar, Assam", lat: 24.8333, lng: 92.7789 },
  { name: "Nagaon, Assam", lat: 26.3464, lng: 92.684 },
  { name: "Kaziranga, Golaghat, Assam", lat: 26.5775, lng: 93.1711 },
  { name: "Itanagar, Papum Pare, Arunachal Pradesh", lat: 27.0844, lng: 93.6053 },
  { name: "Tawang, Arunachal Pradesh", lat: 27.5861, lng: 91.8594 },
  { name: "Kohima, Nagaland", lat: 25.6751, lng: 94.1086 },
  { name: "Dimapur, Nagaland", lat: 25.9091, lng: 93.7266 },
  { name: "Imphal, Manipur", lat: 24.817, lng: 93.9368 },
  { name: "Aizawl, Mizoram", lat: 23.7271, lng: 92.7176 },
  { name: "Agartala, West Tripura, Tripura", lat: 23.8315, lng: 91.2868 },
  { name: "Gangtok, East Sikkim, Sikkim", lat: 27.3389, lng: 88.6065 },
];

/**
 * Resolves GPS coordinates and/or existing app location string into a clean
 * city/district/state search string focused on the North Eastern Region (NER) of India.
 */
export async function resolveLocationQueryContext(
  lat?: number,
  lng?: number,
  rawLocationName?: string
): Promise<{ locationQuery: string; lat: number; lng: number }> {
  const safeLat = typeof lat === "number" && !Number.isNaN(lat) ? lat : 26.1445;
  const safeLng = typeof lng === "number" && !Number.isNaN(lng) ? lng : 91.7362;

  // 1. Clean existing location string if supplied from GPS hook
  if (rawLocationName && typeof rawLocationName === "string") {
    const cleaned = rawLocationName
      .replace(/\(DEMO\)/gi, "")
      .replace(/\[.*?\]/g, "")
      .replace(/\(\d+\.\d+.*?\)/g, "")
      .replace(/GPS:?/gi, "")
      .replace(/Disaster Command Sector/gi, "")
      .replace(/Unnamed Corridor,?/gi, "")
      .trim()
      .replace(/^,+|,+$/g, "")
      .trim();

    if (
      cleaned.length >= 3 &&
      !/^lat\s/i.test(cleaned) &&
      !/^coordinates/i.test(cleaned) &&
      !/^current location$/i.test(cleaned)
    ) {
      return { locationQuery: cleaned, lat: safeLat, lng: safeLng };
    }
  }

  // 2. Attempt reverse geocoding to obtain city/district/state
  try {
    const geoRes = await fetch(
      `https://nominatim.openstreetmap.org/reverse?format=json&lat=${safeLat}&lon=${safeLng}&zoom=12&addressdetails=1`,
      {
        headers: { "User-Agent": "VisionResQ-SIH26002-DisasterResponse/1.0" },
        signal: AbortSignal.timeout(4500),
      }
    );

    if (geoRes.ok) {
      const geo = await geoRes.json();
      const addr = geo.address || {};
      const city =
        addr.city ||
        addr.town ||
        addr.village ||
        addr.municipality ||
        addr.suburb ||
        "";
      const district =
        addr.state_district || addr.county || addr.city_district || "";
      const state = addr.state || "";

      const parts = [city, district, state]
        .map((p) => p.trim())
        .filter(Boolean)
        .filter((val, idx, arr) => arr.indexOf(val) === idx);

      if (parts.length > 0) {
        return {
          locationQuery: parts.join(", "),
          lat: safeLat,
          lng: safeLng,
        };
      }
    }
  } catch {
    // Fall through to nearest NER hub
  }

  // 3. Fallback: Find nearest North Eastern Region (NER) hub by coordinates
  let nearest = NER_REFERENCE_HUBS[0];
  let minDistance = Number.MAX_SAFE_INTEGER;
  for (const hub of NER_REFERENCE_HUBS) {
    const dLat = hub.lat - safeLat;
    const dLng = hub.lng - safeLng;
    const distSq = dLat * dLat + dLng * dLng;
    if (distSq < minDistance) {
      minDistance = distSq;
      nearest = hub;
    }
  }

  return {
    locationQuery: nearest.name,
    lat: safeLat,
    lng: safeLng,
  };
}

/**
 * Generates standard search queries for a given location as specified in requirements:
 * - "[location] road closure today"
 * - "[location] landslide today"
 * - "[location] flood road blocked today"
 * - "[location] bridge damage today"
 * - "[location] traffic disruption today"
 */
export function buildDisruptionSearchQueries(locationQuery: string): string[] {
  const cleanLoc = locationQuery.trim() || "Guwahati Assam";
  return [
    `${cleanLoc} road closure today`,
    `${cleanLoc} landslide today`,
    `${cleanLoc} flood road blocked today`,
    `${cleanLoc} bridge damage today`,
    `${cleanLoc} traffic disruption today`,
  ];
}

/**
 * Infers the disruption category from title/snippet/query text.
 */
function inferDisruptionType(text: string): DisruptionCategory {
  const lower = text.toLowerCase();
  if (lower.includes("landslide") || lower.includes("mudslide") || lower.includes("rockfall") || lower.includes("slope failure")) {
    return "Landslide";
  }
  if (lower.includes("flood") || lower.includes("inundat") || lower.includes("submerg") || lower.includes("waterlog")) {
    return "Flood";
  }
  if (lower.includes("bridge") || lower.includes("culvert") || lower.includes("viaduct")) {
    return "Bridge Damage";
  }
  if (lower.includes("road closure") || lower.includes("road closed") || lower.includes("highway closed") || lower.includes("blocked")) {
    return "Road Closure";
  }
  if (lower.includes("traffic") || lower.includes("congestion") || lower.includes("gridlock") || lower.includes("jam") || lower.includes("diversion")) {
    return "Traffic Disruption";
  }
  return "Emergency Update";
}

/**
 * Checks if a raw search result contains any keywords related to road disruptions or disasters.
 */
function isPotentiallyRelevantResult(title: string, snippet: string): boolean {
  const combined = `${title} ${snippet}`.toLowerCase();
  const disruptionKeywords = [
    "road",
    "highway",
    "nh-",
    "nh ",
    "closure",
    "closed",
    "blocked",
    "blockade",
    "landslide",
    "mudslide",
    "rockfall",
    "flood",
    "flooding",
    "inundat",
    "submerg",
    "waterlog",
    "bridge",
    "collapse",
    "damage",
    "traffic",
    "disruption",
    "diversion",
    "stranded",
    "rainfall",
    "disaster",
    "ndrf",
    "sdrf",
    "asdma",
    "emergency",
  ];
  return disruptionKeywords.some((kw) => combined.includes(kw));
}

/**
 * Extracts location mentioned from title/snippet or falls back to the queried location.
 */
function extractMentionedLocation(
  title: string,
  snippet: string,
  fallbackLocation: string
): string {
  const combined = `${title} ${snippet}`;
  const nhMatch = combined.match(/\b(NH[-\s]?\d+[A-Z]?)\b/i);
  const nerPlaces = [
    "Guwahati",
    "Sonapur",
    "Shillong",
    "Silchar",
    "Nagaon",
    "Jorhat",
    "Dibrugarh",
    "Tinsukia",
    "Tezpur",
    "Kaziranga",
    "Jagiroad",
    "Morigaon",
    "Haflong",
    "Dima Hasao",
    "Karbi Anglong",
    "Goalpara",
    "Bongaigaon",
    "Kokrajhar",
    "Dhubri",
    "Barpeta",
    "Nalbari",
    "Kamrup",
    "Cachar",
    "Karimganj",
    "Hailakandi",
    "Lakhimpur",
    "Dhemaji",
    "Majuli",
    "Sivasagar",
    "Golaghat",
    "Assam",
    "Meghalaya",
    "Arunachal Pradesh",
    "Itanagar",
    "Tawang",
    "Nagaland",
    "Kohima",
    "Dimapur",
    "Manipur",
    "Imphal",
    "Mizoram",
    "Aizawl",
    "Tripura",
    "Agartala",
    "Sikkim",
    "Gangtok",
  ];

  const matchedPlaces = nerPlaces.filter((place) =>
    new RegExp(`\\b${place}\\b`, "i").test(combined)
  );

  if (nhMatch && matchedPlaces.length > 0) {
    return `${nhMatch[1].toUpperCase()}, ${matchedPlaces.slice(0, 2).join(", ")}`;
  }
  if (matchedPlaces.length > 0) {
    return matchedPlaces.slice(0, 2).join(", ");
  }
  if (nhMatch) {
    return `${nhMatch[1].toUpperCase()} (${fallbackLocation})`;
  }
  return fallbackLocation;
}

/**
 * Executes a single SerpApi request securely from the backend.
 */
async function executeSerpApiQuery(
  query: string,
  apiKey: string
): Promise<{
  ok: boolean;
  rateLimited?: boolean;
  error?: string;
  items: SerpApiExtractedResult[];
  locationContext: string;
}> {
  const params = new URLSearchParams({
    engine: "google",
    q: query,
    hl: "en",
    gl: "in",
    num: "8",
    tbs: "qdr:w", // Past week/recent updates
    api_key: apiKey,
  });

  try {
    const response = await fetch(`https://serpapi.com/search.json?${params.toString()}`, {
      method: "GET",
      headers: {
        Accept: "application/json",
        "User-Agent": "VisionResQ-Backend/1.0",
      },
      signal: AbortSignal.timeout(10000),
    });

    if (response.status === 429) {
      return {
        ok: false,
        rateLimited: true,
        error: "SerpApi rate limit or quota reached",
        items: [],
        locationContext: query,
      };
    }

    if (!response.ok) {
      return {
        ok: false,
        error: `SerpApi returned HTTP ${response.status}`,
        items: [],
        locationContext: query,
      };
    }

    const data = await response.json();
    if (data.error) {
      const isQuota =
        typeof data.error === "string" &&
        (data.error.toLowerCase().includes("run out of searches") ||
          data.error.toLowerCase().includes("rate limit") ||
          data.error.toLowerCase().includes("quota"));
      return {
        ok: false,
        rateLimited: isQuota,
        error: String(data.error),
        items: [],
        locationContext: query,
      };
    }

    const extracted: SerpApiExtractedResult[] = [];

    // 1. Extract from top_stories / news_results if present
    const newsItems = [
      ...(Array.isArray(data.top_stories) ? data.top_stories : []),
      ...(Array.isArray(data.news_results) ? data.news_results : []),
    ];

    for (const item of newsItems) {
      const title = String(item.title || "").trim();
      const snippet = String(item.snippet || item.title || "").trim();
      const url = String(item.link || "").trim();
      if (!title || !url) continue;
      if (!isPotentiallyRelevantResult(title, snippet)) continue;

      const source =
        typeof item.source === "object" && item.source !== null
          ? String(item.source.name || "Web Report")
          : String(item.source || "News Report");
      const publishedAt = item.date ? String(item.date).trim() : null;

      extracted.push({
        title,
        source,
        url,
        publishedAt,
        snippet,
        locationMentioned: extractMentionedLocation(title, snippet, query),
        disruptionType: inferDisruptionType(`${title} ${snippet} ${query}`),
        queryUsed: query,
      });
    }

    // 2. Extract from organic_results
    const organicItems = Array.isArray(data.organic_results) ? data.organic_results : [];
    for (const item of organicItems) {
      const title = String(item.title || "").trim();
      const snippet = String(item.snippet || "").trim();
      const url = String(item.link || "").trim();
      if (!title || !url) continue;
      if (!isPotentiallyRelevantResult(title, snippet)) continue;

      const source = String(
        item.source || item.displayed_link?.split("/")?.[0] || "Web Search Report"
      ).trim();
      const publishedAt = item.date ? String(item.date).trim() : null;

      extracted.push({
        title,
        source,
        url,
        publishedAt,
        snippet,
        locationMentioned: extractMentionedLocation(title, snippet, query),
        disruptionType: inferDisruptionType(`${title} ${snippet} ${query}`),
        queryUsed: query,
      });
    }

    return {
      ok: true,
      items: extracted,
      locationContext: query,
    };
  } catch (err: any) {
    return {
      ok: false,
      error: err?.message || "Network error while contacting SerpApi",
      items: [],
      locationContext: query,
    };
  }
}

/**
 * Normalizes a title into significant lowercase tokens for deduplication.
 */
function tokenizeForDeduplication(text: string): Set<string> {
  const stopWords = new Set([
    "the",
    "and",
    "for",
    "with",
    "from",
    "near",
    "today",
    "news",
    "report",
    "reports",
    "update",
    "after",
    "due",
    "over",
    "into",
  ]);
  const tokens = text
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .split(/\s+/)
    .filter((w) => w.length > 2 && !stopWords.has(w));
  return new Set(tokens);
}

/**
 * Deduplicates extracted search results by URL, title token similarity, and incident overlap.
 * Prefers results that have a publication timestamp and higher relevance.
 */
export function deduplicateExtractedResults(
  results: SerpApiExtractedResult[],
  locationQuery: string
): SerpApiExtractedResult[] {
  // Sort to prefer items with publication dates and explicit location matches
  const primaryPlace = locationQuery.split(",")[0].trim().toLowerCase();
  const sorted = [...results].sort((a, b) => {
    const aHasLoc =
      primaryPlace &&
      `${a.title} ${a.snippet}`.toLowerCase().includes(primaryPlace)
        ? 1
        : 0;
    const bHasLoc =
      primaryPlace &&
      `${b.title} ${b.snippet}`.toLowerCase().includes(primaryPlace)
        ? 1
        : 0;
    if (aHasLoc !== bHasLoc) return bHasLoc - aHasLoc;

    const aHasDate = a.publishedAt ? 1 : 0;
    const bHasDate = b.publishedAt ? 1 : 0;
    return bHasDate - aHasDate;
  });

  const deduplicated: SerpApiExtractedResult[] = [];
  const seenUrls = new Set<string>();
  const seenTokenSets: { tokens: Set<string>; type: DisruptionCategory; loc: string }[] = [];

  for (const item of sorted) {
    const normalizedUrl = item.url.replace(/[?#].*$/, "").toLowerCase();
    if (seenUrls.has(normalizedUrl)) continue;

    const itemTokens = tokenizeForDeduplication(item.title);
    let isDuplicate = false;

    for (const existing of seenTokenSets) {
      // Check Jaccard / overlap similarity of title tokens
      let intersection = 0;
      for (const t of itemTokens) {
        if (existing.tokens.has(t)) intersection++;
      }
      const minSize = Math.min(itemTokens.size, existing.tokens.size);
      const overlapRatio = minSize > 0 ? intersection / minSize : 0;

      if (
        overlapRatio >= 0.6 ||
        (overlapRatio >= 0.4 &&
          existing.type === item.disruptionType &&
          existing.loc.toLowerCase() === item.locationMentioned.toLowerCase())
      ) {
        isDuplicate = true;
        break;
      }
    }

    if (!isDuplicate) {
      seenUrls.add(normalizedUrl);
      seenTokenSets.push({
        tokens: itemTokens,
        type: item.disruptionType,
        loc: item.locationMentioned,
      });
      deduplicated.push(item);
    }
  }

  return deduplicated.slice(0, 8);
}

/**
 * Enforces mandatory safety wording on any disruption summary:
 * - Never states a road is definitely safe or definitely closed solely because of a search result.
 * - Ensures wording includes "Reported", "According to available reports", and "Information requires verification".
 */
export function enforceSafetyWording(
  rawSummary: string,
  source: string,
  publishedAt: string | null
): string {
  let summary = rawSummary
    .replace(/\bis definitely closed\b/gi, "is reported as obstructed")
    .replace(/\bis completely closed\b/gi, "is reported to have closures")
    .replace(/\bis definitely safe\b/gi, "has no confirmed closure in this report")
    .replace(/\bconfirmed closed\b/gi, "reported as affected")
    .trim();

  const sourceAttribution = publishedAt
    ? `According to available reports from ${source} (${publishedAt})`
    : `According to available reports from ${source}`;

  if (
    !summary.toLowerCase().includes("according to available reports") &&
    !summary.toLowerCase().includes("reported")
  ) {
    summary = `${sourceAttribution}: ${summary}`;
  } else if (!summary.toLowerCase().includes("according to available reports")) {
    summary = `${sourceAttribution}, ${summary.charAt(0).toLowerCase()}${summary.slice(1)}`;
  }

  if (!summary.toLowerCase().includes("requires verification")) {
    summary = `${summary.replace(/\.*$/, "")}. Information requires verification.`;
  }

  return summary;
}

/**
 * Processes deduplicated SerpApi search results through the existing Gemini AI layer.
 */
export async function processDisruptionsWithGemini(
  candidates: SerpApiExtractedResult[],
  locationQuery: string,
  ai: GoogleGenAI | null
): Promise<GeminiProcessedDisruption[]> {
  if (candidates.length === 0) return [];

  if (ai) {
    try {
      const prompt = `You are the safety-critical road & disaster disruption verification assistant for VisionResQ in the North Eastern Region (NER) of India.
User's current region context: "${locationQuery}".

Evaluate the following web search results retrieved via SerpApi:
${JSON.stringify(
  candidates.map((c, idx) => ({
    index: idx,
    title: c.title,
    source: c.source,
    publishedAt: c.publishedAt || "Not specified",
    snippet: c.snippet,
    locationMentioned: c.locationMentioned,
    disruptionType: c.disruptionType,
  })),
  null,
  2
)}

For each item:
1. Determine "isRelevantDisruption" (boolean): true ONLY if the result is genuinely about a road closure, landslide, flood, bridge damage, major traffic disruption, or emergency/disaster-related local update relevant to road transit/safety in India (especially NER). Exclude generic dictionary pages, unrelated advertisements, or historical trivia.
2. Write "summary": Summarize the reported disruption in simple, clear language.
3. CRITICAL SAFETY LOGIC:
   - NEVER state that a road is definitely safe or definitely closed solely because of a search result.
   - ALWAYS use cautious wording such as "Reported road disruption", "According to available reports", and "Information requires verification".
   - Clearly distinguish reported information from confirmed information.
   - Indicate the source and timestamp when available.
4. Identify "reportedLocation" and "disruptionType" ("Road Closure", "Landslide", "Flood", "Bridge Damage", "Traffic Disruption", or "Emergency Update").`;

      const response = await ai.models.generateContent({
        model: "gemini-3.8-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                index: { type: Type.INTEGER },
                isRelevantDisruption: { type: Type.BOOLEAN },
                summary: { type: Type.STRING },
                reportedLocation: { type: Type.STRING },
                disruptionType: { type: Type.STRING },
              },
              required: [
                "index",
                "isRelevantDisruption",
                "summary",
                "reportedLocation",
                "disruptionType",
              ],
            },
          },
        },
      });

      if (response.text) {
        const parsed = JSON.parse(response.text.trim());
        if (Array.isArray(parsed)) {
          const verified: GeminiProcessedDisruption[] = [];
          for (const item of parsed) {
            if (!item.isRelevantDisruption) continue;
            const original = candidates[item.index];
            if (!original) continue;

            const validTypes: DisruptionCategory[] = [
              "Road Closure",
              "Landslide",
              "Flood",
              "Bridge Damage",
              "Traffic Disruption",
              "Emergency Update",
            ];
            const resolvedType: DisruptionCategory = validTypes.includes(
              item.disruptionType as DisruptionCategory
            )
              ? (item.disruptionType as DisruptionCategory)
              : original.disruptionType;

            const safeSummary = enforceSafetyWording(
              item.summary || original.snippet || original.title,
              original.source,
              original.publishedAt
            );

            verified.push({
              id: `serp_${Buffer.from(original.url).toString("base64url").slice(0, 16)}`,
              isRelevantDisruption: true,
              title: original.title.startsWith("Reported")
                ? original.title
                : `Reported ${resolvedType}: ${original.title}`,
              summary: safeSummary,
              reportedLocation: item.reportedLocation || original.locationMentioned || locationQuery,
              disruptionType: resolvedType,
              source: original.source,
              url: original.url,
              publishedAt: original.publishedAt,
              verificationStatus: "Reported — Information requires verification",
              safetyNotice:
                "Reported road disruption based on web reports. Information requires verification by field authorities.",
            });
          }
          return verified;
        }
      }
    } catch (err) {
      console.warn("Gemini processing of SerpApi results encountered an error, using strict rule filter:", err);
    }
  }

  // Deterministic fallback filter if Gemini is unavailable, still strictly enforcing safety logic
  return candidates
    .filter((c) => c.snippet.length > 20 && isPotentiallyRelevantResult(c.title, c.snippet))
    .slice(0, 4)
    .map((c) => ({
      id: `serp_${Buffer.from(c.url).toString("base64url").slice(0, 16)}`,
      isRelevantDisruption: true,
      title: `Reported ${c.disruptionType}: ${c.title}`,
      summary: enforceSafetyWording(c.snippet, c.source, c.publishedAt),
      reportedLocation: c.locationMentioned || locationQuery,
      disruptionType: c.disruptionType,
      source: c.source,
      url: c.url,
      publishedAt: c.publishedAt,
      verificationStatus: "Reported — Information requires verification",
      safetyNotice:
        "Reported road disruption based on web reports. Information requires verification by field authorities.",
    }));
}

/**
 * Converts processed disruptions into VisionResQ BroadcastAlert objects without generating
 * false Red emergency alerts (uses Amber/Yellow advisory levels with clear verification disclaimers).
 */
export function convertDisruptionsToBroadcastAlerts(
  disruptions: GeminiProcessedDisruption[]
): BroadcastAlert[] {
  return disruptions.map((d) => {
    const isWeatherRelated = d.disruptionType === "Flood" || d.disruptionType === "Landslide";
    return {
      id: d.id,
      title: d.title.length > 95 ? `${d.title.slice(0, 92)}...` : d.title,
      type: isWeatherRelated ? "WEATHER DISRUPTION" : "HIGH RISK ALERT",
      severity: "Amber",
      region: d.reportedLocation,
      message: d.summary,
      recommendedAction:
        "Reported road disruption — Information requires verification before route changes. Check official NHAI/SDMA advisories.",
      timestamp: d.publishedAt || "Recent web report",
      issuedBy: `${d.source} (Reported — Requires Verification)`,
      active: true,
    };
  });
}

/**
 * Main reusable service function for fetching, deduplicating, and AI-verifying
 * road and disaster disruptions via SerpApi.
 */
export async function searchRoadAndDisasterDisruptions(options: {
  lat?: number;
  lng?: number;
  locationName?: string;
  customQuery?: string;
  ai: GoogleGenAI | null;
}): Promise<SerpApiDisruptionResponse> {
  const { lat, lng, locationName, customQuery, ai } = options;
  const resolved = await resolveLocationQueryContext(lat, lng, locationName);
  const locationQuery = resolved.locationQuery;

  const cacheKey = `${resolved.lat.toFixed(2)}_${resolved.lng.toFixed(2)}_${locationQuery.toLowerCase()}_${customQuery || "default"}`;
  const cachedEntry = disruptionCache.get(cacheKey);
  if (cachedEntry && cachedEntry.expiresAt > Date.now()) {
    return { ...cachedEntry.payload, cached: true };
  }

  const apiKey = (process.env.SERPAPI_KEY || "").trim();
  const standardQueries = buildDisruptionSearchQueries(locationQuery);

  // If SERPAPI_KEY is not configured, return graceful empty fallback (NEVER create fake alerts)
  if (!apiKey || apiKey === "YOUR_SERPAPI_KEY" || apiKey === "MY_SERPAPI_KEY") {
    return {
      status: "unconfigured",
      message:
        "SERPAPI_KEY is not configured on the server. Returning empty disruption list without fake alerts.",
      locationQuery,
      coordinates: { lat: resolved.lat, lng: resolved.lng },
      queriesExecuted: [],
      rawResultsCount: 0,
      disruptions: [],
      alerts: [],
      cached: false,
      timestamp: new Date().toISOString(),
    };
  }

  // Execute targeted queries:
  // If customQuery is provided, run that specific query; otherwise run a consolidated query + top priority queries
  const queriesToRun = customQuery
    ? [customQuery]
    : [
        `${locationQuery} (road closure OR landslide OR flood road blocked OR bridge damage OR traffic disruption) today`,
        standardQueries[0], // "[location] road closure today"
        standardQueries[1], // "[location] landslide today"
      ];

  const allExtracted: SerpApiExtractedResult[] = [];
  const executedQueries: string[] = [];
  let rateLimited = false;
  let lastError: string | undefined;

  for (const q of queriesToRun) {
    executedQueries.push(q);
    const res = await executeSerpApiQuery(q, apiKey);
    if (res.rateLimited) {
      rateLimited = true;
      lastError = res.error;
      break;
    }
    if (!res.ok) {
      lastError = res.error;
      continue;
    }
    allExtracted.push(...res.items);
    // If we already gathered sufficient candidate items from the first query, avoid burning extra quota unnecessarily
    if (allExtracted.length >= 6 && !customQuery) {
      break;
    }
  }

  if (rateLimited && allExtracted.length === 0) {
    return {
      status: "rate_limited",
      message: lastError || "SerpApi rate limit reached. Continuing with existing platform data.",
      locationQuery,
      coordinates: { lat: resolved.lat, lng: resolved.lng },
      queriesExecuted: executedQueries,
      rawResultsCount: 0,
      disruptions: [],
      alerts: [],
      cached: false,
      timestamp: new Date().toISOString(),
    };
  }

  if (allExtracted.length === 0) {
    const emptyPayload: SerpApiDisruptionResponse = {
      status: lastError ? "error" : "empty",
      message:
        lastError ||
        "No relevant road or disaster disruption reports found for this location.",
      locationQuery,
      coordinates: { lat: resolved.lat, lng: resolved.lng },
      queriesExecuted: executedQueries,
      rawResultsCount: 0,
      disruptions: [],
      alerts: [],
      cached: false,
      timestamp: new Date().toISOString(),
    };
    disruptionCache.set(cacheKey, {
      expiresAt: Date.now() + CACHE_TTL_MS,
      payload: emptyPayload,
    });
    return emptyPayload;
  }

  // Deduplicate extracted results
  const deduplicated = deduplicateExtractedResults(allExtracted, locationQuery);

  // Send only the relevant retrieved information to the Gemini AI processing layer
  const processedDisruptions = await processDisruptionsWithGemini(
    deduplicated,
    locationQuery,
    ai
  );

  const alerts = convertDisruptionsToBroadcastAlerts(processedDisruptions);

  const responsePayload: SerpApiDisruptionResponse = {
    status: processedDisruptions.length > 0 ? "success" : "empty",
    message:
      processedDisruptions.length > 0
        ? `Retrieved ${processedDisruptions.length} reported disruption(s) requiring verification.`
        : "No verified road or disaster disruptions identified from search results.",
    locationQuery,
    coordinates: { lat: resolved.lat, lng: resolved.lng },
    queriesExecuted: executedQueries,
    rawResultsCount: allExtracted.length,
    disruptions: processedDisruptions,
    alerts,
    cached: false,
    timestamp: new Date().toISOString(),
  };

  disruptionCache.set(cacheKey, {
    expiresAt: Date.now() + CACHE_TTL_MS,
    payload: responsePayload,
  });

  return responsePayload;
}
