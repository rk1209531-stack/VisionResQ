import { Incident, RouteOption } from "../types";

export interface PlaceSuggestion {
  placeId: string;
  mainText: string;
  secondaryText: string;
  fullText: string;
  types?: string[];
}

export interface PlaceLocation {
  name: string;
  region?: string;
  address?: string;
  lat: number;
  lng: number;
  placeId?: string;
}

export interface ComputedCorridorResult {
  routeA: RouteOption;
  routeB: RouteOption;
  source: string;
}

/**
 * Real Google Places Autocomplete: search any location, district, landmark, or hub in India
 */
export async function searchPlacesAutocomplete(input: string): Promise<PlaceSuggestion[]> {
  const trimmed = input.trim();
  if (!trimmed || trimmed.length < 2) return [];

  try {
    const res = await fetch("/api/places/autocomplete", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ input: trimmed }),
    });

    if (!res.ok) {
      console.warn("Places autocomplete failed with status", res.status);
      return [];
    }

    const data = await res.json();
    return data.suggestions || [];
  } catch (err) {
    console.error("searchPlacesAutocomplete error:", err);
    return [];
  }
}

/**
 * Real Google Places Details: fetch exact lat/lng and formatted address for any selected place
 */
export async function getPlaceLocationDetails(placeId: string): Promise<PlaceLocation | null> {
  if (!placeId) return null;

  try {
    const res = await fetch("/api/places/details", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ placeId }),
    });

    if (!res.ok) return null;

    const data = await res.json();
    if (data.status === "success" && typeof data.lat === "number" && typeof data.lng === "number") {
      return {
        name: data.name,
        address: data.formattedAddress,
        region: data.formattedAddress?.split(",").slice(-2)[0]?.trim() || "India",
        lat: data.lat,
        lng: data.lng,
        placeId: data.placeId,
      };
    }
    return null;
  } catch (err) {
    console.error("getPlaceLocationDetails error:", err);
    return null;
  }
}

/**
 * Real Google Geocoding API: resolve string address or landmark to coordinates
 */
export async function geocodeLocation(address: string): Promise<PlaceLocation | null> {
  const trimmed = address.trim();
  if (!trimmed) return null;

  try {
    const res = await fetch(`/api/geocode?address=${encodeURIComponent(trimmed)}`);
    if (!res.ok) return null;

    const data = await res.json();
    if (data.status === "success" && typeof data.lat === "number" && typeof data.lng === "number") {
      return {
        name: data.name,
        address: data.formattedAddress,
        region: data.formattedAddress?.split(",").slice(-2)[0]?.trim() || "India",
        lat: data.lat,
        lng: data.lng,
        placeId: data.placeId,
      };
    }
    return null;
  } catch (err) {
    console.error("geocodeLocation error:", err);
    return null;
  }
}

/**
 * Real Google Reverse Geocoding: resolve lat/lng to real road, district, and city
 */
export async function reverseGeocodeCoords(lat: number, lng: number): Promise<PlaceLocation | null> {
  try {
    const res = await fetch(`/api/geocode?lat=${lat}&lng=${lng}`);
    if (!res.ok) return null;

    const data = await res.json();
    if (data.status === "success") {
      return {
        name: data.name,
        address: data.formattedAddress,
        region: data.formattedAddress?.split(",").slice(-2)[0]?.trim() || "India",
        lat,
        lng,
        placeId: data.placeId,
      };
    }
    return null;
  } catch (err) {
    console.error("reverseGeocodeCoords error:", err);
    return null;
  }
}

/**
 * Real Google Routes API v2: Calculate live driving routes between any two points in India,
 * evaluating intersections with active disaster incidents (landslides, floods, blockages).
 */
export async function computeRealGoogleRoute(
  origin: { lat: number; lng: number; name?: string },
  destination: { lat: number; lng: number; name?: string },
  incidents: Incident[] = []
): Promise<ComputedCorridorResult | null> {
  if (!origin?.lat || !origin?.lng || !destination?.lat || !destination?.lng) {
    return null;
  }

  try {
    const res = await fetch("/api/routes/compute", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        origin,
        destination,
        incidents: incidents.map((inc) => ({
          id: inc.id,
          title: inc.title,
          lat: inc.lat,
          lng: inc.lng,
          severity: inc.aiAnalysis?.severity || "High",
          type: inc.type,
        })),
      }),
    });

    if (!res.ok) {
      console.warn("Routes compute failed with status", res.status);
      return null;
    }

    const data = await res.json();
    if (data.status === "success" && data.routeA) {
      return {
        routeA: data.routeA,
        routeB: data.routeB,
        source: data.source || "Google Routes API v2",
      };
    }
    return null;
  } catch (err) {
    console.error("computeRealGoogleRoute error:", err);
    return null;
  }
}

/**
 * Browser GPS Detection with high accuracy & real Google reverse geocoding
 */
export async function getCurrentDeviceLocation(): Promise<PlaceLocation> {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error("Geolocation is not supported by your browser"));
      return;
    }

    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const { latitude, longitude } = pos.coords;
        // Reverse geocode using Google Geocoding API
        const place = await reverseGeocodeCoords(latitude, longitude);
        if (place) {
          resolve(place);
        } else {
          resolve({
            name: `My GPS Location (${latitude.toFixed(4)}, ${longitude.toFixed(4)})`,
            address: `Latitude: ${latitude.toFixed(5)}, Longitude: ${longitude.toFixed(5)}`,
            region: "Current Location",
            lat: latitude,
            lng: longitude,
          });
        }
      },
      (err) => {
        console.warn("GPS acquisition failed, error:", err.message);
        reject(err);
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 30000,
      }
    );
  });
}
