import { BroadcastAlert, Incident, OfflineReportQueueItem, SmartRoute } from "../types";

const OFFLINE_QUEUE_KEY = "sih_offline_incidents_queue";

export interface WeatherContext {
  temperature?: number;
  rainfall?: number;
  condition?: string;
  windSpeed?: number;
  weatherRisk?: string;
}

export async function analyzeIncidentWithGemini(payload: {
  imageBase64?: string;
  mimeType?: string;
  userDescription: string;
  locationName: string;
  lat?: number;
  lng?: number;
  weatherContext?: WeatherContext;
}) {
  try {
    const response = await fetch("/api/gemini/analyze-incident", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      throw new Error(`Server returned ${response.status}`);
    }

    const data = await response.json();
    return data.analysis;
  } catch (error) {
    console.warn("AI endpoint error, using local heuristic analyzer:", error);
    // Fallback heuristic if fetch fails
    return fallbackHeuristic(payload.userDescription, payload.locationName);
  }
}

// Server Incident Persistence APIs
export async function fetchServerIncidents(): Promise<Incident[]> {
  try {
    const response = await fetch("/api/incidents");
    if (response.ok) {
      const data = await response.json();
      return data.incidents || [];
    }
  } catch (err) {
    console.warn("Failed to fetch server incidents:", err);
  }
  return [];
}

export async function postServerIncident(incident: Partial<Incident>): Promise<Incident | null> {
  try {
    const response = await fetch("/api/incidents", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(incident),
    });
    if (response.ok) {
      const data = await response.json();
      return data.incident;
    }
  } catch (err) {
    console.warn("Failed to post server incident:", err);
  }
  return null;
}

export async function voteServerIncident(
  incidentId: string,
  action: "confirm" | "reject"
): Promise<{ confirmations: number; rejections: number; confidenceScore: number; incidentStatus: string } | null> {
  try {
    const response = await fetch(`/api/incidents/${incidentId}/vote`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action }),
    });
    if (response.ok) {
      return await response.json();
    }
  } catch (err) {
    console.warn("Vote API error:", err);
  }
  return null;
}

export async function updateServerIncidentStatus(
  incidentId: string,
  status: string,
  note?: string,
  updatedBy?: string
): Promise<Incident | null> {
  try {
    const response = await fetch(`/api/incidents/${incidentId}/status`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status, note, updatedBy }),
    });
    if (response.ok) {
      const data = await response.json();
      return data.incident;
    }
  } catch (err) {
    console.warn("Update status error:", err);
  }
  return null;
}

export async function fetchServerAlerts(): Promise<any[]> {
  try {
    const response = await fetch("/api/alerts");
    if (response.ok) {
      const data = await response.json();
      return data.alerts || [];
    }
  } catch (err) {
    console.warn("Failed to fetch alerts:", err);
  }
  return [];
}

export interface SerpApiClientDisruptionItem {
  id: string;
  isRelevantDisruption: boolean;
  title: string;
  summary: string;
  reportedLocation: string;
  disruptionType:
    | "Road Closure"
    | "Landslide"
    | "Flood"
    | "Bridge Damage"
    | "Traffic Disruption"
    | "Emergency Update";
  source: string;
  url: string;
  publishedAt: string | null;
  verificationStatus: string;
  safetyNotice: string;
}

export interface SerpApiClientSearchResponse {
  status: "success" | "empty" | "unconfigured" | "rate_limited" | "error";
  message: string;
  locationQuery: string;
  coordinates: { lat: number; lng: number };
  queriesExecuted: string[];
  rawResultsCount: number;
  disruptions: SerpApiClientDisruptionItem[];
  alerts: BroadcastAlert[];
  cached: boolean;
  timestamp: string;
}

/**
 * Fetches recent road and natural disaster disruption reports for the user's GPS
 * location in the North Eastern Region (NER) via the backend SerpApi + Gemini AI pipeline.
 * Never exposes API keys to the client and fails gracefully with empty arrays if unavailable.
 */
export async function fetchSerpApiDisruptionAlerts(params: {
  lat?: number;
  lng?: number;
  locationName?: string;
  query?: string;
}): Promise<SerpApiClientSearchResponse> {
  try {
    const response = await fetch("/api/disruptions/search", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(params),
    });

    if (!response.ok) {
      throw new Error(`Disruption search returned status ${response.status}`);
    }

    const data = await response.json();
    return {
      status: data.status || "empty",
      message: data.message || "",
      locationQuery: data.locationQuery || "",
      coordinates: data.coordinates || { lat: params.lat ?? 26.1445, lng: params.lng ?? 91.7362 },
      queriesExecuted: Array.isArray(data.queriesExecuted) ? data.queriesExecuted : [],
      rawResultsCount: typeof data.rawResultsCount === "number" ? data.rawResultsCount : 0,
      disruptions: Array.isArray(data.disruptions) ? data.disruptions : [],
      alerts: Array.isArray(data.alerts) ? data.alerts : [],
      cached: Boolean(data.cached),
      timestamp: data.timestamp || new Date().toISOString(),
    };
  } catch (err) {
    console.warn("SerpApi disruption lookup unavailable, continuing with existing alerts:", err);
    return {
      status: "error",
      message: "SerpApi disruption search unavailable.",
      locationQuery: params.locationName || "",
      coordinates: { lat: params.lat ?? 26.1445, lng: params.lng ?? 91.7362 },
      queriesExecuted: [],
      rawResultsCount: 0,
      disruptions: [],
      alerts: [],
      cached: false,
      timestamp: new Date().toISOString(),
    };
  }
}

export async function createServerAlert(alertData: any): Promise<any | null> {
  try {
    const response = await fetch("/api/alerts", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(alertData),
    });
    if (response.ok) {
      const data = await response.json();
      return data.alert;
    }
  } catch (err) {
    console.warn("Failed to create alert:", err);
  }
  return null;
}

export async function analyzeRouteWithGemini(payload: {

  origin: string;
  destination: string;
  routeAIncidents: any[];
  routeBIncidents: any[];
}): Promise<Partial<SmartRoute>> {
  try {
    const response = await fetch("/api/gemini/analyze-route", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      throw new Error(`Route AI returned ${response.status}`);
    }

    return await response.json();
  } catch (error) {
    console.warn("Route AI fallback:", error);
    return {
      routeA: {
        name: "Route A (Direct)",
        distanceKm: 248,
        estimatedMinutes: 380,
        riskPercentage: 82,
        hazards: ["Active Landslide"],
        isRecommended: false,
        roadCondition: "Severe Blockage",
      },
      routeB: {
        name: "Route B (Bypass)",
        distanceKm: 282,
        estimatedMinutes: 330,
        riskPercentage: 21,
        hazards: ["Minor wet pavement"],
        isRecommended: true,
        roadCondition: "Clear Expressway Corridor",
      },
      aiRecommendation: "Route B Recommended: 21% risk vs 82% risk on Route A.",
    };
  }
}

function fallbackHeuristic(description: string = "", locationName: string = "") {
  const d = description.toLowerCase();
  if (d.includes("landslide") || d.includes("rock") || d.includes("mountain") || d.includes("boulder")) {
    return {
      incidentType: "Landslide" as const,
      summary: `Severe rockfall and slope failure disrupting movement near ${locationName || "reported coordinates"}.`,
      severity: "High" as const,
      riskScore: 89,
      recommendedAction: "Use alternate mountain bypass route. Do not enter valley pinch points.",
      estimatedClearanceHours: 16,
      affectedInfrastructure: ["Carriageway", "Retaining Wall"],
      greenCorridorViability: false,
    };
  }
  if (d.includes("flood") || d.includes("water") || d.includes("rain") || d.includes("submerged")) {
    return {
      incidentType: "Flood" as const,
      summary: `Road surface submerged under heavy rainwater run-off. Danger of hydroplaning and stalled vehicles.`,
      severity: "High" as const,
      riskScore: 84,
      recommendedAction: "Diversion for light vehicles; commercial freight hold at designated staging areas.",
      estimatedClearanceHours: 10,
      affectedInfrastructure: ["Submerged Culverts", "Asphalt Base"],
      greenCorridorViability: false,
    };
  }
  if (d.includes("bridge") || d.includes("crack") || d.includes("structure")) {
    return {
      incidentType: "Bridge Damage" as const,
      summary: `Visible structural stress cracks observed on bridge support elements.`,
      severity: "Critical" as const,
      riskScore: 95,
      recommendedAction: "Immediate vehicular shutdown. Structural audit by PWD / NHAI engineers required.",
      estimatedClearanceHours: 48,
      affectedInfrastructure: ["Pier Column", "Bearing Pad"],
      greenCorridorViability: false,
    };
  }
  if (d.includes("traffic") || d.includes("truck") || d.includes("jam") || d.includes("accident")) {
    return {
      incidentType: "Traffic Blockage" as const,
      summary: `Multi-vehicle freight bottleneck blocking active transit lanes.`,
      severity: "Medium" as const,
      riskScore: 62,
      recommendedAction: "Divert light traffic to hard shoulder; dispatch heavy tow trucks.",
      estimatedClearanceHours: 3,
      affectedInfrastructure: ["Carriageway Lanes 1 & 2"],
      greenCorridorViability: true,
    };
  }
  return {
    incidentType: "Road Damage" as const,
    summary: `Road surface degradation with deep fissures impacting safe transit speed.`,
    severity: "Medium" as const,
    riskScore: 58,
    recommendedAction: "Speed restriction 20 km/h; caution on uneven shoulders.",
    estimatedClearanceHours: 8,
    affectedInfrastructure: ["Pavement Base", "Road Shoulder"],
    greenCorridorViability: true,
  };
}

// Offline Queue Management
export function getOfflineQueue(): OfflineReportQueueItem[] {
  try {
    const raw = localStorage.getItem(OFFLINE_QUEUE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveToOfflineQueue(item: OfflineReportQueueItem) {
  try {
    const queue = getOfflineQueue();
    queue.push(item);
    localStorage.setItem(OFFLINE_QUEUE_KEY, JSON.stringify(queue));
  } catch (err) {
    console.error("Failed to save to offline storage:", err);
  }
}

export function clearOfflineQueue() {
  try {
    localStorage.removeItem(OFFLINE_QUEUE_KEY);
  } catch (err) {
    console.error("Failed to clear offline storage:", err);
  }
}

export function syncOfflineReports(
  onReportSynced: (incident: Incident) => void
): number {
  const queue = getOfflineQueue();
  if (queue.length === 0) return 0;

  queue.forEach((item, index) => {
    const ai = fallbackHeuristic(item.description, item.locationName);
    const syncedIncident: Incident = {
      id: `INC-SYNC-${Date.now()}-${index}`,
      title: `${item.type} (Synced from Offline Report)`,
      type: item.type,
      description: item.description,
      locationName: item.locationName || "Offline Captured Coordinates",
      lat: item.lat,
      lng: item.lng,
      imageUrl: item.imageBase64 || "https://images.unsplash.com/photo-1547683905-f686c993aae5?w=800&auto=format&fit=crop&q=80",
      reportedAt: "Just now (Synced)",
      reportedBy: {
        name: "Offline Citizen Reporter",
        role: "citizen",
      },
      aiAnalysis: {
        ...ai,
        analyzedAt: "Just now",
        modelUsed: "gemini-3.8-flash",
      },
      crowdVerification: {
        confirmations: 1,
        rejections: 0,
        confidenceScore: 50,
      },
      status: "Reported",
      resolutionTimeline: [
        {
          step: "Reported",
          timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
          note: "Report submitted offline and automatically synced once network connected.",
          updatedBy: "Offline Sync Service",
        },
      ],
      isOfflineSubmitted: true,
    };

    onReportSynced(syncedIncident);
  });

  clearOfflineQueue();
  return queue.length;
}
