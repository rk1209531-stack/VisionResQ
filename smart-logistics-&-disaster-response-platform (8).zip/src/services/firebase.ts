import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import {
  getFirestore,
  doc,
  getDoc,
  getDocFromServer,
  collection,
  onSnapshot,
  setDoc,
  updateDoc,
  getDocs,
  Unsubscribe,
} from "firebase/firestore";
import firebaseConfig from "../../firebase-applet-config.json";
import { Incident, EmergencyRequest, BroadcastAlert, TransportBooking } from "../types";
import { INITIAL_INCIDENTS, INITIAL_EMERGENCY_REQUESTS } from "../mockData";
import { INITIAL_BOOKINGS } from "../transportData";

// Initialize Firebase App
export const app = initializeApp(firebaseConfig);

// CRITICAL: The app will break without specifying firestoreDatabaseId if custom ID was used
const firestoreDatabaseId = (firebaseConfig as any).firestoreDatabaseId || "(default)";
export const db = getFirestore(app, firestoreDatabaseId);
export const auth = getAuth(app);

// Operational Error Handling as mandated by the Firebase skill
export enum OperationType {
  CREATE = "create",
  UPDATE = "update",
  DELETE = "delete",
  LIST = "list",
  GET = "get",
  WRITE = "write",
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error("Firestore Error: ", JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

/**
 * Sanitizes data before writing to Firestore:
 * 1. Strips all `undefined` values (which Firestore rejects).
 * 2. Recursively flattens/converts nested arrays (e.g. coordinates `[ [lat, lng], ... ]`)
 *    into an array of objects `{ lat, lng }`, since Firestore strictly forbids nested arrays.
 */
export function sanitizeForFirestore<T = any>(obj: T): any {
  if (obj === null || obj === undefined) {
    return null;
  }
  if (Array.isArray(obj)) {
    return obj.map((item) => {
      if (Array.isArray(item)) {
        // Detected nested array (array inside array)
        if (item.length === 2 && typeof item[0] === "number" && typeof item[1] === "number") {
          return { lat: item[0], lng: item[1] };
        }
        return { items: sanitizeForFirestore(item) };
      }
      return sanitizeForFirestore(item);
    });
  }
  if (typeof obj === "object") {
    if (obj instanceof Date) {
      return obj.toISOString();
    }
    const clean: Record<string, any> = {};
    for (const [k, v] of Object.entries(obj)) {
      if (v !== undefined) {
        clean[k] = sanitizeForFirestore(v);
      }
    }
    return clean;
  }
  return obj;
}

/**
 * Deserializes Firestore booking documents back to the client interface:
 * Restores `{ lat, lng }[]` coordinate points back to `[number, number][]` format
 * for seamless compatibility with map polylines and tracking simulations.
 */
export function deserializeBookingFromFirestore(docData: any): TransportBooking {
  if (!docData) return docData;
  const booking = { ...docData };
  if (booking.routeDetails && Array.isArray(booking.routeDetails.pathCoordinates)) {
    booking.routeDetails = {
      ...booking.routeDetails,
      pathCoordinates: booking.routeDetails.pathCoordinates.map((pt: any) => {
        if (Array.isArray(pt) && pt.length >= 2) {
          return [Number(pt[0]), Number(pt[1])] as [number, number];
        }
        if (pt && typeof pt === "object" && "lat" in pt && "lng" in pt) {
          return [Number(pt.lat), Number(pt.lng)] as [number, number];
        }
        return pt;
      }),
    };
  }
  return booking as TransportBooking;
}

// Mandatory connection test on boot
export async function testConnection(): Promise<boolean> {
  const testPath = "test/connection";
  try {
    await getDocFromServer(doc(db, "test", "connection"));
    console.log("Firebase Firestore connected successfully to:", firestoreDatabaseId);
    return true;
  } catch (error) {
    if (error instanceof Error && error.message.includes("the client is offline")) {
      console.error("Please check your Firebase configuration.");
    } else {
      console.info("Firestore connection probe executed:", error);
    }
    return false;
  }
}

// -----------------------------------------------------------------------------------
// 1. INCIDENTS (Real-Time Firestore Sync)
// -----------------------------------------------------------------------------------
const INCIDENTS_COLLECTION = "incidents";

export function subscribeIncidents(
  onUpdate: (incidents: Incident[]) => void,
  onError?: (err: Error) => void
): Unsubscribe {
  const colRef = collection(db, INCIDENTS_COLLECTION);
  return onSnapshot(
    colRef,
    (snapshot) => {
      const items: Incident[] = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        items.push({
          ...data,
          id: docSnap.id,
        } as Incident);
      });
      onUpdate(items);
    },
    (error) => {
      try {
        handleFirestoreError(error, OperationType.LIST, INCIDENTS_COLLECTION);
      } catch (e) {
        if (onError) onError(e as Error);
      }
    }
  );
}

export async function saveIncidentToFirestore(incident: Incident): Promise<void> {
  const docRef = doc(db, INCIDENTS_COLLECTION, incident.id);
  try {
    await setDoc(docRef, sanitizeForFirestore({
      ...incident,
      updatedAt: new Date().toISOString(),
    }));
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `${INCIDENTS_COLLECTION}/${incident.id}`);
  }
}

export async function updateIncidentInFirestore(
  incidentId: string,
  updates: Partial<Incident>,
  currentSnapshot?: Incident
): Promise<void> {
  const docRef = doc(db, INCIDENTS_COLLECTION, incidentId);
  try {
    const snap = await getDoc(docRef);
    if (!snap.exists()) {
      const base =
        currentSnapshot ||
        INITIAL_INCIDENTS.find((i) => i.id === incidentId);
      if (base) {
        await setDoc(docRef, sanitizeForFirestore({
          ...base,
          ...updates,
          updatedAt: new Date().toISOString(),
        }));
        return;
      }
    }
    await updateDoc(docRef, sanitizeForFirestore({
      ...updates,
      updatedAt: new Date().toISOString(),
    }));
  } catch (error: any) {
    if (
      error?.code === "not-found" ||
      (error?.message && error.message.includes("No document to update"))
    ) {
      const base =
        currentSnapshot ||
        INITIAL_INCIDENTS.find((i) => i.id === incidentId);
      if (base) {
        try {
          await setDoc(docRef, sanitizeForFirestore({
            ...base,
            ...updates,
            updatedAt: new Date().toISOString(),
          }));
          return;
        } catch (innerError) {
          handleFirestoreError(innerError, OperationType.WRITE, `${INCIDENTS_COLLECTION}/${incidentId}`);
          return;
        }
      }
    }
    handleFirestoreError(error, OperationType.UPDATE, `${INCIDENTS_COLLECTION}/${incidentId}`);
  }
}

// -----------------------------------------------------------------------------------
// 2. EMERGENCY REQUESTS (Real-Time Firestore Sync)
// -----------------------------------------------------------------------------------
const EMERGENCY_COLLECTION = "emergency_requests";

export function subscribeEmergencyRequests(
  onUpdate: (requests: EmergencyRequest[]) => void,
  onError?: (err: Error) => void
): Unsubscribe {
  const colRef = collection(db, EMERGENCY_COLLECTION);
  return onSnapshot(
    colRef,
    (snapshot) => {
      const items: EmergencyRequest[] = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        items.push({
          ...data,
          id: docSnap.id,
        } as EmergencyRequest);
      });
      onUpdate(items);
    },
    (error) => {
      try {
        handleFirestoreError(error, OperationType.LIST, EMERGENCY_COLLECTION);
      } catch (e) {
        if (onError) onError(e as Error);
      }
    }
  );
}

export async function saveEmergencyRequestToFirestore(request: EmergencyRequest): Promise<void> {
  const docRef = doc(db, EMERGENCY_COLLECTION, request.id);
  try {
    await setDoc(docRef, sanitizeForFirestore({
      ...request,
      updatedAt: new Date().toISOString(),
    }));
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `${EMERGENCY_COLLECTION}/${request.id}`);
  }
}

export async function updateEmergencyRequestInFirestore(
  requestId: string,
  updates: Partial<EmergencyRequest>,
  currentSnapshot?: EmergencyRequest
): Promise<void> {
  const docRef = doc(db, EMERGENCY_COLLECTION, requestId);
  try {
    const snap = await getDoc(docRef);
    if (!snap.exists()) {
      const base =
        currentSnapshot ||
        INITIAL_EMERGENCY_REQUESTS.find((r) => r.id === requestId);
      if (base) {
        await setDoc(docRef, sanitizeForFirestore({
          ...base,
          ...updates,
          updatedAt: new Date().toISOString(),
        }));
        return;
      }
    }
    await updateDoc(docRef, sanitizeForFirestore({
      ...updates,
      updatedAt: new Date().toISOString(),
    }));
  } catch (error: any) {
    if (
      error?.code === "not-found" ||
      (error?.message && error.message.includes("No document to update"))
    ) {
      const base =
        currentSnapshot ||
        INITIAL_EMERGENCY_REQUESTS.find((r) => r.id === requestId);
      if (base) {
        try {
          await setDoc(docRef, sanitizeForFirestore({
            ...base,
            ...updates,
            updatedAt: new Date().toISOString(),
          }));
          return;
        } catch (innerError) {
          handleFirestoreError(innerError, OperationType.WRITE, `${EMERGENCY_COLLECTION}/${requestId}`);
          return;
        }
      }
    }
    handleFirestoreError(error, OperationType.UPDATE, `${EMERGENCY_COLLECTION}/${requestId}`);
  }
}

// -----------------------------------------------------------------------------------
// 3. TRANSPORT BOOKINGS (Real-Time Disaster Logistics Sync)
// -----------------------------------------------------------------------------------
const BOOKINGS_COLLECTION = "transport_bookings";

export function subscribeTransportBookings(
  onUpdate: (bookings: TransportBooking[]) => void,
  onError?: (err: Error) => void
): Unsubscribe {
  const colRef = collection(db, BOOKINGS_COLLECTION);
  return onSnapshot(
    colRef,
    (snapshot) => {
      const items: TransportBooking[] = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        items.push(
          deserializeBookingFromFirestore({
            ...data,
            bookingId: docSnap.id,
          })
        );
      });
      onUpdate(items);
    },
    (error) => {
      try {
        handleFirestoreError(error, OperationType.LIST, BOOKINGS_COLLECTION);
      } catch (e) {
        if (onError) onError(e as Error);
      }
    }
  );
}

export async function saveTransportBookingToFirestore(booking: TransportBooking): Promise<void> {
  const docRef = doc(db, BOOKINGS_COLLECTION, booking.bookingId);
  try {
    await setDoc(docRef, sanitizeForFirestore({
      ...booking,
      updatedAt: new Date().toISOString(),
    }));
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `${BOOKINGS_COLLECTION}/${booking.bookingId}`);
  }
}

export async function updateTransportBookingInFirestore(
  bookingId: string,
  updates: Partial<TransportBooking>,
  currentSnapshot?: TransportBooking
): Promise<void> {
  const docRef = doc(db, BOOKINGS_COLLECTION, bookingId);
  try {
    const snap = await getDoc(docRef);
    if (!snap.exists()) {
      const base =
        currentSnapshot ||
        INITIAL_BOOKINGS.find((b) => b.bookingId === bookingId) || {
          bookingId,
          vehicleType: updates.vehicleType || "Mini Truck",
          status: updates.status || "Driver Assigned",
          origin: "Disaster Logistics Base",
          destination: "Relief Distribution Center",
          cargoDescription: "Emergency Relief Logistics",
          priority: "High",
          purpose: "Relief Goods Delivery",
          contactPerson: { name: "Relief Logistics Officer", phone: "+91 98765 00000" },
          assignedDriver: {
            name: "Suresh Kumar",
            phone: "+91 98111 22334",
            vehicleNumber: "UK-07-GA-4412",
            vehicleModel: "Tata 407 4x4",
            rating: 4.8,
            currentLocation: "Transit Camp",
          },
          estimatedPickupTime: "Within 20 mins",
          estimatedDeliveryTime: "Within 2 hours",
          distanceKm: 42,
          routeDetails: {
            routeName: "Active Relief Corridor",
            riskScore: 25,
            waypoints: ["Base", "Transit Depot", "Relief Hub"],
            hazardWarnings: [],
            recommendedSpeedLimit: "35 km/h",
          },
          fareBreakdown: {
            baseFare: 250,
            distanceCharge: 1470,
            riskDetourCharge: 0,
            totalEstimatedFare: 1720,
          },
          driverProgressPercent: 10,
          greenCorridorApproved: false,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };

      await setDoc(docRef, sanitizeForFirestore({
        ...base,
        ...updates,
        updatedAt: new Date().toISOString(),
      }));
      return;
    }

    await updateDoc(docRef, sanitizeForFirestore({
      ...updates,
      updatedAt: new Date().toISOString(),
    }));
  } catch (error: any) {
    if (
      error?.code === "not-found" ||
      (error?.message && error.message.includes("No document to update"))
    ) {
      const base =
        currentSnapshot ||
        INITIAL_BOOKINGS.find((b) => b.bookingId === bookingId) || {
          bookingId,
          vehicleType: updates.vehicleType || "Mini Truck",
          status: updates.status || "Driver Assigned",
          origin: "Disaster Logistics Base",
          destination: "Relief Distribution Center",
          cargoDescription: "Emergency Relief Logistics",
          priority: "High",
          purpose: "Relief Goods Delivery",
          contactPerson: { name: "Relief Logistics Officer", phone: "+91 98765 00000" },
          assignedDriver: {
            name: "Suresh Kumar",
            phone: "+91 98111 22334",
            vehicleNumber: "UK-07-GA-4412",
            vehicleModel: "Tata 407 4x4",
            rating: 4.8,
            currentLocation: "Transit Camp",
          },
          estimatedPickupTime: "Within 20 mins",
          estimatedDeliveryTime: "Within 2 hours",
          distanceKm: 42,
          routeDetails: {
            routeName: "Active Relief Corridor",
            riskScore: 25,
            waypoints: ["Base", "Transit Depot", "Relief Hub"],
            hazardWarnings: [],
            recommendedSpeedLimit: "35 km/h",
          },
          fareBreakdown: {
            baseFare: 250,
            distanceCharge: 1470,
            riskDetourCharge: 0,
            totalEstimatedFare: 1720,
          },
          driverProgressPercent: 10,
          greenCorridorApproved: false,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };

      try {
        await setDoc(docRef, sanitizeForFirestore({
          ...base,
          ...updates,
          updatedAt: new Date().toISOString(),
        }));
        return;
      } catch (innerError) {
        handleFirestoreError(innerError, OperationType.WRITE, `${BOOKINGS_COLLECTION}/${bookingId}`);
        return;
      }
    }
    handleFirestoreError(error, OperationType.UPDATE, `${BOOKINGS_COLLECTION}/${bookingId}`);
  }
}

// -----------------------------------------------------------------------------------
// 4. BROADCAST ALERTS (Real-Time Alert Sync)
// -----------------------------------------------------------------------------------
const ALERTS_COLLECTION = "broadcast_alerts";

export function subscribeBroadcastAlerts(
  onUpdate: (alerts: BroadcastAlert[]) => void,
  onError?: (err: Error) => void
): Unsubscribe {
  const colRef = collection(db, ALERTS_COLLECTION);
  return onSnapshot(
    colRef,
    (snapshot) => {
      const items: BroadcastAlert[] = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        items.push({
          ...data,
          id: docSnap.id,
        } as BroadcastAlert);
      });
      onUpdate(items);
    },
    (error) => {
      try {
        handleFirestoreError(error, OperationType.LIST, ALERTS_COLLECTION);
      } catch (e) {
        if (onError) onError(e as Error);
      }
    }
  );
}

export async function saveBroadcastAlertToFirestore(alert: BroadcastAlert): Promise<void> {
  const docRef = doc(db, ALERTS_COLLECTION, alert.id);
  try {
    await setDoc(docRef, sanitizeForFirestore({
      ...alert,
      updatedAt: new Date().toISOString(),
    }));
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `${ALERTS_COLLECTION}/${alert.id}`);
  }
}

// -----------------------------------------------------------------------------------
// 5. Initial Seed Helper: Seeds initial baseline dataset if cloud records are missing
// -----------------------------------------------------------------------------------
export async function seedInitialFirestoreDataIfEmpty(
  initialIncidents: Incident[],
  initialAlerts: BroadcastAlert[],
  initialEmergency: EmergencyRequest[],
  initialBookings: TransportBooking[]
) {
  try {
    // 1. Ensure all baseline incidents exist
    const incidentsSnap = await getDocs(collection(db, INCIDENTS_COLLECTION));
    const existingIncidentIds = new Set(incidentsSnap.docs.map((d) => d.id));
    for (const inc of initialIncidents) {
      if (!existingIncidentIds.has(inc.id)) {
        await setDoc(doc(db, INCIDENTS_COLLECTION, inc.id), sanitizeForFirestore(inc));
      }
    }

    // 2. Ensure all baseline alerts exist
    const alertsSnap = await getDocs(collection(db, ALERTS_COLLECTION));
    const existingAlertIds = new Set(alertsSnap.docs.map((d) => d.id));
    for (const alert of initialAlerts) {
      if (!existingAlertIds.has(alert.id)) {
        await setDoc(doc(db, ALERTS_COLLECTION, alert.id), sanitizeForFirestore(alert));
      }
    }

    // 3. Ensure all baseline emergency SOS requests exist
    const emergencySnap = await getDocs(collection(db, EMERGENCY_COLLECTION));
    const existingEmergencyIds = new Set(emergencySnap.docs.map((d) => d.id));
    for (const req of initialEmergency) {
      if (!existingEmergencyIds.has(req.id)) {
        await setDoc(doc(db, EMERGENCY_COLLECTION, req.id), sanitizeForFirestore(req));
      }
    }

    // 4. Ensure all baseline transport bookings exist
    const bookingsSnap = await getDocs(collection(db, BOOKINGS_COLLECTION));
    const existingBookingIds = new Set(bookingsSnap.docs.map((d) => d.id));
    for (const booking of initialBookings) {
      if (!existingBookingIds.has(booking.bookingId)) {
        await setDoc(doc(db, BOOKINGS_COLLECTION, booking.bookingId), sanitizeForFirestore(booking));
      }
    }
  } catch (e) {
    console.warn("Initial Firestore seed notice (offline or permission):", e);
  }
}
