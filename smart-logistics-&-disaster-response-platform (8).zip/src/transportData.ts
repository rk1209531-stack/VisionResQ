import {
  VehiclePricingConfig,
  VehicleType,
  RouteOption,
  TransportBooking,
  TripPurpose,
  BookingPriority,
} from "./types";

export const INITIAL_VEHICLE_PRICING: VehiclePricingConfig[] = [
  {
    type: "Bike",
    baseFare: 40,
    ratePerKm: 10,
    capacity: "1 Passenger or Small Parcel (<10 kg)",
    description: "Rapid disaster scout & vital blood/antivenom courier; passes single-lane debris",
    iconName: "Bike",
  },
  {
    type: "Mini Truck",
    baseFare: 250,
    ratePerKm: 35,
    capacity: "1.5 - 2.5 Tons Cargo",
    description: "Emergency rations, clean water containers, tents, and generator transport",
    iconName: "Truck",
  },
  {
    type: "Heavy Truck",
    baseFare: 600,
    ratePerKm: 55,
    capacity: "10 - 18 Tons Heavy Freight",
    description: "Earthmovers, Bailey bridge components, bulk grain, and prefabricated shelters",
    iconName: "Truck",
  },
];

export interface LocationPreset {
  name: string;
  region: string;
  lat: number;
  lng: number;
  isHighRiskZone?: boolean;
}

export const PRESET_LOCATIONS: LocationPreset[] = [
  { name: "Rajouri (Border District)", region: "Jammu & Kashmir", lat: 33.3765, lng: 74.3103, isHighRiskZone: true },
  { name: "Jammu Tawi Base Depot", region: "Jammu & Kashmir", lat: 32.7266, lng: 74.8570, isHighRiskZone: false },
  { name: "Srinagar Relief Hub", region: "Kashmir Valley", lat: 34.0837, lng: 74.7973, isHighRiskZone: true },
  { name: "Poonch Sector Forward Post", region: "Jammu & Kashmir", lat: 33.7712, lng: 74.0950, isHighRiskZone: true },
  { name: "Udhampur Logistics Base", region: "Jammu & Kashmir", lat: 32.9255, lng: 75.1416, isHighRiskZone: false },
  { name: "Rishikesh Transit Center", region: "Uttarakhand", lat: 30.0869, lng: 78.2676, isHighRiskZone: false },
  { name: "Devprayag (NH-58 Junction)", region: "Uttarakhand", lat: 30.1459, lng: 78.5989, isHighRiskZone: true },
  { name: "Joshimath Relief Depot (Chamoli)", region: "Uttarakhand", lat: 30.5564, lng: 79.5667, isHighRiskZone: true },
  { name: "Kedarnath Base Relief Camp", region: "Uttarakhand", lat: 30.7346, lng: 79.0669, isHighRiskZone: true },
  { name: "Rudraprayag Confluence Hub", region: "Uttarakhand", lat: 30.2844, lng: 78.9811, isHighRiskZone: true },
  { name: "Dehradun State Emergency HQ", region: "Uttarakhand", lat: 30.3165, lng: 78.0322, isHighRiskZone: false },
  { name: "Tehri Dam Ridge Bypass", region: "Uttarakhand", lat: 30.3800, lng: 78.4800, isHighRiskZone: false },
  { name: "Guwahati Brahmaputra Depot", region: "Assam", lat: 26.1445, lng: 91.7362, isHighRiskZone: true },
  { name: "Silchar Flood Relief Zone", region: "Assam", lat: 24.8333, lng: 92.7789, isHighRiskZone: true },
  { name: "Tezpur Civil & Military Hospital", region: "Assam", lat: 26.6528, lng: 92.7926, isHighRiskZone: false },
  { name: "Nagaon Flood Evacuation Depot", region: "Assam", lat: 26.3466, lng: 92.6840, isHighRiskZone: true },
  { name: "Kaziranga Relief Staging Post", region: "Assam", lat: 26.5775, lng: 93.1711, isHighRiskZone: true },
  { name: "Mandi Valley Relief Sector", region: "Himachal Pradesh", lat: 31.5892, lng: 76.9182, isHighRiskZone: true },
  { name: "Manali Mountain Transit Hub", region: "Himachal Pradesh", lat: 32.2396, lng: 77.1887, isHighRiskZone: true },
  { name: "Shimla Emergency Command Post", region: "Himachal Pradesh", lat: 31.1048, lng: 77.1734, isHighRiskZone: false },
  { name: "Leh Ladakh Logistics Airfield", region: "Ladakh", lat: 34.1526, lng: 77.5771, isHighRiskZone: false },
  { name: "Wayanad Landslide Disaster Camp", region: "Kerala", lat: 11.6854, lng: 76.1320, isHighRiskZone: true },
  { name: "Kozhikode Trauma & Air Cargo Center", region: "Kerala", lat: 11.2588, lng: 75.7804, isHighRiskZone: false },
  { name: "New Delhi National Relief Reserve", region: "Delhi NCR", lat: 28.6139, lng: 77.2090, isHighRiskZone: false },
  { name: "Chandigarh Logistics Airbase", region: "Punjab / Haryana", lat: 30.7333, lng: 76.7794, isHighRiskZone: false },
];

export const CORRIDOR_ROUTES: Record<string, { routeA: RouteOption; routeB: RouteOption }> = {
  default: {
    routeA: {
      id: "Route A",
      name: "Direct National Highway NH-144A",
      via: "Direct Canyon Pass (Shivkhori-Akhnoor)",
      distanceKm: 120,
      estimatedMinutes: 180, // 3 hr
      riskScore: 78,
      riskLevel: "HIGH RISK",
      activeIncidentsCount: 3,
      incidentSummary: "Active boulder landslide at km 42, waterlogged culvert, and mudflow",
      roadAccessibility: "High Hazard / Blocked",
      isRecommended: false,
      recommendationReason: "❌ NOT RECOMMENDED: High risk of vehicle entrapment due to 3 active landslide warnings.",
      pathCoordinates: [
        [33.3765, 74.3103],
        [33.2500, 74.4500],
        [33.1000, 74.6200],
        [32.9000, 74.7400],
        [32.7266, 74.8570],
      ],
    },
    routeB: {
      id: "Route B",
      name: "Reasi-Katra Engineered Ridge Bypass",
      via: "Reasi Paved Bypass & Elevated Katra Corridor",
      distanceKm: 128,
      estimatedMinutes: 200, // 3 hr 20 min
      riskScore: 22,
      riskLevel: "LOW RISK",
      activeIncidentsCount: 0,
      incidentSummary: "Fully clear, reinforced retaining walls, continuous 4G and police escort patrol",
      roadAccessibility: "Fully Passable",
      isRecommended: true,
      recommendationReason: "✅ RECOMMENDED: Route B is 8 km longer but has significantly lower disaster risk (22/100 vs 78/100).",
      pathCoordinates: [
        [33.3765, 74.3103],
        [33.2800, 74.5800],
        [33.0800, 74.8300],
        [32.8500, 74.8900],
        [32.7266, 74.8570],
      ],
    },
  },
  rishikesh_devprayag: {
    routeA: {
      id: "Route A",
      name: "NH-58 River Bed Highway",
      via: "Shivpuri & Byasi Gorge (Vulnerable to rockfall)",
      distanceKm: 72,
      estimatedMinutes: 110,
      riskScore: 84,
      riskLevel: "HIGH RISK",
      activeIncidentsCount: 2,
      incidentSummary: "Massive rockfall near Byasi; single lane cleared by BRO excavator",
      roadAccessibility: "One-Lane / Rough",
      isRecommended: false,
      recommendationReason: "❌ NOT RECOMMENDED: High probability of secondary rockfalls after 14:00 hrs.",
      pathCoordinates: [
        [30.0869, 78.2676],
        [30.1384, 78.3912],
        [30.1856, 78.4728],
        [30.1459, 78.5989],
      ],
    },
    routeB: {
      id: "Route B",
      name: "Narendra Nagar - Chamba High Ridge Route",
      via: "Narendra Nagar & Chamba bypass",
      distanceKm: 86,
      estimatedMinutes: 135,
      riskScore: 26,
      riskLevel: "LOW RISK",
      activeIncidentsCount: 0,
      incidentSummary: "Stable mountain crest with concrete drainage, zero blockages reported",
      roadAccessibility: "Fully Passable",
      isRecommended: true,
      recommendationReason: "✅ RECOMMENDED: 14 km longer but avoids the active landslide choke point on NH-58.",
      pathCoordinates: [
        [30.0869, 78.2676],
        [30.1600, 78.2900],
        [30.3400, 78.3900],
        [30.3100, 78.5200],
        [30.1459, 78.5989],
      ],
    },
  },
};

/**
 * Calculates straight line distance in km between two lat/lng points
 */
export function calculateDistanceKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.max(15, Math.round(R * c));
}

/**
 * Dynamic corridor generator for any pickup and destination combination
 */
export function getCorridorRoutes(
  pickup: LocationPreset,
  destination: LocationPreset
): { routeA: RouteOption; routeB: RouteOption } {
  // Generate dynamic routes between any two locations in India
  const rawDist = calculateDistanceKm(pickup.lat, pickup.lng, destination.lat, destination.lng);
  const distA = Math.round(rawDist * 1.22);
  const distB = Math.round(rawDist * 1.34);

  const speedA = 38; // km/h in rough canyon road
  const speedB = 48; // km/h on paved ridge bypass
  const minA = Math.max(30, Math.round((distA / speedA) * 60));
  const minB = Math.max(35, Math.round((distB / speedB) * 60));

  const isHighRisk = pickup.isHighRiskZone || destination.isHighRiskZone;
  const riskA = isHighRisk ? 82 : 68;
  const riskB = 22;

  // Midpoints for polylines
  const midLat = (pickup.lat + destination.lat) / 2;
  const midLng = (pickup.lng + destination.lng) / 2;
  const dLat = destination.lat - pickup.lat;
  const dLng = destination.lng - pickup.lng;

  // Route A direct pass with small wave
  const pathA: [number, number][] = [
    [pickup.lat, pickup.lng],
    [pickup.lat + dLat * 0.3 + dLng * 0.05, pickup.lng + dLng * 0.3 - dLat * 0.05],
    [midLat, midLng],
    [pickup.lat + dLat * 0.7 - dLng * 0.05, pickup.lng + dLng * 0.7 + dLat * 0.05],
    [destination.lat, destination.lng],
  ];

  // Route B engineered bypass (wider arc detour)
  const pathB: [number, number][] = [
    [pickup.lat, pickup.lng],
    [pickup.lat + dLat * 0.25 - dLng * 0.15, pickup.lng + dLng * 0.25 + dLat * 0.15],
    [midLat - dLng * 0.2, midLng + dLat * 0.2],
    [pickup.lat + dLat * 0.75 - dLng * 0.15, pickup.lng + dLng * 0.75 + dLat * 0.15],
    [destination.lat, destination.lng],
  ];

  return {
    routeA: {
      id: "Route A",
      name: `Direct Corridor (${pickup.name.split(" ")[0]} - ${destination.name.split(" ")[0]})`,
      via: "Direct Lowland / Riverbed Highway",
      distanceKm: distA,
      estimatedMinutes: minA,
      riskScore: riskA,
      riskLevel: riskA >= 70 ? "HIGH RISK" : "MEDIUM RISK",
      activeIncidentsCount: isHighRisk ? 3 : 1,
      incidentSummary: isHighRisk
        ? "Active debris blockage, vulnerable valley gorge, and saturated culverts"
        : "Moderate traffic and potential monsoon waterlogging",
      roadAccessibility: isHighRisk ? "High Hazard / Blocked" : "One-Lane / Rough",
      isRecommended: false,
      recommendationReason: `❌ NOT RECOMMENDED: High hazard risk (${riskA}/100) due to prone terrain and reported weather alerts.`,
      pathCoordinates: pathA,
    },
    routeB: {
      id: "Route B",
      name: `Engineered Ridge Bypass (${pickup.name.split(" ")[0]} - ${destination.name.split(" ")[0]})`,
      via: "Elevated Crest / Retaining Wall Bypass",
      distanceKm: distB,
      estimatedMinutes: minB,
      riskScore: riskB,
      riskLevel: "LOW RISK",
      activeIncidentsCount: 0,
      incidentSummary: "Reinforced retaining walls, clear drainage channels, patrol vehicle standby",
      roadAccessibility: "Fully Passable",
      isRecommended: true,
      recommendationReason: `✅ RECOMMENDED: Safe engineered bypass with ${riskB}/100 risk score and zero active blockages.`,
      pathCoordinates: pathB,
    },
  };
}

/**
 * Calculates fare according to SIH Problem Statement Formula:
 * Estimated Fare = Base Fare + (Distance in km × Rate per km) + Risk/Detour Charge
 */
export function calculateEstimatedFare(
  vehicleType: VehicleType,
  distanceKm: number,
  route: RouteOption,
  priority: BookingPriority,
  pricingList: VehiclePricingConfig[] = INITIAL_VEHICLE_PRICING
): {
  baseFare: number;
  distanceCharge: number;
  riskDetourCharge: number;
  prioritySurcharge: number;
  totalEstimatedFare: number;
} {
  const vehicle = pricingList.find((v) => v.type === vehicleType) || pricingList[1] || pricingList[0]; // default to Mini Truck or first available
  const baseFare = vehicle.baseFare;
  const distanceCharge = Math.round(distanceKm * vehicle.ratePerKm);

  // If Route A has high risk or Route B incurs a detour charge
  let riskDetourCharge = 0;
  if (route.riskScore >= 70) {
    // Hazard hazard premium (insurance & spotter costs)
    riskDetourCharge = Math.round(distanceCharge * 0.15);
  } else if (route.id === "Route B") {
    // Standard safe detour service surcharge as specified in example (₹300 for 120km Mini Truck)
    riskDetourCharge = Math.max(100, Math.round(distanceKm * 2.5));
  }

  // Priority adjustments
  let prioritySurcharge = 0;
  if (priority === "EMERGENCY") {
    // Subsidized or dedicated escort handling
    prioritySurcharge = 0; // Emergency disaster relief receives zero surge pricing
  } else if (priority === "URGENT") {
    prioritySurcharge = Math.round(baseFare * 0.25);
  }

  const totalEstimatedFare = baseFare + distanceCharge + riskDetourCharge + prioritySurcharge;

  return {
    baseFare,
    distanceCharge,
    riskDetourCharge,
    prioritySurcharge,
    totalEstimatedFare,
  };
}

export const INITIAL_BOOKINGS: TransportBooking[] = [
  {
    bookingId: "BK-2026-9041",
    userId: "usr_rajesh_01",
    userName: "Col. Rajesh Sharma (Retd)",
    userPhone: "+91 98112 45890",
    driverId: "drv_vikram_88",
    driverName: "Vikramjit Singh",
    driverPhone: "+91 94191 77621",
    driverRating: 4.9,
    vehicleType: "Mini Truck",
    vehicleNumber: "JK-02-CD-4188",
    purpose: "Disaster Relief",
    priority: "EMERGENCY",
    isEmergency: true,
    pickupLocation: {
      name: "Rajouri (Border District)",
      lat: 33.3765,
      lng: 74.3103,
    },
    destinationLocation: {
      name: "Jammu Tawi Base Depot",
      lat: 32.7266,
      lng: 74.8570,
    },
    distanceKm: 128,
    estimatedMinutes: 200,
    fareBreakdown: {
      baseFare: 250,
      distanceCharge: 4200,
      riskDetourCharge: 300,
      totalEstimatedFare: 4750,
    },
    selectedRoute: "Route B",
    routeDetails: CORRIDOR_ROUTES.default.routeB,
    status: "Trip Started",
    packageInfo: {
      weightKg: 1400,
      description: "WHO Emergency Medical Rations, Antivenom Kits, and Purified Water Tablets",
      isFragileOrPerishable: true,
      recipientName: "Dr. Ananya Kaul (Jammu GMC)",
      recipientPhone: "+91 94191 33201",
    },
    driverProgressPercent: 48,
    driverCurrentLocation: [33.0800, 74.8300],
    greenCorridorApproved: true,
    createdAt: "45 mins ago",
    updatedAt: "3 mins ago",
  },
  {
    bookingId: "BK-2026-8912",
    userId: "usr_priya_22",
    userName: "Priya Sundaram",
    userPhone: "+91 97171 89012",
    driverId: "drv_sunil_04",
    driverName: "Sunil Rawat",
    driverPhone: "+91 98371 44520",
    driverRating: 4.8,
    vehicleType: "Mini Truck",
    vehicleNumber: "UK-07-TA-8921",
    purpose: "Medicine Delivery",
    priority: "URGENT",
    isEmergency: false,
    pickupLocation: {
      name: "Rishikesh Transit Center",
      lat: 30.0869,
      lng: 78.2676,
    },
    destinationLocation: {
      name: "Devprayag (NH-58 Junction)",
      lat: 30.1459,
      lng: 78.5989,
    },
    distanceKm: 86,
    estimatedMinutes: 135,
    fareBreakdown: {
      baseFare: 150,
      distanceCharge: 2150,
      riskDetourCharge: 220,
      totalEstimatedFare: 2520,
    },
    selectedRoute: "Route B",
    routeDetails: CORRIDOR_ROUTES.rishikesh_devprayag.routeB,
    status: "On the Way",
    packageInfo: {
      weightKg: 120,
      description: "Insulin Cold-Chain Cooler Boxes & Dialysis Fluids",
      isFragileOrPerishable: true,
      recipientName: "Devprayag Community Health Center",
      recipientPhone: "+91 1378 261 200",
    },
    driverProgressPercent: 25,
    driverCurrentLocation: [30.1600, 78.2900],
    greenCorridorApproved: true,
    createdAt: "22 mins ago",
    updatedAt: "Just now",
  },
  {
    bookingId: "BK-2026-9055",
    userId: "usr_amit_44",
    userName: "Amit Verma (Food Supplies Rep)",
    userPhone: "+91 94120 66543",
    driverId: undefined,
    driverName: undefined,
    vehicleType: "Truck",
    purpose: "Food Delivery",
    priority: "NORMAL",
    isEmergency: false,
    pickupLocation: {
      name: "Jammu Tawi Base Depot",
      lat: 32.7266,
      lng: 74.8570,
    },
    destinationLocation: {
      name: "Rajouri (Border District)",
      lat: 33.3765,
      lng: 74.3103,
    },
    distanceKm: 128,
    estimatedMinutes: 240,
    fareBreakdown: {
      baseFare: 500,
      distanceCharge: 6400,
      riskDetourCharge: 320,
      totalEstimatedFare: 7220,
    },
    selectedRoute: "Route B",
    routeDetails: CORRIDOR_ROUTES.default.routeB,
    status: "Searching",
    packageInfo: {
      weightKg: 8500,
      description: "Dry Rice, Wheat Flour, and Lentils for 4 Relief Camps",
      isFragileOrPerishable: false,
    },
    createdAt: "4 mins ago",
    updatedAt: "4 mins ago",
  },
];
