import { useState, useEffect, useCallback } from "react";

export interface RealWeatherData {
  temperature: number;
  rainProbability: number;
  rainfall: number;
  weatherCondition: string;
  windSpeed: number;
  visibility: number;
  weatherAlert: string;
  weatherRisk: "Low" | "Medium" | "High";
  weatherRiskScoreDelta: number;
  currentTime: string;
  lastUpdatedTime: string;
  location: string;
  coordinates?: { lat: number; lng: number };
  dataSource: string;
  isRealData: boolean;
}

export interface UseRealWeatherResult {
  weather: RealWeatherData | null;
  isLoading: boolean;
  error: string | null;
  refetch: () => Promise<void>;
}

export function useRealWeather(
  lat: number = 26.1445,
  lng: number = 91.7362,
  locationName: string = "Current Location",
  isDemoMode: boolean = false
): UseRealWeatherResult {
  const [weather, setWeather] = useState<RealWeatherData | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const fetchWeather = useCallback(async () => {
    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch(
        `/api/weather?lat=${lat}&lng=${lng}&locationName=${encodeURIComponent(locationName)}`
      );

      if (!response.ok) {
        throw new Error(`Weather service responded with ${response.status}`);
      }

      const data = await response.json();

      if (data.status === "error" || !data.temperature) {
        throw new Error(data.message || "Weather data temporarily unavailable.");
      }

      setWeather({
        temperature: data.temperature,
        rainProbability: data.rainProbability,
        rainfall: data.rainfall,
        weatherCondition: data.weatherCondition,
        windSpeed: data.windSpeed,
        visibility: data.visibility,
        weatherAlert: data.weatherAlert,
        weatherRisk: data.weatherRisk,
        weatherRiskScoreDelta: data.weatherRiskScoreDelta,
        currentTime: data.currentTime,
        lastUpdatedTime: data.lastUpdatedTime,
        location: data.location || locationName,
        coordinates: data.coordinates || { lat, lng },
        dataSource: isDemoMode
          ? `${data.dataSource} (DEMO SIMULATION)`
          : data.dataSource,
        isRealData: !isDemoMode,
      });
      setError(null);
    } catch (err: any) {
      console.warn("Real weather fetch error:", err);
      // Explicit Prompt Mandate: "If the weather API fails, show: 'Weather data temporarily unavailable.' Do NOT invent weather values."
      setError("Weather data temporarily unavailable.");
      setWeather(null);
    } finally {
      setIsLoading(false);
    }
  }, [lat, lng, locationName, isDemoMode]);

  useEffect(() => {
    fetchWeather();
  }, [fetchWeather]);

  return {
    weather,
    isLoading,
    error,
    refetch: fetchWeather,
  };
}
