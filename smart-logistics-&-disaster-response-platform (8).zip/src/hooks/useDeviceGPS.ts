import { useState, useEffect, useCallback } from "react";

export interface GPSLocation {
  lat: number;
  lng: number;
  accuracyMeters: number | null;
  speedKmh: number | null;
  heading: number | null;
  timestamp: string;
  formattedAddress: string;
  locality: string;
  isRealGPS: boolean;
  isWatching: boolean;
}

export interface GPSState {
  location: GPSLocation;
  permissionStatus: "prompt" | "granted" | "denied" | "unsupported";
  isLoading: boolean;
  error: string | null;
  refreshGPS: () => Promise<void>;
  startWatching: () => void;
  stopWatching: () => void;
  setManualLocation: (lat: number, lng: number, address: string) => void;
}

// Fallback demo coordinates for Northeast disaster test corridor
const DEMO_COORDS = {
  lat: 26.1445,
  lng: 91.7362,
  address: "Guwahati Disaster Command Sector, Assam (DEMO)",
};

export function useDeviceGPS(isDemoMode: boolean = false): GPSState {
  const [location, setLocation] = useState<GPSLocation>({
    lat: DEMO_COORDS.lat,
    lng: DEMO_COORDS.lng,
    accuracyMeters: 15,
    speedKmh: 0,
    heading: null,
    timestamp: new Date().toLocaleTimeString(),
    formattedAddress: DEMO_COORDS.address,
    locality: "Guwahati, Assam",
    isRealGPS: false,
    isWatching: false,
  });

  const [permissionStatus, setPermissionStatus] = useState<"prompt" | "granted" | "denied" | "unsupported">("prompt");
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [watchId, setWatchId] = useState<number | null>(null);

  // Reverse geocode via server
  const reverseGeocode = useCallback(async (lat: number, lng: number): Promise<{ address: string; locality: string }> => {
    try {
      const res = await fetch(`/api/geocode/reverse?lat=${lat}&lng=${lng}`);
      if (res.ok) {
        const data = await res.json();
        return {
          address: data.fullAddress || data.formattedLocation || `Lat ${lat.toFixed(4)}, Lng ${lng.toFixed(4)}`,
          locality: data.locality || `${lat.toFixed(4)}, ${lng.toFixed(4)}`,
        };
      }
    } catch {
      // ignore
    }
    return {
      address: `GPS: [${lat.toFixed(4)}, ${lng.toFixed(4)}]`,
      locality: `Lat: ${lat.toFixed(4)}, Lng: ${lng.toFixed(4)}`,
    };
  }, []);

  const refreshGPS = useCallback(async () => {
    if (isDemoMode) {
      setLocation({
        lat: DEMO_COORDS.lat,
        lng: DEMO_COORDS.lng,
        accuracyMeters: 10,
        speedKmh: 0,
        heading: 0,
        timestamp: new Date().toLocaleTimeString(),
        formattedAddress: DEMO_COORDS.address,
        locality: "Guwahati, Assam (Demo)",
        isRealGPS: false,
        isWatching: false,
      });
      setError(null);
      setPermissionStatus("granted");
      return;
    }

    if (!navigator.geolocation) {
      setPermissionStatus("unsupported");
      setError("Device does not support GPS geolocation.");
      return;
    }

    setIsLoading(true);
    setError(null);

    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const { latitude, longitude, accuracy, speed, heading } = pos.coords;
        setPermissionStatus("granted");

        const geo = await reverseGeocode(latitude, longitude);

        setLocation({
          lat: latitude,
          lng: longitude,
          accuracyMeters: accuracy ? Math.round(accuracy) : null,
          speedKmh: speed ? Math.round(speed * 3.6) : 0,
          heading: heading || null,
          timestamp: new Date(pos.timestamp).toLocaleTimeString(),
          formattedAddress: geo.address,
          locality: geo.locality,
          isRealGPS: true,
          isWatching: false,
        });

        setIsLoading(false);
        setError(null);
      },
      (err) => {
        setIsLoading(false);
        if (err.code === err.PERMISSION_DENIED) {
          setPermissionStatus("denied");
          setError("Location permission is required to report an incident accurately.");
        } else if (err.code === err.POSITION_UNAVAILABLE) {
          setError("Unable to determine current location. GPS signal weak.");
        } else {
          setError("GPS request timed out. Retrying recommended.");
        }
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 5000,
      }
    );
  }, [isDemoMode, reverseGeocode]);

  // Start continuous watching for transport tracking
  const startWatching = useCallback(() => {
    if (!navigator.geolocation || isDemoMode) return;

    if (watchId !== null) return;

    const id = navigator.geolocation.watchPosition(
      async (pos) => {
        const { latitude, longitude, accuracy, speed, heading } = pos.coords;
        setLocation((prev) => ({
          ...prev,
          lat: latitude,
          lng: longitude,
          accuracyMeters: accuracy ? Math.round(accuracy) : null,
          speedKmh: speed ? Math.round(speed * 3.6) : 0,
          heading: heading || null,
          timestamp: new Date(pos.timestamp).toLocaleTimeString(),
          isRealGPS: true,
          isWatching: true,
        }));
      },
      (err) => {
        console.warn("GPS watch error:", err.message);
      },
      { enableHighAccuracy: true, maximumAge: 3000 }
    );

    setWatchId(id);
  }, [isDemoMode, watchId]);

  const stopWatching = useCallback(() => {
    if (watchId !== null) {
      navigator.geolocation.clearWatch(watchId);
      setWatchId(null);
      setLocation((prev) => ({ ...prev, isWatching: false }));
    }
  }, [watchId]);

  const setManualLocation = useCallback(async (lat: number, lng: number, address: string) => {
    const geo = await reverseGeocode(lat, lng);
    setLocation({
      lat,
      lng,
      accuracyMeters: 5,
      speedKmh: 0,
      heading: null,
      timestamp: new Date().toLocaleTimeString(),
      formattedAddress: address || geo.address,
      locality: geo.locality,
      isRealGPS: false,
      isWatching: false,
    });
  }, [reverseGeocode]);

  useEffect(() => {
    refreshGPS();
    return () => {
      if (watchId !== null) {
        navigator.geolocation.clearWatch(watchId);
      }
    };
  }, [refreshGPS]);

  return {
    location,
    permissionStatus,
    isLoading,
    error,
    refreshGPS,
    startWatching,
    stopWatching,
    setManualLocation,
  };
}
