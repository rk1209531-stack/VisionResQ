export type UserRole = "citizen" | "driver" | "authority" | "emergency";

export type IncidentType =
  | "Landslide"
  | "Flood"
  | "Road Damage"
  | "Bridge Damage"
  | "Traffic Blockage";

export type SeverityLevel = "Low" | "Medium" | "High" | "Critical";

export type IncidentStatus =
  | "Reported"
  | "Verified"
  | "Team Dispatched"
  | "Work In Progress"
  | "Resolved";

export interface Incident {
  id: string;
  title: string;
  type: IncidentType;
  description: string;
  locationName: string;
  lat: number;
  lng: number;
  highwayNumber?: string;
  imageUrl: string;
  voiceNoteUrl?: string;
  voiceTranscript?: string;
  reportedAt: string;
  reportedBy: {
    name: string;
    role: UserRole;
    phone?: string;
  };
  aiAnalysis: {
    incidentType: IncidentType;
    summary: string;
    severity: SeverityLevel;
    riskScore: number; // 0 - 100
    recommendedAction: string;
    estimatedClearanceHours?: number;
    affectedInfrastructure?: string[];
    greenCorridorViability?: boolean;
    analyzedAt?: string;
    modelUsed: string;
  };
  crowdVerification: {
    confirmations: number;
    rejections: number;
    confidenceScore: number; // percentage 0 - 100
    userVoted?: "confirm" | "reject" | null;
  };
  status: IncidentStatus;
  assignedTeam?: {
    teamName: string;
    agency: "NDRF" | "SDRF" | "BRO" | "Traffic Police" | "PWD" | "NHAI" | "State Police" | string;
    contactNumber: string;
    personnelCount?: number;
    equipment?: string[];
    dispatchedAt?: string;
  };
  resolutionTimeline: {
    step: string;
    timestamp: string;
    note: string;
    updatedBy: string;
  }[];
  isEmergencyPriority?: boolean;
  isOfflineSubmitted?: boolean;
}

export interface EmergencyRequest {
  id: string;
  incidentId?: string;
  requestType: "Ambulance" | "Medical Supply Delivery" | "Food Supply" | "Disaster Relief Vehicles";
  urgency: "Normal" | "High" | "Critical Priority";
  destination: string;
  origin: string;
  passengersOrCargo: string;
  contactPerson: string;
  contactPhone: string;
  requestedAt: string;
  status: "Pending Dispatch" | "Green Corridor Active" | "In Transit" | "Delivered";
  assignedEscort?: string;
}

export interface BroadcastAlert {
  id: string;
  title: string;
  type: "HIGH RISK ALERT" | "WEATHER DISRUPTION" | "CORRIDOR CLEARANCE" | "ALL CLEAR";
  severity: "Red" | "Amber" | "Yellow";
  region: string;
  message: string;
  recommendedAction: string;
  timestamp: string;
  issuedBy: string;
  active: boolean;
}

export interface SmartRoute {
  id: string;
  origin: string;
  destination: string;
  routeA: {
    name: string;
    distanceKm: number;
    estimatedMinutes: number;
    riskPercentage: number;
    hazards: string[];
    isRecommended: boolean;
    roadCondition: string;
  };
  routeB: {
    name: string;
    distanceKm: number;
    estimatedMinutes: number;
    riskPercentage: number;
    hazards: string[];
    isRecommended: boolean;
    roadCondition: string;
  };
  greenCorridorActive: boolean;
  aiRecommendation: string;
}

export interface OfflineReportQueueItem {
  id: string;
  createdAt?: string;
  timestamp?: string;
  type: IncidentType;
  description: string;
  locationName: string;
  lat: number;
  lng: number;
  imageBase64?: string;
  imageUrl?: string;
  voiceTranscript?: string;
  synced?: boolean;
  syncStatus?: string;
}

export type VehicleType = "Bike" | "Mini Truck" | "Heavy Truck" | "Ambulance" | "Truck";

export type TripPurpose =
  | "Construction Materials"
  | "Agricultural Produce"
  | "Medicine Delivery"
  | "Food Delivery"
  | "Disaster Relief"
  | "Other";

export type BookingPriority = "NORMAL" | "URGENT" | "EMERGENCY";

export type BookingStatus =
  | "Searching"
  | "Accepted"
  | "Driver Assigned"
  | "On the Way"
  | "Arrived"
  | "Trip Started"
  | "Completed"
  | "Cancelled";

export interface VehiclePricingConfig {
  type: VehicleType;
  baseFare: number;
  ratePerKm: number;
  capacity: string;
  description: string;
  iconName: string;
}

export interface RouteOption {
  id: "Route A" | "Route B";
  name: string;
  via: string;
  distanceKm: number;
  estimatedMinutes: number;
  riskScore: number; // 0 - 100
  riskLevel: "LOW RISK" | "MEDIUM RISK" | "HIGH RISK";
  activeIncidentsCount: number;
  incidentSummary: string;
  roadAccessibility: "Fully Passable" | "One-Lane / Rough" | "High Hazard / Blocked";
  isRecommended: boolean;
  recommendationReason: string;
  pathCoordinates: [number, number][];
}

export interface TransportBooking {
  bookingId: string;
  userId: string;
  userName: string;
  userPhone: string;
  driverId?: string;
  driverName?: string;
  driverPhone?: string;
  driverRating?: number;
  vehicleType: VehicleType;
  vehicleNumber?: string;
  purpose: TripPurpose;
  priority: BookingPriority;
  isEmergency: boolean;
  pickupLocation: {
    name: string;
    lat: number;
    lng: number;
  };
  destinationLocation: {
    name: string;
    lat: number;
    lng: number;
  };
  distanceKm: number;
  estimatedMinutes: number;
  fareBreakdown: {
    baseFare: number;
    distanceCharge: number;
    riskDetourCharge: number;
    totalEstimatedFare: number;
  };
  selectedRoute: "Route A" | "Route B";
  routeDetails: RouteOption;
  status: BookingStatus;
  packageInfo?: {
    weightKg?: number;
    description?: string;
    isFragileOrPerishable?: boolean;
    recipientName?: string;
    recipientPhone?: string;
  };
  driverProgressPercent?: number; // 0 - 100 for tracking simulation
  driverCurrentLocation?: [number, number];
  greenCorridorApproved?: boolean;
  createdAt: string;
  updatedAt: string;
}

export type ScreenId =
  | "splash"
  | "login"
  | "register"
  | "home"
  | "book_transport"
  | "booking_confirmation"
  | "booking_tracking"
  | "driver_dashboard"
  | "report"
  | "voice_report"
  | "ai_analysis"
  | "incident_details"
  | "crowd_verify"
  | "live_map"
  | "smart_route"
  | "alerts"
  | "emergency"
  | "authority_dashboard"
  | "incident_mgmt"
  | "resolution_tracking"
  | "profile";
