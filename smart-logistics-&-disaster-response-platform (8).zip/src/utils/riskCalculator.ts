export interface RiskCalculationBreakdown {
  incidentRisk: number; // 0 - 40
  weatherRisk: number; // 0 - 25
  accessibilityRisk: number; // 0 - 25
  verificationFactor: number; // -10 to +10 (crowd verification dampener / amplifier)
  totalRiskScore: number; // normalized 0 - 100
  riskLevel: "LOW" | "MEDIUM" | "HIGH";
  riskColor: string;
  explanation: string;
}

export function calculateSmartRiskScore(params: {
  incidentSeverity?: "Low" | "Medium" | "High" | "Critical";
  activeIncidentsOnRouteCount?: number;
  weatherRiskFactor?: "Low" | "Medium" | "High";
  weatherRainfallMm?: number;
  roadAccessibility?: "Fully Passable" | "One-Lane / Rough" | "High Hazard / Blocked";
  confirmationsCount?: number;
  rejectionsCount?: number;
}): RiskCalculationBreakdown {
  const {
    incidentSeverity = "Medium",
    activeIncidentsOnRouteCount = 1,
    weatherRiskFactor = "Low",
    weatherRainfallMm = 0,
    roadAccessibility = "One-Lane / Rough",
    confirmationsCount = 1,
    rejectionsCount = 0,
  } = params;

  // 1. Incident Severity & Count (Base 0 - 40)
  let incidentScore = 15;
  if (incidentSeverity === "High" || incidentSeverity === "Critical") {
    incidentScore = 35;
  } else if (incidentSeverity === "Medium") {
    incidentScore = 22;
  } else if (incidentSeverity === "Low") {
    incidentScore = 8;
  }
  // Extra incident presence adds up to 10 points
  if (activeIncidentsOnRouteCount > 1) {
    incidentScore = Math.min(45, incidentScore + (activeIncidentsOnRouteCount - 1) * 8);
  }

  // 2. Weather Factor (0 - 25)
  let weatherScore = 5;
  if (weatherRiskFactor === "High" || weatherRainfallMm > 15) {
    weatherScore = 25;
  } else if (weatherRiskFactor === "Medium" || weatherRainfallMm > 2) {
    weatherScore = 14;
  } else {
    weatherScore = 4;
  }

  // 3. Road Accessibility Risk (0 - 25)
  let accessScore = 10;
  if (roadAccessibility === "High Hazard / Blocked") {
    accessScore = 25;
  } else if (roadAccessibility === "One-Lane / Rough") {
    accessScore = 14;
  } else {
    accessScore = 3;
  }

  // 4. Crowd Verification Factor (-10 to +10)
  // If many people confirm, probability of real blockage increases
  // If many dispute, risk reduces
  let verifFactor = 0;
  if (confirmationsCount >= 5 && rejectionsCount === 0) {
    verifFactor = 6;
  } else if (rejectionsCount > confirmationsCount) {
    verifFactor = -8;
  }

  // Total raw score
  const rawTotal = incidentScore + weatherScore + accessScore + verifFactor;
  const total = Math.max(5, Math.min(98, Math.round(rawTotal)));

  // Normalize: 0-30 -> LOW, 31-70 -> MEDIUM, 71-100 -> HIGH
  let riskLevel: "LOW" | "MEDIUM" | "HIGH" = "LOW";
  let riskColor = "emerald";

  if (total >= 71) {
    riskLevel = "HIGH";
    riskColor = "rose";
  } else if (total >= 31) {
    riskLevel = "MEDIUM";
    riskColor = "amber";
  } else {
    riskLevel = "LOW";
    riskColor = "emerald";
  }

  const explanation = `${riskLevel} RISK (${total}/100): Incident severity contributes ${incidentScore}pts, live weather adds ${weatherScore}pts, road accessibility adds ${accessScore}pts, and community crowd verification adjusts by ${verifFactor >= 0 ? `+${verifFactor}` : verifFactor}pts.`;

  return {
    incidentRisk: incidentScore,
    weatherRisk: weatherScore,
    accessibilityRisk: accessScore,
    verificationFactor: verifFactor,
    totalRiskScore: total,
    riskLevel,
    riskColor,
    explanation,
  };
}
