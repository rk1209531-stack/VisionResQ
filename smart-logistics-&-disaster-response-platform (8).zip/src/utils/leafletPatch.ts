import L from "leaflet";

/**
 * Leaflet DOM Positioning Safety Patch
 *
 * Prevents "TypeError: Cannot read properties of undefined (reading '_leaflet_pos')"
 * which occurs in Leaflet when:
 * 1. An animation or transition callback executes while a map or marker is unmounted/removed.
 * 2. `DomUtil.getPosition` or `DomUtil.setPosition` is called on an undefined or detached element.
 * 3. `map._getMapPanePos()` is called after `map._mapPane` has been destroyed during teardown.
 */

let isPatched = false;

export function applyLeafletSafetyPatch(): void {
  if (isPatched || typeof window === "undefined" || !L) return;

  try {
    // 1. Patch DomUtil.getPosition
    if (L.DomUtil && typeof L.DomUtil.getPosition === "function") {
      const originalGetPosition = L.DomUtil.getPosition;
      L.DomUtil.getPosition = function (el: HTMLElement) {
        if (!el) {
          return new L.Point(0, 0);
        }
        try {
          return originalGetPosition(el) || (el as any)._leaflet_pos || new L.Point(0, 0);
        } catch {
          return (el as any)?._leaflet_pos || new L.Point(0, 0);
        }
      };
    }

    // 2. Patch DomUtil.setPosition
    if (L.DomUtil && typeof L.DomUtil.setPosition === "function") {
      const originalSetPosition = L.DomUtil.setPosition;
      L.DomUtil.setPosition = function (el: HTMLElement, point: L.Point) {
        if (!el) return;
        try {
          originalSetPosition(el, point);
        } catch {
          try {
            (el as any)._leaflet_pos = point;
          } catch {
            // ignore
          }
        }
      };
    }

    // 3. Patch Map.prototype._getMapPanePos
    if (L.Map && L.Map.prototype) {
      const originalGetMapPanePos = (L.Map.prototype as any)._getMapPanePos;
      if (typeof originalGetMapPanePos === "function") {
        (L.Map.prototype as any)._getMapPanePos = function () {
          if (!this || !this._mapPane) {
            return new L.Point(0, 0);
          }
          try {
            return originalGetMapPanePos.call(this) || new L.Point(0, 0);
          } catch {
            return new L.Point(0, 0);
          }
        };
      }

      // 4. Patch Map.prototype.remove for graceful animation cancellation
      const originalRemove = L.Map.prototype.remove;
      if (typeof originalRemove === "function") {
        L.Map.prototype.remove = function () {
          try {
            if (typeof (this as any)._stop === "function") {
              (this as any)._stop();
            }
            if ((this as any)._panAnim && typeof (this as any)._panAnim.stop === "function") {
              (this as any)._panAnim.stop();
            }
          } catch {
            // ignore pre-cleanup stops
          }

          try {
            return originalRemove.call(this);
          } catch (err) {
            console.warn("Leaflet safe map removal caught error:", err);
            return this;
          }
        };
      }
    }

    // 5. Patch PosAnimation.prototype.run
    if (L.PosAnimation && L.PosAnimation.prototype) {
      const originalRun = L.PosAnimation.prototype.run;
      if (typeof originalRun === "function") {
        L.PosAnimation.prototype.run = function (el: HTMLElement, newPos: L.Point, duration?: number, easeLinearity?: number) {
          if (!el) return this;
          try {
            return originalRun.call(this, el, newPos, duration, easeLinearity);
          } catch {
            return this;
          }
        };
      }
    }

    isPatched = true;
  } catch (err) {
    console.warn("Failed to apply Leaflet safety patch:", err);
  }
}

// Auto-apply on import
applyLeafletSafetyPatch();
