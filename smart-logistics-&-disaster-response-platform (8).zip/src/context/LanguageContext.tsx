import React, { createContext, useContext, useState, useEffect } from "react";
import {
  SupportedLanguage,
  SUPPORTED_LANGUAGES,
  TRANSLATIONS,
  TranslationStrings,
  LanguageOption,
} from "../services/i18n";

interface LanguageContextType {
  currentLanguage: SupportedLanguage;
  setLanguage: (lang: SupportedLanguage) => void;
  t: TranslationStrings;
  languages: LanguageOption[];
  isAssamLanguage: boolean;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentLanguage, setCurrentLanguage] = useState<SupportedLanguage>(() => {
    const saved = localStorage.getItem("sih_app_language") as SupportedLanguage;
    return saved && TRANSLATIONS[saved] ? saved : "en"; // Default to English for VisionResQ
  });

  const setLanguage = (lang: SupportedLanguage) => {
    setCurrentLanguage(lang);
    localStorage.setItem("sih_app_language", lang);
  };

  const activeLangOption = SUPPORTED_LANGUAGES.find((l) => l.code === currentLanguage);
  const isAssamLanguage = !!activeLangOption?.isAssamLanguage;

  return (
    <LanguageContext.Provider
      value={{
        currentLanguage,
        setLanguage,
        t: TRANSLATIONS[currentLanguage] || TRANSLATIONS.en,
        languages: SUPPORTED_LANGUAGES,
        isAssamLanguage,
      }}
    >
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error("useLanguage must be used within a LanguageProvider");
  }
  return context;
};
